
from typing import Optional
from .db import get_conn

def write_audit(
    action: str,
    actor: str = "system",
    resource_type: Optional[str] = None,
    resource_id: Optional[str] = None,
    detail: Optional[dict] = None,
):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO admin_audit_log (
                    actor, action, resource_type, resource_id, detail
                )
                VALUES (%s, %s, %s, %s, %s)
                """,
                (actor, action, resource_type, resource_id, detail or {}),
            )
        conn.commit()
