
from dataclasses import replace
from .user_preferences import UserPreferences, get_preferences, save_preferences
from .db import get_conn

STEP = 0.05
MIN_WEIGHT = 0.10
MAX_WEIGHT = 0.80

def _bounded(value):
    return max(MIN_WEIGHT, min(MAX_WEIGHT, value))

def _renormalize(saving, time, simplicity):
    total = saving + time + simplicity
    if total <= 0:
        return 0.50, 0.25, 0.25
    return saving / total, time / total, simplicity / total

def apply_feedback(user_id: str, feedback_type: str) -> UserPreferences:
    p = get_preferences(user_id)

    saving = p.weight_saving
    time = p.weight_time
    simplicity = p.weight_simplicity

    if feedback_type == "prefer_cheaper":
        saving = _bounded(saving + STEP)
    elif feedback_type in {"prefer_faster", "too_slow"}:
        time = _bounded(time + STEP)
    elif feedback_type in {"prefer_fewer_stores", "too_many_stores"}:
        simplicity = _bounded(simplicity + STEP)
    elif feedback_type == "too_far":
        time = _bounded(time + STEP / 2)
        simplicity = _bounded(simplicity + STEP / 2)
    elif feedback_type == "good_choice":
        pass

    saving, time, simplicity = _renormalize(saving, time, simplicity)

    updated = replace(
        p,
        weight_saving=round(saving, 4),
        weight_time=round(time, 4),
        weight_simplicity=round(simplicity, 4),
    )
    save_preferences(updated)
    return updated

def suggest_strategy(user_id: str):
    p = get_preferences(user_id)
    if p.weight_saving >= 0.60:
        key = "max_saving"
        reason = "Dai tuoi feedback emerge una forte preferenza per il risparmio."
    elif p.weight_simplicity >= 0.38 or p.weight_time >= 0.35:
        key = "max_comfort"
        reason = "Dai tuoi feedback emerge una preferenza per meno tempo e meno negozi."
    else:
        key = "balanced"
        reason = "Le tue preferenze risultano equilibrate tra risparmio, tempo e semplicità."

    return {
        "strategy": key,
        "reason": reason,
        "weights": {
            "saving": p.weight_saving,
            "time": p.weight_time,
            "simplicity": p.weight_simplicity,
        }
    }

def reset_learning(user_id: str) -> UserPreferences:
    current = get_preferences(user_id)
    reset = replace(
        current,
        weight_saving=0.50,
        weight_time=0.25,
        weight_simplicity=0.25,
    )
    save_preferences(reset)

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                DELETE FROM choice_feedback
                WHERE user_id=%s
            """, (user_id,))
        conn.commit()

    return reset

def learning_summary(user_id: str):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT feedback_type, COUNT(*)
                FROM choice_feedback
                WHERE user_id=%s
                GROUP BY feedback_type
                ORDER BY COUNT(*) DESC
            """, (user_id,))
            rows = cur.fetchall()

    prefs = get_preferences(user_id)
    suggestion = suggest_strategy(user_id)

    return {
        "feedback_counts": {r[0]: r[1] for r in rows},
        "learned_weights": {
            "saving": prefs.weight_saving,
            "time": prefs.weight_time,
            "simplicity": prefs.weight_simplicity,
        },
        "suggested_strategy": suggestion,
        "learning_mode": "explicit-feedback-only",
        "note": "Gli aggiustamenti sono piccoli, spiegabili e basati solo sul feedback esplicito.",
    }
