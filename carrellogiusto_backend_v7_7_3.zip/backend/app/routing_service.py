
from dataclasses import dataclass
from typing import Optional, List
import os
import json
from urllib.request import urlopen, Request
from urllib.error import URLError, HTTPError

from .geo import haversine_km
from .route_cache import RouteCache

@dataclass
class RouteEstimate:
    distance_km: float
    duration_minutes: Optional[float]
    provider: str
    verified: bool

class RoutingProvider:
    name = "base"
    def route(self, coordinates: List[dict], profile: str = "driving") -> RouteEstimate:
        raise NotImplementedError

class HaversineRoutingProvider(RoutingProvider):
    name = "haversine"

    def route(self, coordinates: List[dict], profile: str = "driving") -> RouteEstimate:
        if len(coordinates) < 2:
            return RouteEstimate(0.0, 0.0, self.name, False)

        total = 0.0
        for a, b in zip(coordinates, coordinates[1:]):
            total += haversine_km(
                a["latitude"], a["longitude"],
                b["latitude"], b["longitude"],
            )

        return RouteEstimate(
            distance_km=round(total, 3),
            duration_minutes=None,
            provider=self.name,
            verified=False,
        )

class OSRMRoutingProvider(RoutingProvider):
    name = "osrm"

    def __init__(self, base_url: Optional[str] = None, timeout_seconds: float = 5.0):
        self.base_url = (base_url or os.getenv("ROUTING_BASE_URL", "")).rstrip("/")
        self.timeout_seconds = timeout_seconds

    def route(self, coordinates: List[dict], profile: str = "driving") -> RouteEstimate:
        if not self.base_url:
            raise RuntimeError("ROUTING_BASE_URL non configurato")
        coord_string = ";".join(
            f'{float(c["longitude"])},{float(c["latitude"])}'
            for c in coordinates
        )
        url = f"{self.base_url}/route/v1/{profile}/{coord_string}?overview=false&steps=false"
        req = Request(url, headers={"User-Agent": "CarrelloGiusto/6.1"})
        try:
            with urlopen(req, timeout=self.timeout_seconds) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (URLError, HTTPError, TimeoutError) as exc:
            raise RuntimeError(f"Routing provider non raggiungibile: {exc}") from exc

        routes = payload.get("routes") or []
        if payload.get("code") != "Ok" or not routes:
            raise RuntimeError(f"Routing provider response non valida: {payload.get('code')}")

        route = routes[0]
        return RouteEstimate(
            distance_km=round(float(route["distance"]) / 1000.0, 3),
            duration_minutes=round(float(route["duration"]) / 60.0, 1),
            provider=self.name,
            verified=True,
        )

class RoutingService:
    _cache = RouteCache(ttl_seconds=int(os.getenv("ROUTE_CACHE_TTL_SECONDS", "900")))

    def __init__(self):
        self.primary = OSRMRoutingProvider() if os.getenv("ROUTING_BASE_URL") else None
        self.fallback = HaversineRoutingProvider()

    def estimate(self, coordinates: List[dict], profile: str = "driving") -> RouteEstimate:
        cached = self._cache.get(coordinates, profile)
        if cached:
            return cached

        if self.primary:
            try:
                result = self.primary.route(coordinates, profile)
                self._cache.set(coordinates, profile, result)
                return result
            except Exception:
                pass

        result = self.fallback.route(coordinates, profile)
        self._cache.set(coordinates, profile, result)
        return result
