
from dataclasses import dataclass
from typing import Optional
from .db import get_conn

@dataclass(frozen=True)
class OfferCandidate:
    offer_id: str
    store_id: str
    store_name: str
    product_key: str
    product_name: str
    brand: Optional[str]
    price: float
    regular_price: Optional[float]
    quantity: Optional[float]
    unit: Optional[str]
    verified: bool
    source_status: Optional[str]
    valid_from: Optional[str]
    valid_to: Optional[str]
    loyalty_required: bool

class OfferRepositoryV46:
    def find_candidates(
        self,
        product_key: str,
        preferred_brand: str | None = None,
        allow_equivalents: bool = True,
        strict_brand: bool = False,
    ):
        params = [product_key]
        brand_clause = ""

        if strict_brand and preferred_brand:
            brand_clause = "AND LOWER(COALESCE(p.brand,'')) = LOWER(%s)"
            params.append(preferred_brand)
        elif preferred_brand and not allow_equivalents:
            brand_clause = "AND LOWER(COALESCE(p.brand,'')) = LOWER(%s)"
            params.append(preferred_brand)

        sql = f"""
            SELECT
                o.id::text,
                s.id::text,
                s.name,
                COALESCE(p.product_key, p.id::text),
                p.name,
                p.brand,
                o.price,
                o.regular_price,
                p.quantity,
                p.unit,
                COALESCE(o.verified, FALSE),
                o.source_status,
                o.valid_from::text,
                o.valid_to::text,
                COALESCE(o.loyalty_required, FALSE)
            FROM offers o
            JOIN products p ON p.id = o.product_id
            JOIN stores s ON s.id = o.store_id
            WHERE COALESCE(p.product_key, p.id::text) = %s
              {brand_clause}
              AND (o.valid_from IS NULL OR o.valid_from <= NOW())
              AND (o.valid_to IS NULL OR o.valid_to >= NOW())
              AND COALESCE(o.source_status, 'active') NOT IN ('expired','rejected','stale','not_yet_valid')
              AND COALESCE(o.freshness_status, 'fresh') = 'fresh'
              AND o.source_checked_at IS NOT NULL
              AND o.source_checked_at >= NOW() - INTERVAL '48 hours'
            ORDER BY
                COALESCE(o.verified, FALSE) DESC,
                o.price ASC
        """

        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, tuple(params))
                rows = cur.fetchall()

        return [
            OfferCandidate(
                offer_id=r[0],
                store_id=r[1],
                store_name=r[2],
                product_key=r[3],
                product_name=r[4],
                brand=r[5],
                price=float(r[6]),
                regular_price=float(r[7]) if r[7] is not None else None,
                quantity=float(r[8]) if r[8] is not None else None,
                unit=r[9],
                verified=bool(r[10]),
                source_status=r[11],
                valid_from=r[12],
                valid_to=r[13],
                loyalty_required=bool(r[14]),
            )
            for r in rows
        ]
