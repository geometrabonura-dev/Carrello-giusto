
from dataclasses import dataclass
from typing import Optional

from .catalog_repository_v44 import CatalogRepositoryV44

@dataclass(frozen=True)
class ResolvedCartItem:
    product_key: str
    product_name: str
    brand: Optional[str]
    quantity: float
    unit: str
    preferred_brand: Optional[str]
    allow_equivalents: bool
    strict_brand: bool

class CartValidationError(ValueError):
    pass

def _norm_unit(value: str) -> str:
    v = value.strip().lower()
    aliases = {
        "kilogram": "kg",
        "kilograms": "kg",
        "litro": "l",
        "liter": "l",
        "liters": "l",
        "confezione": "pack",
        "package": "pack",
        "pezzo": "piece",
        "piece": "piece",
    }
    return aliases.get(v, v)

def resolve_cart_items(raw_items, repo: CatalogRepositoryV44 | None = None):
    repo = repo or CatalogRepositoryV44()
    resolved = []

    for raw in raw_items:
        product = repo.resolve_key(raw.product_key)
        if product is None:
            raise CartValidationError(
                f"product_key non riconosciuta: {raw.product_key}"
            )

        requested_unit = _norm_unit(raw.unit)
        catalog_unit = _norm_unit(product.unit)

        if requested_unit != catalog_unit:
            raise CartValidationError(
                f"Unità non valida per {raw.product_key}: "
                f"ricevuta {raw.unit}, attesa {product.unit}"
            )

        quantity = float(raw.quantity)
        if quantity <= 0:
            raise CartValidationError(
                f"Quantità non valida per {raw.product_key}"
            )

        if not product.allow_fractional_quantity and abs(quantity - round(quantity)) > 1e-9:
            raise CartValidationError(
                f"{raw.product_key} non accetta quantità frazionarie"
            )

        preferred_brand = raw.preferred_brand

        if product.strict_brand:
            if product.brand and preferred_brand and preferred_brand.lower() != product.brand.lower():
                raise CartValidationError(
                    f"{raw.product_key} richiede la marca {product.brand}"
                )
            preferred_brand = product.brand
            allow_equivalents = False
        else:
            allow_equivalents = bool(raw.allow_equivalents)

        resolved.append(
            ResolvedCartItem(
                product_key=product.product_key,
                product_name=product.name,
                brand=product.brand,
                quantity=quantity,
                unit=product.unit,
                preferred_brand=preferred_brand,
                allow_equivalents=allow_equivalents,
                strict_brand=product.strict_brand,
            )
        )

    return resolved
