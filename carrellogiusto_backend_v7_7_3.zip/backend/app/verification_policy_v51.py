
from .authorized_sources_v51 import get_source
from .real_offer_models_v51 import ImportDecision

def decide_verification(
    *,
    source_key: str,
    product_match_confidence: float,
    store_resolved: bool,
    has_valid_price: bool,
):
    source = get_source(source_key)
    if source is None:
        return ImportDecision(
            accepted=False,
            verification_status="rejected",
            reason="Fonte non registrata.",
            product_match_confidence=product_match_confidence,
            source_authorized=False,
        )

    if not store_resolved:
        return ImportDecision(
            accepted=False,
            verification_status="needs_review",
            reason="Punto vendita non risolto.",
            product_match_confidence=product_match_confidence,
            source_authorized=source.authorized_for_auto_verification,
        )

    if not has_valid_price:
        return ImportDecision(
            accepted=False,
            verification_status="rejected",
            reason="Prezzo non valido.",
            product_match_confidence=product_match_confidence,
            source_authorized=source.authorized_for_auto_verification,
        )

    if product_match_confidence < 0.90:
        return ImportDecision(
            accepted=True,
            verification_status="needs_review",
            reason="Match prodotto troppo debole per accettazione automatica.",
            product_match_confidence=product_match_confidence,
            source_authorized=source.authorized_for_auto_verification,
        )

    if (
        source.official
        and source.authorized_for_auto_verification
        and product_match_confidence >= 0.98
    ):
        return ImportDecision(
            accepted=True,
            verification_status="verified",
            reason="Fonte autorizzata + match prodotto ad alta confidenza.",
            product_match_confidence=product_match_confidence,
            source_authorized=True,
        )

    return ImportDecision(
        accepted=True,
        verification_status="accepted_unverified",
        reason=(
            "Offerta accettata ma non verificata automaticamente: "
            "la fonte non è abilitata all'auto-verifica."
        ),
        product_match_confidence=product_match_confidence,
        source_authorized=source.authorized_for_auto_verification,
    )
