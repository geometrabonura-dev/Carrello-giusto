
class ReviewStateActionsV57:
    def __init__(self, review_repository, audit):
        self.review_repository = review_repository
        self.audit = audit

    def reopen(
        self,
        *,
        review_id: str,
        source_key: str,
        actor: str,
        reason: str,
    ):
        self.review_repository.reopen_review(
            review_id=review_id,
            reason=reason,
        )

        self.audit.log(
            actor=actor,
            action="reopen_review",
            entity_type="review",
            entity_id=review_id,
            source_key=source_key,
            details={"reason": reason},
        )

        return {
            "status": "pending",
            "review_id": review_id,
            "reason": reason,
        }
