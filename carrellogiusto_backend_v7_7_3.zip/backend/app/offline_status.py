
from dataclasses import dataclass

@dataclass(frozen=True)
class DataAvailability:
    repository: str
    offers_available: bool
    verified_offer_count: int
    fallback_allowed: bool

    def as_dict(self):
        return {
            "repository": self.repository,
            "offers_available": self.offers_available,
            "verified_offer_count": self.verified_offer_count,
            "fallback_allowed": self.fallback_allowed,
        }
