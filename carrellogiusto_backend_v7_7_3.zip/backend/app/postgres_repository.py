
from dataclasses import dataclass
from typing import List, Optional
from .db import get_conn
from .catalog_repository import CatalogRepository, OfferRecord
from .geo import haversine_km

@dataclass
class GeoStoreRecord:
    id: str
    name: str
    distance_km: float
    source_status: str
    latitude: float
    longitude: float

class PostgresCatalogRepository(CatalogRepository):
    def find_stores(self, radius_km: float, origin: Optional[dict] = None) -> List[GeoStoreRecord]:
        if not origin or "latitude" not in origin or "longitude" not in origin:
            return []

        lat, lon = float(origin["latitude"]), float(origin["longitude"])
        import math
        lat_delta = radius_km / 111.0
        lon_delta = radius_km / max(1.0, 111.0 * abs(math.cos(math.radians(lat))))

        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT id::text, name, latitude, longitude, source_status
                    FROM stores
                    WHERE active=TRUE
                      AND latitude IS NOT NULL AND longitude IS NOT NULL
                      AND latitude BETWEEN %s AND %s
                      AND longitude BETWEEN %s AND %s
                """, (lat-lat_delta, lat+lat_delta, lon-lon_delta, lon+lon_delta))
                rows = cur.fetchall()

        out = []
        for sid, name, slat, slon, status in rows:
            d = haversine_km(lat, lon, float(slat), float(slon))
            if d <= radius_km:
                out.append(
                    GeoStoreRecord(
                        id=sid,
                        name=name,
                        distance_km=round(d, 3),
                        source_status=status or "unknown",
                        latitude=float(slat),
                        longitude=float(slon),
                    )
                )
        return sorted(out, key=lambda s: s.distance_km)

    def find_offers(self, item_names: List[str], store_ids: List[str]) -> List[OfferRecord]:
        if not item_names or not store_ids:
            return []
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT p.canonical_name,o.store_id::text,o.price,o.source_status,o.verified
                    FROM offers o
                    JOIN products p ON p.id=o.product_id
                    WHERE p.canonical_name=ANY(%s)
                      AND o.store_id::text=ANY(%s)
                      AND o.active=TRUE
                      AND (o.valid_from IS NULL OR o.valid_from<=CURRENT_DATE)
                      AND (o.valid_to IS NULL OR o.valid_to>=CURRENT_DATE)
                """, (item_names,store_ids))
                return [
                    OfferRecord(r[0],r[1],float(r[2]),r[3] or "unknown",bool(r[4]))
                    for r in cur.fetchall()
                ]
