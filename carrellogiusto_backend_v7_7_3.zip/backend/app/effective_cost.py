
def time_cost(duration_minutes: float | None, value_per_hour: float) -> float:
    if duration_minutes is None:
        return 0.0
    return round((duration_minutes / 60.0) * max(0.0, value_per_hour), 2)

def effective_total(product_total: float, travel_cost: float, duration_minutes: float | None, value_per_hour: float) -> dict:
    t_cost = time_cost(duration_minutes, value_per_hour)
    return {
        "time_cost": t_cost,
        "effective_total": round(product_total + travel_cost + t_cost, 2),
    }
