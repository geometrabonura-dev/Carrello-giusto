
from dataclasses import dataclass
from typing import Optional
from .db import get_conn

@dataclass
class ChoiceEvent:
    user_id: str
    strategy: str
    chosen_plan_key: str
    recommended_plan_key: Optional[str]
    accepted_recommendation: bool
    stores_count: int
    product_total: float
    travel_cost: float
    time_cost: float
    effective_total: float
    duration_minutes: Optional[float]
    distance_km: Optional[float]

def record_choice(event: ChoiceEvent) -> str:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO choice_history (
                    user_id, strategy, chosen_plan_key, recommended_plan_key,
                    accepted_recommendation, stores_count, product_total,
                    travel_cost, time_cost, effective_total,
                    duration_minutes, distance_km
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                RETURNING id::text
            """, (
                event.user_id,
                event.strategy,
                event.chosen_plan_key,
                event.recommended_plan_key,
                event.accepted_recommendation,
                event.stores_count,
                event.product_total,
                event.travel_cost,
                event.time_cost,
                event.effective_total,
                event.duration_minutes,
                event.distance_km,
            ))
            event_id = cur.fetchone()[0]
        conn.commit()
    return event_id

def recent_choices(user_id: str, limit: int = 50):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT
                    id::text, strategy, chosen_plan_key, recommended_plan_key,
                    accepted_recommendation, stores_count, product_total,
                    travel_cost, time_cost, effective_total,
                    duration_minutes, distance_km, created_at
                FROM choice_history
                WHERE user_id=%s
                ORDER BY created_at DESC
                LIMIT %s
            """, (user_id, limit))
            rows = cur.fetchall()

    return [
        {
            "id": r[0],
            "strategy": r[1],
            "chosen_plan_key": r[2],
            "recommended_plan_key": r[3],
            "accepted_recommendation": r[4],
            "stores_count": r[5],
            "product_total": float(r[6]),
            "travel_cost": float(r[7]),
            "time_cost": float(r[8]),
            "effective_total": float(r[9]),
            "duration_minutes": float(r[10]) if r[10] is not None else None,
            "distance_km": float(r[11]) if r[11] is not None else None,
            "created_at": r[12].isoformat() if r[12] else None,
        }
        for r in rows
    ]
