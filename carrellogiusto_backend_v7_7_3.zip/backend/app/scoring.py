
def _normalize(value, lo, hi, inverse=False):
    if hi <= lo:
        return 1.0
    x = (value - lo) / (hi - lo)
    x = max(0.0, min(1.0, x))
    return 1.0 - x if inverse else x

def score_plans(plans, weight_saving=0.50, weight_time=0.25, weight_simplicity=0.25, store_penalty_eur=0.75):
    if not plans:
        return plans

    product_totals = [p["product_total"] for p in plans]
    durations = [p["duration_minutes"] or 0 for p in plans]
    store_counts = [len(p["stores"]) for p in plans]

    min_prod, max_prod = min(product_totals), max(product_totals)
    min_time, max_time = min(durations), max(durations)
    min_store, max_store = min(store_counts), max(store_counts)

    weight_sum = max(weight_saving + weight_time + weight_simplicity, 1e-9)

    for p in plans:
        saving_score = _normalize(p["product_total"], min_prod, max_prod, inverse=True)
        time_score = _normalize(p["duration_minutes"] or 0, min_time, max_time, inverse=True)
        simplicity_score = _normalize(len(p["stores"]), min_store, max_store, inverse=True)

        weighted = (
            weight_saving * saving_score +
            weight_time * time_score +
            weight_simplicity * simplicity_score
        ) / weight_sum

        store_penalty = max(0, len(p["stores"]) - 1) * store_penalty_eur
        p["store_penalty"] = round(store_penalty, 2)
        p["personalized_score"] = round(weighted, 4)
        p["effective_total_with_store_penalty"] = round(
            p["effective_total"] + store_penalty, 2
        )

    return sorted(
        plans,
        key=lambda p: (-p["personalized_score"], p["effective_total_with_store_penalty"])
    )
