from fastapi import APIRouter, Depends
from .auth import require_admin
from .ai_orchestrator_v64 import (
    AI_ALLOWED_TASKS,
    AI_FORBIDDEN_TASKS,
    DETERMINISTIC_AUTHORITIES,
    authorize_ai_task,
)

router = APIRouter(prefix="/admin/ai", tags=["ai-v6-4"])

@router.get("/policy", dependencies=[Depends(require_admin)])
def ai_policy():
    return {
        "allowed_tasks": sorted(AI_ALLOWED_TASKS),
        "forbidden_tasks": sorted(AI_FORBIDDEN_TASKS),
        "deterministic_authorities": DETERMINISTIC_AUTHORITIES,
        "principle": (
            "L'AI assiste e orchestra; prezzi, verifica, freshness, routing "
            "e decisione economica restano deterministici."
        ),
    }

@router.get("/policy/{task}", dependencies=[Depends(require_admin)])
def ai_task_policy(task: str):
    return authorize_ai_task(task).to_dict()
