from __future__ import annotations

from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class AIMatchSuggestionV64:
    candidate_product_id: str
    confidence: float
    explanation: str
    advisory_only: bool = True

    def to_dict(self):
        return asdict(self)

def should_auto_accept_ai_match(confidence: float) -> bool:
    # v6.4 deliberately forbids autonomous AI acceptance.
    return False

def route_ai_match(confidence: float) -> str:
    """
    AI suggestions never become verified mappings automatically.

    >=0.98 -> still needs deterministic confirmation
    >=0.90 -> review
    <0.90  -> review/unmatched
    """
    confidence = float(confidence)
    if confidence >= 0.98:
        return "deterministic_confirmation_required"
    if confidence >= 0.90:
        return "needs_review"
    return "needs_review"
