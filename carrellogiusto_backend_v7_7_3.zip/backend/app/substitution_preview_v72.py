from __future__ import annotations

from typing import Any

from .substitution_compatibility_v71 import (
    evaluate_substitution_compatibility_v71,
)

def _normalize_cost(price: float, quantity: float | None, unit: str | None):
    if quantity is None or quantity <= 0 or not unit:
        return None
    u = str(unit).lower()
    if u == "g":
        return price / (quantity / 1000.0)
    if u == "kg":
        return price / quantity
    if u == "ml":
        return price / (quantity / 1000.0)
    if u in {"l", "lt"}:
        return price / quantity
    if u in {"piece", "pezzo", "pc", "pack", "confezione"}:
        return price / quantity
    return None

class SubstitutionPreviewV72:
    def _conn(self):
        from .db import get_conn
        return get_conn()

    def _product(self, product_key: str):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        COALESCE(product_key, id::text),
                        name,
                        brand,
                        quantity,
                        unit,
                        ean,
                        gtin
                    FROM products
                    WHERE COALESCE(product_key, id::text) = %s
                    LIMIT 1
                    """,
                    (product_key,),
                )
                row = cur.fetchone()
        if not row:
            return None
        return {
            "product_key": str(row[0]),
            "name": row[1],
            "brand": row[2],
            "quantity": float(row[3]) if row[3] is not None else None,
            "unit": row[4],
            "ean": row[5],
            "gtin": row[6],
        }

    def _best_offer(self, product_key: str):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        o.price,
                        COALESCE(o.verified, FALSE),
                        COALESCE(o.loyalty_required, FALSE),
                        s.name,
                        p.quantity,
                        p.unit
                    FROM offers o
                    JOIN products p ON p.id = o.product_id
                    JOIN stores s ON s.id = o.store_id
                    WHERE COALESCE(p.product_key, p.id::text) = %s
                      AND (o.valid_from IS NULL OR o.valid_from <= NOW())
                      AND (o.valid_to IS NULL OR o.valid_to >= NOW())
                      AND COALESCE(o.source_status, 'active')
                          NOT IN ('expired','rejected','stale','not_yet_valid')
                      AND COALESCE(o.freshness_status, 'fresh') = 'fresh'
                      AND o.source_checked_at IS NOT NULL
                      AND o.source_checked_at >= NOW() - INTERVAL '48 hours'
                    ORDER BY
                        COALESCE(o.verified, FALSE) DESC,
                        o.price ASC
                    LIMIT 1
                    """,
                    (product_key,),
                )
                row = cur.fetchone()
        if not row:
            return None
        normalized = _normalize_cost(
            float(row[0]),
            float(row[4]) if row[4] is not None else None,
            row[5],
        )
        return {
            "price": float(row[0]),
            "verified": bool(row[1]),
            "loyalty_required": bool(row[2]),
            "store_name": row[3],
            "quantity": float(row[4]) if row[4] is not None else None,
            "unit": row[5],
            "normalized_unit_cost": (
                round(normalized, 4) if normalized is not None else None
            ),
        }

    def build(self, *, source_product_key: str, alternative_product_key: str):
        source = self._product(source_product_key)
        alternative = self._product(alternative_product_key)
        if source is None or alternative is None:
            raise ValueError("Prodotto non trovato.")

        compatibility = evaluate_substitution_compatibility_v71(
            source_quantity=source["quantity"],
            source_unit=source["unit"],
            alternative_quantity=alternative["quantity"],
            alternative_unit=alternative["unit"],
        )

        source_offer = self._best_offer(source_product_key)
        alternative_offer = self._best_offer(alternative_product_key)

        normalized_saving = None
        comparison_status = "not_comparable"
        if (
            source_offer
            and alternative_offer
            and source_offer["normalized_unit_cost"] is not None
            and alternative_offer["normalized_unit_cost"] is not None
            and compatibility.compatible
        ):
            normalized_saving = round(
                source_offer["normalized_unit_cost"]
                - alternative_offer["normalized_unit_cost"],
                4,
            )
            comparison_status = (
                "verified"
                if source_offer["verified"] and alternative_offer["verified"]
                else "unverified"
            )

        return {
            "source": source,
            "alternative": alternative,
            "compatibility": compatibility.to_dict(),
            "source_offer": source_offer,
            "alternative_offer": alternative_offer,
            "normalized_saving": normalized_saving,
            "comparison_status": comparison_status,
        }
