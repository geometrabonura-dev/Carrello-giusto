
from .optimizer_v34 import optimize_personalized
from .strategy_profiles import get_strategy
from .explanations_v35 import explain_plan

def optimize_with_strategy(
    items,
    stores,
    offers,
    origin,
    strategy="balanced",
    travel_profile="car",
    vehicle_cost_per_km=None,
    time_value_per_hour=None,
    min_saving_to_travel=3.0,
    max_stores=3,
    max_travel_minutes=None,
):
    preset = get_strategy(strategy)

    result = optimize_personalized(
        items=items,
        stores=stores,
        offers=offers,
        origin=origin,
        travel_profile=travel_profile,
        vehicle_cost_per_km=vehicle_cost_per_km,
        time_value_per_hour=time_value_per_hour,
        min_saving_to_travel=min_saving_to_travel,
        max_stores=max_stores,
        max_travel_minutes=max_travel_minutes,
        weight_saving=preset.weight_saving,
        weight_time=preset.weight_time,
        weight_simplicity=preset.weight_simplicity,
        store_penalty_eur=preset.store_penalty_eur,
    )

    recommendation = result.get("recommendation")
    explanation = explain_plan(
        recommendation,
        closest_plan=result.get("closest_plan"),
        cheapest_product_plan=result.get("max_saving_plan"),
    )

    result["strategy"] = {
        "key": preset.key,
        "label": preset.label,
        "description": preset.description,
    }
    result["explanation"] = explanation
    return result
