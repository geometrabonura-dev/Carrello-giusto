from dataclasses import dataclass
from typing import Any

from .routing_service import RoutingService
from .route_ordering_v60 import scalable_stop_order

@dataclass(frozen=True)
class PairRouteV61:
    distance_km: float
    duration_minutes: float | None
    provider: str
    verified: bool

def _estimate_pair(service, a: dict, b: dict, profile: str):
    result = service.estimate([a, b], profile=profile)
    return PairRouteV61(
        distance_km=float(result.distance_km),
        duration_minutes=(
            float(result.duration_minutes)
            if result.duration_minutes is not None else None
        ),
        provider=str(result.provider),
        verified=bool(result.verified),
    )

def build_pairwise_route_matrix_v61(
    *,
    origin: dict,
    stores: list[dict],
    travel_profile: str,
    routing_provider=None,
):
    """
    Build one reusable pairwise matrix for origin + candidate stores.

    routing_provider can be:
    - None: use RoutingService()
    - object exposing estimate(coordinates, profile=...)
    This fixes the old path where the injected routing provider was ignored.
    """
    service = routing_provider or RoutingService()

    nodes = [
        {
            "id": "__origin__",
            "latitude": float(origin["latitude"]),
            "longitude": float(origin["longitude"]),
        }
    ]
    for s in stores:
        nodes.append({
            "id": str(s["id"]),
            "latitude": float(s["lat"]),
            "longitude": float(s["lon"]),
        })

    n = len(nodes)
    distance = [[0.0 for _ in range(n)] for _ in range(n)]
    duration = [[0.0 for _ in range(n)] for _ in range(n)]
    duration_known = [[True for _ in range(n)] for _ in range(n)]
    verified = [[True for _ in range(n)] for _ in range(n)]
    providers = [["none" for _ in range(n)] for _ in range(n)]

    for i in range(n):
        for j in range(i + 1, n):
            pair = _estimate_pair(service, nodes[i], nodes[j], travel_profile)

            distance[i][j] = pair.distance_km
            distance[j][i] = pair.distance_km

            if pair.duration_minutes is None:
                duration_known[i][j] = False
                duration_known[j][i] = False
                duration[i][j] = 0.0
                duration[j][i] = 0.0
            else:
                duration[i][j] = pair.duration_minutes
                duration[j][i] = pair.duration_minutes

            verified[i][j] = pair.verified
            verified[j][i] = pair.verified
            providers[i][j] = pair.provider
            providers[j][i] = pair.provider

    return {
        "nodes": nodes,
        "distance": distance,
        "duration": duration,
        "duration_known": duration_known,
        "verified": verified,
        "providers": providers,
        "index_by_store_id": {
            str(node["id"]): idx for idx, node in enumerate(nodes)
        },
    }

def route_for_store_ids_v61(matrix_bundle, store_ids):
    idx_map = matrix_bundle["index_by_store_id"]
    stop_nodes = [idx_map[str(sid)] for sid in store_ids]

    order = list(
        scalable_stop_order(
            matrix_bundle["distance"],
            stop_nodes,
        )
    )

    legs = []
    prev = 0
    total_distance = 0.0
    total_duration = 0.0
    all_duration_known = True
    all_verified = True
    provider_names = set()

    for node in [*order, 0]:
        total_distance += matrix_bundle["distance"][prev][node]
        if matrix_bundle["duration_known"][prev][node]:
            total_duration += matrix_bundle["duration"][prev][node]
        else:
            all_duration_known = False
        all_verified = all_verified and matrix_bundle["verified"][prev][node]
        provider_names.add(matrix_bundle["providers"][prev][node])
        legs.append((prev, node))
        prev = node

    ordered_store_ids = [
        matrix_bundle["nodes"][idx]["id"] for idx in order
    ]

    return {
        "ordered_store_ids": ordered_store_ids,
        "distance_km": round(total_distance, 3),
        "duration_minutes": (
            round(total_duration, 2) if all_duration_known else None
        ),
        "verified": bool(all_verified),
        "provider": "+".join(sorted(p for p in provider_names if p != "none")) or "none",
        "legs": legs,
    }
