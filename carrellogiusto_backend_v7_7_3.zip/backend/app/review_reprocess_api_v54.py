
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

router = APIRouter(prefix="/v5/reprocess", tags=["reprocess-v5-4"])

class ReprocessRequest(BaseModel):
    source_key: str
    external_ref: str
    review_type: str
    limit: int = Field(default=100, ge=1, le=500)

@router.post("")
def reprocess(payload: ReprocessRequest):
    if payload.review_type not in ("store", "product"):
        raise HTTPException(
            status_code=422,
            detail="review_type deve essere store o product",
        )

    from .raw_review_repository_v54 import RawReviewRepositoryV54
    from .raw_reprocess_v54 import RawReprocessServiceV54
    from .import_repository_v52 import ImportRepositoryV52
    from .product_match_adapter_v52 import ProductMatchAdapterV52
    from .review_repository_v53 import ReviewRepositoryV53
    from .source_product_mapping_v53 import SourceProductMappingV53

    payloads = RawReviewRepositoryV54().payloads_for_resolved_mapping(
        source_key=payload.source_key,
        external_ref=payload.external_ref,
        review_type=payload.review_type,
        limit=payload.limit,
    )

    if not payloads:
        return {
            "status": "nothing_to_reprocess",
            "count": 0,
        }

    result = RawReprocessServiceV54(
        import_repository=ImportRepositoryV52(),
        product_matcher=ProductMatchAdapterV52(),
        review_repository=ReviewRepositoryV53(),
        product_mapping_repository=SourceProductMappingV53(),
    ).reprocess_payloads(
        source_key=payload.source_key,
        payloads=payloads,
    )

    return {
        "status": "reprocessed",
        "count": len(payloads),
        "import_result": result,
    }
