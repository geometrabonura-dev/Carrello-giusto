
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional

from .request_models_v43 import CartItemV43
from .cart_resolution_v45 import resolve_cart_items, CartValidationError
from .optimizer_input_v45 import to_optimizer_items
from .cart_offer_resolution_v46 import resolve_offer_coverage
from .optimizer_v46 import build_store_pricebook
from .store_enrichment_v47 import enrich_pricebook_with_store_coordinates
from .route_aware_optimizer_v47 import optimize_db_cart_route_aware

router = APIRouter(prefix="/v4/cart", tags=["cart-v4-7"])

class Origin(BaseModel):
    latitude: float
    longitude: float

class OptimizeCartV47Request(BaseModel):
    items: list[CartItemV43]
    origin: Origin
    travel_profile: str = "car"
    max_stores: int = Field(default=3, ge=1, le=3)
    min_saving_to_travel: float = 3.0
    vehicle_cost_per_km: Optional[float] = None
    time_value_per_hour: Optional[float] = None

@router.post("/optimize")
def optimize_cart_v47(payload: OptimizeCartV47Request):
    try:
        resolved = resolve_cart_items(payload.items)
    except CartValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    optimizer_items = to_optimizer_items(resolved)
    coverage = resolve_offer_coverage(optimizer_items)

    if coverage.missing:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "cart_incomplete",
                "message": "Non ci sono offerte utilizzabili per tutti i prodotti.",
                "missing_items": coverage.missing,
            },
        )

    pricebook = build_store_pricebook(coverage)
    pricebook = enrich_pricebook_with_store_coordinates(pricebook)

    result = optimize_db_cart_route_aware(
        pricebook=pricebook,
        product_keys=[i["product_key"] for i in optimizer_items],
        origin={
            "latitude": payload.origin.latitude,
            "longitude": payload.origin.longitude,
        },
        routing_provider=None,
        travel_profile=payload.travel_profile,
        max_stores=payload.max_stores,
        min_saving_to_travel=payload.min_saving_to_travel,
        vehicle_cost_per_km=payload.vehicle_cost_per_km,
        time_value_per_hour=payload.time_value_per_hour,
    )

    if result is None:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "no_complete_plan",
                "message": "Nessuna combinazione di negozi copre tutto il carrello.",
            },
        )

    chosen = result["recommendation"]
    data_status = (
        "verified"
        if chosen["all_offers_verified"]
        else "unverified"
    )

    return {
        "data_status": data_status,
        "recommendation": result["recommendation"],
        "closest_plan": result["closest_plan"],
        "max_saving_plan": result["max_saving_plan"],
        "best_single_store": result["best_single_store"],
        "plans": result["plans"],
        "rule": result["rule"],
        "explanation": {
            "headline": "Scelta calcolata su prezzi, distanza e tempo",
            "reasons": [
                (
                    f"Soglia minima per spostarti: "
                    f"€{result['rule']['min_saving_to_travel']:.2f}."
                ),
                (
                    f"Costo viaggio: "
                    f"€{chosen['travel_cost']:.2f}; "
                    f"costo tempo: €{chosen['time_cost']:.2f}."
                ),
                (
                    "Il piano consigliato rispetta la soglia minima "
                    "rispetto al piano più vicino."
                ),
            ],
        },
    }
