
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from .auth import require_admin

router = APIRouter(prefix="/admin/review-actions", tags=["admin-review-v5-6"])

class RejectReviewRequest(BaseModel):
    review_id: str
    source_key: str
    review_type: str
    external_ref: str
    reason: str = Field(min_length=2, max_length=500)

class RetryReviewRequest(BaseModel):
    source_key: str
    external_ref: str
    review_type: str
    limit: int = Field(default=50, ge=1, le=200)

@router.get("/search/stores", dependencies=[Depends(require_admin)])
def search_stores(q: str, limit: int = 20):
    from .admin_search_v56 import AdminSearchV56
    return AdminSearchV56().search_stores(
        q=q,
        limit=max(1, min(limit, 50)),
    )

@router.get("/search/products", dependencies=[Depends(require_admin)])
def search_products(q: str, limit: int = 20):
    from .admin_search_v56 import AdminSearchV56
    return AdminSearchV56().search_products(
        q=q,
        limit=max(1, min(limit, 50)),
    )

@router.post("/reject", dependencies=[Depends(require_admin)])
def reject_review(
    payload: RejectReviewRequest,
    x_admin_actor: str = Header(default="admin"),
):
    if payload.review_type not in ("store", "product"):
        raise HTTPException(
            status_code=422,
            detail="review_type deve essere store o product",
        )

    from .review_repository_v53 import ReviewRepositoryV53
    from .manual_audit_v55 import ManualAuditV55
    from .review_actions_v56 import ReviewActionsV56

    return ReviewActionsV56(
        review_repository=ReviewRepositoryV53(),
        audit=ManualAuditV55(),
    ).reject(
        review_id=payload.review_id,
        source_key=payload.source_key,
        review_type=payload.review_type,
        external_ref=payload.external_ref,
        actor=x_admin_actor,
        reason=payload.reason,
    )

@router.post("/retry", dependencies=[Depends(require_admin)])
def retry_review(
    payload: RetryReviewRequest,
    x_admin_actor: str = Header(default="admin"),
):
    if payload.review_type not in ("store", "product"):
        raise HTTPException(
            status_code=422,
            detail="review_type deve essere store o product",
        )

    from .raw_review_repository_v54 import RawReviewRepositoryV54
    from .raw_reprocess_v54 import RawReprocessServiceV54
    from .import_repository_v52 import ImportRepositoryV52
    from .product_match_adapter_v52 import ProductMatchAdapterV52
    from .review_repository_v53 import ReviewRepositoryV53
    from .source_product_mapping_v53 import SourceProductMappingV53
    from .manual_audit_v55 import ManualAuditV55

    payloads = RawReviewRepositoryV54().payloads_for_resolved_mapping(
        source_key=payload.source_key,
        external_ref=payload.external_ref,
        review_type=payload.review_type,
        limit=payload.limit,
    )

    if not payloads:
        return {"status": "nothing_to_retry", "count": 0}

    result = RawReprocessServiceV54(
        import_repository=ImportRepositoryV52(),
        product_matcher=ProductMatchAdapterV52(),
        review_repository=ReviewRepositoryV53(),
        product_mapping_repository=SourceProductMappingV53(),
    ).reprocess_payloads(
        source_key=payload.source_key,
        payloads=payloads,
    )

    ManualAuditV55().log(
        actor=x_admin_actor,
        action="retry_review",
        entity_type="review",
        entity_id=None,
        source_key=payload.source_key,
        details={
            "external_ref": payload.external_ref,
            "review_type": payload.review_type,
            "count": len(payloads),
        },
    )

    return {
        "status": "retried",
        "count": len(payloads),
        "result": result,
    }
