
import os
from .catalog_repository import DemoCatalogRepository
from .postgres_repository import PostgresCatalogRepository

def get_repository():
    backend = os.getenv("CATALOG_BACKEND", "demo").lower()
    if backend == "postgres":
        return PostgresCatalogRepository()
    return DemoCatalogRepository()
