
from .optimizer_v33 import optimize_with_time_value
from .scoring import score_plans

def optimize_personalized(
    items,
    stores,
    offers,
    origin,
    travel_profile="car",
    vehicle_cost_per_km=None,
    time_value_per_hour=None,
    min_saving_to_travel=3.0,
    max_stores=3,
    max_travel_minutes=None,
    weight_saving=0.50,
    weight_time=0.25,
    weight_simplicity=0.25,
    store_penalty_eur=0.75,
):
    base = optimize_with_time_value(
        items=items,
        stores=stores,
        offers=offers,
        origin=origin,
        travel_profile=travel_profile,
        vehicle_cost_per_km=vehicle_cost_per_km,
        time_value_per_hour=time_value_per_hour,
        min_saving_to_travel=min_saving_to_travel,
        max_stores=max_stores,
        max_travel_minutes=max_travel_minutes,
    )

    plans = score_plans(
        base["plans"],
        weight_saving=weight_saving,
        weight_time=weight_time,
        weight_simplicity=weight_simplicity,
        store_penalty_eur=store_penalty_eur,
    )

    if not plans:
        return base

    recommendation = plans[0]

    recommendation["reason"] = (
        f"Piano con miglior equilibrio personalizzato: score "
        f"{recommendation['personalized_score']:.2f}, "
        f"{len(recommendation['stores'])} supermercato/i."
    )

    base["recommendation"] = recommendation
    base["plans"] = plans
    return base
