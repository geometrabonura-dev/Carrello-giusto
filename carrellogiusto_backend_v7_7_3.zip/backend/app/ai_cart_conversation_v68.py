from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

from .catalog_match_v66 import resolve_catalog_item_v66

_ALLOWED_STRATEGIES = {"max_saving", "balanced", "max_comfort"}

def _norm(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())

@dataclass
class ConversationPreferencesV68:
    strategy: str = "balanced"
    max_stores: int = 3
    min_saving_to_travel: float = 3.0
    budget_cap: float | None = None

    def to_dict(self):
        return asdict(self)

@dataclass
class ConversationStateV68:
    items: list[dict[str, Any]] = field(default_factory=list)
    preferences: ConversationPreferencesV68 = field(
        default_factory=ConversationPreferencesV68
    )
    notes: list[str] = field(default_factory=list)

    def to_dict(self):
        return {
            "items": self.items,
            "preferences": self.preferences.to_dict(),
            "notes": self.notes,
        }

def state_from_dict(raw: dict[str, Any] | None) -> ConversationStateV68:
    raw = raw or {}
    prefs_raw = raw.get("preferences") or {}
    prefs = ConversationPreferencesV68(
        strategy=str(prefs_raw.get("strategy") or "balanced"),
        max_stores=int(prefs_raw.get("max_stores") or 3),
        min_saving_to_travel=float(
            prefs_raw.get("min_saving_to_travel") or 3.0
        ),
        budget_cap=(
            float(prefs_raw["budget_cap"])
            if prefs_raw.get("budget_cap") is not None
            else None
        ),
    )
    return ConversationStateV68(
        items=[dict(x) for x in (raw.get("items") or []) if isinstance(x, dict)],
        preferences=prefs,
        notes=[str(x) for x in (raw.get("notes") or [])],
    )

def _resolve_item(
    raw: dict[str, Any],
    *,
    user_id: str | None,
) -> dict[str, Any]:
    label = str(raw.get("label") or raw.get("name") or "").strip()
    preferred_brand = raw.get("preferred_brand")
    resolution = resolve_catalog_item_v66(
        label=label,
        preferred_brand=preferred_brand,
        user_id=user_id,
    )
    return {
        "product_key": resolution.product_key,
        "label": label,
        "quantity": max(float(raw.get("quantity") or 1.0), 0.001),
        "unit": str(raw.get("unit") or "piece"),
        "preferred_brand": preferred_brand,
        "allow_equivalents": bool(raw.get("allow_equivalents", True)),
        "constraints": list(raw.get("constraints") or []),
        "match_status": resolution.status,
        "match_confidence": resolution.confidence,
        "catalog_candidates": [
            candidate.to_dict() for candidate in resolution.candidates
        ],
    }

def _remove_match(item: dict[str, Any], action: dict[str, Any]) -> bool:
    target_key = action.get("product_key")
    if target_key and item.get("product_key") == target_key:
        return True

    target_label = _norm(action.get("label"))
    if target_label and (
        _norm(item.get("label")) == target_label
        or target_label in _norm(item.get("label"))
    ):
        return True

    return False

def apply_actions_v68(
    *,
    state: ConversationStateV68,
    actions: list[dict[str, Any]],
    user_id: str | None = None,
) -> ConversationStateV68:
    items = [dict(x) for x in state.items]
    prefs = ConversationPreferencesV68(**state.preferences.to_dict())
    notes = list(state.notes)

    for action in actions:
        if not isinstance(action, dict):
            continue
        action_type = str(action.get("type") or "").strip().lower()

        if action_type == "add_item":
            raw_item = action.get("item") or {}
            if raw_item.get("label") or raw_item.get("name"):
                items.append(_resolve_item(raw_item, user_id=user_id))

        elif action_type == "remove_item":
            items = [
                item for item in items
                if not _remove_match(item, action)
            ]

        elif action_type == "clear_cart":
            items = []

        elif action_type == "set_strategy":
            value = str(action.get("value") or "")
            if value in _ALLOWED_STRATEGIES:
                prefs.strategy = value

        elif action_type == "set_max_stores":
            value = int(action.get("value") or prefs.max_stores)
            prefs.max_stores = min(6, max(1, value))

        elif action_type == "set_min_saving":
            value = float(action.get("value") or 0.0)
            prefs.min_saving_to_travel = min(10.0, max(0.0, value))

        elif action_type == "set_budget":
            value = action.get("value")
            prefs.budget_cap = (
                max(float(value), 0.01) if value is not None else None
            )
            notes = [
                n for n in notes
                if not n.startswith("budget:")
            ]
            if prefs.budget_cap is not None:
                notes.append(
                    "budget: il tetto di spesa è un obiettivo conversazionale; "
                    "non modifica i prezzi reali e va verificato sul risultato "
                    "dell'ottimizzatore."
                )

    return ConversationStateV68(
        items=items,
        preferences=prefs,
        notes=notes,
    )

CONVERSATION_SYSTEM_PROMPT_V68 = """
Sei l'assistente conversazionale di CarrelloGiusto.

Ricevi lo stato corrente di una lista della spesa e un nuovo messaggio utente.
Devi restituire SOLO JSON con:
- "reply": breve risposta in italiano;
- "actions": lista di azioni strutturate.

Azioni consentite:
- add_item: {"type":"add_item","item":{label,quantity,unit,preferred_brand,allow_equivalents,constraints}}
- remove_item: {"type":"remove_item","label":"..."} oppure product_key
- clear_cart
- set_strategy: value = max_saving | balanced | max_comfort
- set_max_stores: value da 1 a 6
- set_min_saving: value da 0 a 10 euro
- set_budget: value numerico positivo oppure null

Non inventare prezzi, promozioni, EAN, disponibilità o product_key.
Non modificare direttamente effective_total, routing, freshness o verifica offerte.
Il backend applicherà deterministicamente le azioni.
""".strip()
