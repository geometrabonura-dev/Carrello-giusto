from __future__ import annotations

import os
from .ai_provider_openai_v66 import OpenAIResponsesClientV66

def build_ai_client_v66():
    provider = os.getenv("AI_PROVIDER", "openai").strip().lower()

    if provider in {"", "disabled", "none"}:
        return None

    if provider == "openai":
        client = OpenAIResponsesClientV66()
        return client if client.configured else None

    raise ValueError(f"AI_PROVIDER non supportato: {provider}")
