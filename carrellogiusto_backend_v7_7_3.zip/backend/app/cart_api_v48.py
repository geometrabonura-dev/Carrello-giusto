
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional

from .request_models_v43 import CartItemV43
from .cart_resolution_v45 import resolve_cart_items, CartValidationError
from .optimizer_input_v45 import to_optimizer_items
from .cart_offer_resolution_v46 import resolve_offer_coverage
from .optimizer_v46 import build_store_pricebook
from .store_enrichment_v47 import enrich_pricebook_with_store_coordinates
from .route_aware_optimizer_v48 import optimize_db_cart_v48
from .strategy_ranker_v48 import get_strategy
from .store_radius_v50 import filter_pricebook_by_radius
from .budget_evaluator_v69 import evaluate_budget_v69
from .budget_substitution_engine_v70 import (
    suggest_budget_substitutions_v70,
    build_budget_recovery_v70,
)
from .product_substitution_repository_v70 import (
    ProductSubstitutionRepositoryV70,
)

router = APIRouter(prefix="/v4/cart", tags=["cart-v4-8"])

class Origin(BaseModel):
    latitude: float
    longitude: float

class OptimizeCartV48Request(BaseModel):
    items: list[CartItemV43]
    origin: Origin
    travel_profile: str = "car"
    strategy: str = "balanced"
    radius_km: float = Field(default=10.0, ge=2.0, le=30.0)
    max_stores: int = Field(default=3, ge=1, le=6)
    min_saving_to_travel: float = 3.0
    vehicle_cost_per_km: Optional[float] = None
    time_value_per_hour: Optional[float] = None
    budget_cap: Optional[float] = Field(default=None, gt=0)

@router.post("/optimize-v48")
def optimize_cart_v48(payload: OptimizeCartV48Request):
    try:
        resolved = resolve_cart_items(payload.items)
    except CartValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    optimizer_items = to_optimizer_items(resolved)
    coverage = resolve_offer_coverage(optimizer_items)

    if coverage.missing:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "cart_incomplete",
                "message": "Non ci sono offerte utilizzabili per tutti i prodotti.",
                "missing_items": coverage.missing,
            },
        )

    pricebook = enrich_pricebook_with_store_coordinates(
        build_store_pricebook(coverage)
    )
    pricebook = filter_pricebook_by_radius(
        pricebook,
        {
            "latitude": payload.origin.latitude,
            "longitude": payload.origin.longitude,
        },
        payload.radius_km,
    )

    if not pricebook:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "no_stores_in_radius",
                "message": "Nessun supermercato con offerte nel raggio scelto.",
            },
        )

    result = optimize_db_cart_v48(
        pricebook=pricebook,
        product_keys=[i["product_key"] for i in optimizer_items],
        origin={
            "latitude": payload.origin.latitude,
            "longitude": payload.origin.longitude,
        },
        routing_provider=None,
        travel_profile=payload.travel_profile,
        max_stores=payload.max_stores,
        min_saving_to_travel=payload.min_saving_to_travel,
        vehicle_cost_per_km=payload.vehicle_cost_per_km,
        time_value_per_hour=payload.time_value_per_hour,
        strategy=payload.strategy,
    )

    if result is None:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "no_complete_plan",
                "message": "Nessuna combinazione copre tutto il carrello.",
            },
        )

    chosen = result["recommendation"]
    strategy = get_strategy(payload.strategy)

    budget_analysis = None
    if payload.budget_cap is not None:
        evaluation = evaluate_budget_v69(
            budget_cap=payload.budget_cap,
            recommendation=chosen,
            plans=result.get("plans") or [],
        )

        recovery = {
            "budget_gap": 0.0,
            "suggested_saving": 0.0,
            "can_close_gap": True,
            "substitutions": [],
        }

        if not evaluation.within_budget:
            substitutions = suggest_budget_substitutions_v70(
                recommendation=chosen,
                pricebook=pricebook,
                substitution_repo=ProductSubstitutionRepositoryV70(),
            )
            recovery = build_budget_recovery_v70(
                budget_gap=max(
                    chosen["effective_total"] - float(payload.budget_cap),
                    0.0,
                ),
                suggestions=substitutions,
            )

        budget_analysis = {
            **evaluation.to_dict(),
            "recovery": recovery,
            "principle": (
                "Solo sostituzioni approvate e con prezzo reale; "
                "nessuna alternativa inventata dall'AI."
            ),
        }

    return {
        "data_status": (
            "verified"
            if chosen["all_offers_verified"]
            else "unverified"
        ),
        "strategy": {
            "key": strategy.key,
            "label": strategy.label,
        },
        "budget_analysis": budget_analysis,
        **result,
        "explanation": {
            "headline": f"Strategia: {strategy.label}",
            "reasons": [
                (
                    f"Massimo {result['rule']['max_stores']} supermercati."
                ),
                (
                    f"Soglia minima per spostarti: "
                    f"€{result['rule']['min_saving_to_travel']:.2f}."
                ),
                (
                    "La strategia viene applicata solo ai piani già "
                    "ammissibili secondo la soglia di risparmio."
                ),
                (
                    f"Piano consigliato: {chosen['stores_count']} "
                    f"supermercato/i, totale effettivo "
                    f"€{chosen['effective_total']:.2f}."
                ),
            ],
        },
    }
