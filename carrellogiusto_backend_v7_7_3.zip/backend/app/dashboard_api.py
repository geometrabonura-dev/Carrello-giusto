
from fastapi import APIRouter
from .quality_dashboard import dashboard_summary

router = APIRouter(prefix="/v2/quality", tags=["quality"])

@router.get("/dashboard")
def dashboard():
    return dashboard_summary()
