from __future__ import annotations

from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

_TRUE_VALUES = {"1", "true", "t", "yes", "y", "si", "sì", "on"}
_FALSE_VALUES = {"0", "false", "f", "no", "n", "off", ""}

def parse_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value != 0

    text = str(value).strip().lower()
    if text in _TRUE_VALUES:
        return True
    if text in _FALSE_VALUES:
        return False
    raise ValueError(f"Valore booleano non valido: {value!r}")

def parse_decimal(value: Any, *, required: bool = False) -> float | None:
    if value in (None, ""):
        if required:
            raise ValueError("Valore numerico obbligatorio mancante.")
        return None

    if isinstance(value, (int, float, Decimal)):
        return float(value)

    text = str(value).strip().replace("\u00a0", "").replace("€", "")
    # Italian/European input: 1.234,56 -> 1234.56
    if "," in text:
        text = text.replace(".", "").replace(",", ".")

    try:
        return float(Decimal(text))
    except (InvalidOperation, ValueError) as exc:
        raise ValueError(f"Valore numerico non valido: {value!r}") from exc

def parse_datetime(value: Any) -> datetime | None:
    if value in (None, ""):
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        text = str(value).strip()
        # Common Italian date-only format.
        if re_fullmatch_date_it(text):
            day, month, year = text.split("/")
            dt = datetime(int(year), int(month), int(day), tzinfo=timezone.utc)
        else:
            text = text.replace("Z", "+00:00")
            try:
                dt = datetime.fromisoformat(text)
            except ValueError as exc:
                raise ValueError(f"Data/ora non valida: {value!r}") from exc

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt

def parse_datetime_iso(value: Any) -> str | None:
    dt = parse_datetime(value)
    return dt.isoformat() if dt is not None else None

def re_fullmatch_date_it(text: str) -> bool:
    parts = text.split("/")
    if len(parts) != 3:
        return False
    d, m, y = parts
    return (
        len(d) in {1, 2}
        and len(m) in {1, 2}
        and len(y) == 4
        and d.isdigit()
        and m.isdigit()
        and y.isdigit()
    )
