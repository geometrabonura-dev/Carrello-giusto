
from dataclasses import dataclass
from .db import get_conn

@dataclass
class FeedbackEvent:
    user_id: str
    choice_id: str | None
    feedback_type: str
    value: float | None = None
    note: str | None = None

ALLOWED_FEEDBACK = {
    "prefer_cheaper",
    "prefer_faster",
    "prefer_fewer_stores",
    "too_far",
    "too_slow",
    "too_many_stores",
    "good_choice",
}

def record_feedback(event: FeedbackEvent) -> str:
    if event.feedback_type not in ALLOWED_FEEDBACK:
        raise ValueError("feedback_type non valido")

    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO choice_feedback (
                    user_id, choice_id, feedback_type, value, note
                )
                VALUES (%s,%s,%s,%s,%s)
                RETURNING id::text
            """, (
                event.user_id,
                event.choice_id,
                event.feedback_type,
                event.value,
                event.note,
            ))
            feedback_id = cur.fetchone()[0]
        conn.commit()
    return feedback_id
