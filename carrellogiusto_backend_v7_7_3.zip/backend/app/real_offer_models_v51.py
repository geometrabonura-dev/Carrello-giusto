
from dataclasses import dataclass, asdict
from typing import Optional

@dataclass
class RealOfferInput:
    source_key: str
    store_external_ref: str
    product_key: Optional[str]
    ean: Optional[str]
    product_name: str
    brand: Optional[str]
    price: float
    regular_price: Optional[float]
    quantity: Optional[float]
    unit: Optional[str]
    valid_from: Optional[str]
    valid_to: Optional[str]
    loyalty_required: bool
    source_url: Optional[str]
    raw_payload: dict

@dataclass
class ImportDecision:
    accepted: bool
    verification_status: str
    reason: str
    product_match_confidence: float
    source_authorized: bool

    def to_dict(self):
        return asdict(self)
