
from .cart_resolution_v45 import resolve_cart_items
from .optimizer_input_v45 import to_optimizer_items

def resolve_for_optimizer(raw_items):
    """
    Punto unico da usare prima di entrare nell'optimizer.
    """
    resolved = resolve_cart_items(raw_items)
    return to_optimizer_items(resolved)
