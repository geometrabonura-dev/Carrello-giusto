
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from typing import Any
from .job_queue import DatabaseJobQueue
from .auth import require_admin
from .db import get_conn

router = APIRouter(prefix="/v2/jobs", tags=["jobs"])

class EnqueuePayload(BaseModel):
    job_type: str
    payload: dict[str, Any]
    max_attempts: int = 5

@router.post("", dependencies=[Depends(require_admin)])
def enqueue(payload: EnqueuePayload):
    queue = DatabaseJobQueue()
    job_id = queue.enqueue(
        payload.job_type,
        payload.payload,
        max_attempts=payload.max_attempts,
    )
    return {"job_id": job_id, "status": "pending"}

@router.get("/{job_id}", dependencies=[Depends(require_admin)])
def get_job(job_id: str):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    id::text, job_type, status, attempts, max_attempts,
                    last_error, created_at, started_at, finished_at
                FROM background_jobs
                WHERE id=%s
                """,
                (job_id,),
            )
            row = cur.fetchone()

    if not row:
        return {"found": False}

    return {
        "found": True,
        "id": row[0],
        "job_type": row[1],
        "status": row[2],
        "attempts": row[3],
        "max_attempts": row[4],
        "last_error": row[5],
        "created_at": row[6].isoformat() if row[6] else None,
        "started_at": row[7].isoformat() if row[7] else None,
        "finished_at": row[8].isoformat() if row[8] else None,
    }
