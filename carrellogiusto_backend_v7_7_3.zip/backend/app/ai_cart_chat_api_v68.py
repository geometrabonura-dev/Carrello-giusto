from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .ai_orchestrator_v64 import AIOrchestratorV64
from .ai_provider_factory_v66 import build_ai_client_v66
from .ai_cart_conversation_v68 import (
    CONVERSATION_SYSTEM_PROMPT_V68,
    apply_actions_v68,
    state_from_dict,
)

router = APIRouter(prefix="/v6/ai-cart", tags=["ai-cart-v6-8"])

class AICartChatRequestV68(BaseModel):
    user_id: str | None = Field(default=None, max_length=128)
    message: str = Field(min_length=1, max_length=2000)
    state: dict[str, Any] = Field(default_factory=dict)

def _safe_fallback(message: str, state: dict[str, Any]):
    return {
        "reply": (
            "In questo momento non riesco a interpretare la modifica con l'AI. "
            "La lista attuale non è stata cambiata."
        ),
        "state": state_from_dict(state).to_dict(),
        "used_ai": False,
        "actions_applied": [],
    }

@router.post("/chat")
def chat_ai_cart(payload: AICartChatRequestV68):
    current = state_from_dict(payload.state)
    orchestrator = AIOrchestratorV64(
        llm_client=build_ai_client_v66()
    )

    result = orchestrator.run(
        task="update_cart_conversation",
        system=CONVERSATION_SYSTEM_PROMPT_V68,
        user=json.dumps({
            "current_state": current.to_dict(),
            "message": payload.message,
        }, ensure_ascii=False),
    )

    if not result["ok"]:
        return _safe_fallback(payload.message, payload.state)

    try:
        data = json.loads(result["output"])
        if not isinstance(data, dict):
            raise ValueError("La risposta AI non è un oggetto JSON.")
        actions = data.get("actions") or []
        if not isinstance(actions, list):
            raise ValueError("Il campo actions non è una lista.")

        updated = apply_actions_v68(
            state=current,
            actions=actions,
            user_id=payload.user_id,
        )
        return {
            "reply": str(data.get("reply") or "Lista aggiornata."),
            "state": updated.to_dict(),
            "used_ai": True,
            "actions_applied": actions,
        }
    except (ValueError, TypeError, json.JSONDecodeError) as exc:
        raise HTTPException(
            status_code=502,
            detail={
                "code": "ai_chat_invalid",
                "message": str(exc),
            },
        )
