
from dataclasses import dataclass
from datetime import date
from decimal import Decimal
from typing import Optional, Iterable
from .db import get_conn
from .product_matcher import ProductMatcher
from .review_queue import enqueue_unmatched
from .source_quality_service import calculate_source_quality
from .quality_policy import QualityPolicy

@dataclass
class IncomingOffer:
    source_id: str
    external_store_ref: str
    external_product_ref: str
    product_name: str
    price: Decimal
    regular_price: Optional[Decimal] = None
    ean: Optional[str] = None
    brand: Optional[str] = None
    loyalty_required: bool = False
    valid_from: Optional[date] = None
    valid_to: Optional[date] = None
    source_url: Optional[str] = None
    raw_payload: Optional[dict] = None

class ImportPipeline:
    def __init__(self):
        self.matcher = ProductMatcher()
        self.policy = QualityPolicy()

    def start_run(self, source_id: str) -> str:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO import_runs (source_id, status)
                    VALUES (%s, 'running')
                    RETURNING id::text
                    """,
                    (source_id,),
                )
                run_id = cur.fetchone()[0]
            conn.commit()
        return run_id

    def finish_run(self, run_id: str, seen: int, imported: int, error: Optional[str] = None):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE import_runs
                    SET finished_at = NOW(),
                        status = %s,
                        records_seen = %s,
                        records_imported = %s,
                        error_message = %s
                    WHERE id = %s
                    """,
                    ("failed" if error else "completed", seen, imported, error, run_id),
                )
            conn.commit()

    def save_raw(self, run_id: str, offer: IncomingOffer):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO raw_offers (
                        import_run_id, external_store_ref, external_product_ref, payload
                    ) VALUES (%s, %s, %s, %s)
                    """,
                    (
                        run_id,
                        offer.external_store_ref,
                        offer.external_product_ref,
                        offer.raw_payload or {},
                    ),
                )
            conn.commit()

    def resolve_store_id(self, external_store_ref: str) -> Optional[str]:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id::text
                    FROM stores
                    WHERE external_ref = %s
                    LIMIT 1
                    """,
                    (external_store_ref,),
                )
                row = cur.fetchone()
                return row[0] if row else None

    def upsert_offer(
        self,
        offer: IncomingOffer,
        store_id: str,
        product_id: str,
        match_method: str,
        match_confidence: float,
        source_quality: float,
        verified: bool,
        source_status: str,
        quality_score: float,
        quality_reason: str,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO offers (
                        store_id, product_id, source_id, price, regular_price,
                        loyalty_required, valid_from, valid_to, source_status,
                        verified, active, source_url, checked_at,
                        match_method, match_confidence, source_quality_score,
                        quality_score, quality_reason
                    )
                    VALUES (
                        %s, %s, %s, %s, %s,
                        %s, %s, %s, %s,
                        %s, TRUE, %s, NOW(),
                        %s, %s, %s,
                        %s, %s
                    )
                    ON CONFLICT (store_id, product_id, source_id)
                    DO UPDATE SET
                        price = EXCLUDED.price,
                        regular_price = EXCLUDED.regular_price,
                        loyalty_required = EXCLUDED.loyalty_required,
                        valid_from = EXCLUDED.valid_from,
                        valid_to = EXCLUDED.valid_to,
                        source_status = EXCLUDED.source_status,
                        verified = EXCLUDED.verified,
                        active = TRUE,
                        source_url = EXCLUDED.source_url,
                        checked_at = NOW(),
                        match_method = EXCLUDED.match_method,
                        match_confidence = EXCLUDED.match_confidence,
                        source_quality_score = EXCLUDED.source_quality_score,
                        quality_score = EXCLUDED.quality_score,
                        quality_reason = EXCLUDED.quality_reason,
                        updated_at = NOW()
                    """,
                    (
                        store_id, product_id, offer.source_id,
                        offer.price, offer.regular_price,
                        offer.loyalty_required, offer.valid_from, offer.valid_to,
                        source_status, verified, offer.source_url,
                        match_method, match_confidence, source_quality,
                        quality_score, quality_reason,
                    ),
                )
            conn.commit()

    def import_offers(self, source_id: str, offers: Iterable[IncomingOffer]) -> dict:
        run_id = self.start_run(source_id)
        seen = imported = unmatched_products = unmatched_stores = 0
        fuzzy_matches = rejected_by_policy = verified_count = 0
        source_quality = calculate_source_quality(source_id)

        try:
            for offer in offers:
                seen += 1
                self.save_raw(run_id, offer)

                store_id = self.resolve_store_id(offer.external_store_ref)
                if not store_id:
                    unmatched_stores += 1
                    continue

                match = self.matcher.match(
                    product_name=offer.product_name,
                    ean=offer.ean,
                    brand=offer.brand,
                )

                if not match.product_id:
                    unmatched_products += 1
                    enqueue_unmatched(
                        import_run_id=run_id,
                        source_id=source_id,
                        external_store_ref=offer.external_store_ref,
                        external_product_ref=offer.external_product_ref,
                        product_name=offer.product_name,
                        ean=offer.ean,
                        brand=offer.brand,
                        best_candidate_name=match.matched_name,
                        match_confidence=match.confidence,
                    )
                    continue

                if match.method == "fuzzy":
                    fuzzy_matches += 1

                decision = self.policy.decide(
                    source_quality=source_quality,
                    match_confidence=match.confidence,
                )

                if not decision.accepted:
                    rejected_by_policy += 1

                if decision.verified:
                    verified_count += 1

                self.upsert_offer(
                    offer=offer,
                    store_id=store_id,
                    product_id=match.product_id,
                    match_method=match.method,
                    match_confidence=match.confidence,
                    source_quality=source_quality,
                    verified=decision.verified,
                    source_status=decision.status,
                    quality_score=decision.score,
                    quality_reason=decision.reason,
                )
                imported += 1

            self.finish_run(run_id, seen, imported)

            with get_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(
                        """
                        UPDATE sources
                        SET last_success_at = NOW()
                        WHERE id = %s
                        """,
                        (source_id,),
                    )
                conn.commit()

            return {
                "run_id": run_id,
                "seen": seen,
                "imported": imported,
                "verified": verified_count,
                "rejected_by_policy": rejected_by_policy,
                "unmatched_products": unmatched_products,
                "unmatched_stores": unmatched_stores,
                "fuzzy_matches": fuzzy_matches,
                "source_quality": source_quality,
            }
        except Exception as exc:
            self.finish_run(run_id, seen, imported, str(exc))
            raise
