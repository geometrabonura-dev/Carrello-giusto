
from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import Optional
from .user_preferences import UserPreferences, get_preferences, save_preferences

router = APIRouter(prefix="/v3/preferences", tags=["preferences"])

class PreferencesPayload(BaseModel):
    radius_km: float = Field(default=10.0, ge=2.0, le=30.0)
    travel_profile: str = "car"
    min_saving_to_travel: float = Field(default=3.0, ge=0.0, le=10.0)
    max_travel_minutes: Optional[float] = None
    max_stores: int = Field(default=3, ge=1, le=6)
    vehicle_cost_per_km: Optional[float] = None
    time_value_per_hour: Optional[float] = None
    weight_saving: float = 0.50
    weight_time: float = 0.25
    weight_simplicity: float = 0.25
    store_penalty_eur: float = 0.75

@router.get("/{user_id}")
def get_user_preferences(user_id: str):
    return get_preferences(user_id).__dict__

@router.put("/{user_id}")
def put_user_preferences(user_id: str, payload: PreferencesPayload):
    p = UserPreferences(user_id=user_id, **payload.model_dump())
    save_preferences(p)
    return p.__dict__
