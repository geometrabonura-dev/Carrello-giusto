
from dataclasses import dataclass
from datetime import datetime, timezone
from .feed_parsing_v62 import parse_datetime

@dataclass(frozen=True)
class FreshnessDecision:
    status: str
    usable: bool
    reason: str

def _parse_dt(value):
    return parse_datetime(value)

def evaluate_freshness(
    *,
    valid_from=None,
    valid_to=None,
    source_checked_at=None,
    max_age_hours=48,
    now=None,
):
    now = now or datetime.now(timezone.utc)
    vf = _parse_dt(valid_from)
    vt = _parse_dt(valid_to)
    checked = _parse_dt(source_checked_at)

    if vf and now < vf:
        return FreshnessDecision(
            status="not_yet_valid",
            usable=False,
            reason="L'offerta non è ancora valida.",
        )

    if vt and now > vt:
        return FreshnessDecision(
            status="expired",
            usable=False,
            reason="L'offerta è scaduta.",
        )

    if checked is None:
        return FreshnessDecision(
            status="stale",
            usable=False,
            reason="Manca la data di ultimo controllo della fonte.",
        )

    age_hours = (now - checked).total_seconds() / 3600.0
    if age_hours > max_age_hours:
        return FreshnessDecision(
            status="stale",
            usable=False,
            reason=f"Fonte non controllata da oltre {max_age_hours} ore.",
        )

    return FreshnessDecision(
        status="fresh",
        usable=True,
        reason="Offerta valida e sufficientemente recente.",
    )
