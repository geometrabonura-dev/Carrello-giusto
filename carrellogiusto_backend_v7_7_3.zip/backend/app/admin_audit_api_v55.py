
from fastapi import APIRouter, Depends
from .auth import require_admin

router = APIRouter(prefix="/admin/audit", tags=["admin-audit-v5-5"])

@router.get("", dependencies=[Depends(require_admin)])
def recent_audit(limit: int = 100):
    from .manual_audit_v55 import ManualAuditV55
    return ManualAuditV55().recent(limit=max(1, min(limit, 500)))
