from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

@dataclass(frozen=True)
class BudgetEvaluationV69:
    budget_cap: float
    recommended_total: float
    within_budget: bool
    difference: float
    best_plan_within_budget_key: str | None
    cheapest_eligible_plan_key: str | None
    cheapest_eligible_total: float | None

    def to_dict(self):
        return asdict(self)

def evaluate_budget_v69(
    *,
    budget_cap: float,
    recommendation: dict[str, Any],
    plans: list[dict[str, Any]],
) -> BudgetEvaluationV69:
    budget = max(float(budget_cap), 0.01)
    recommended_total = float(recommendation.get("effective_total") or 0.0)

    eligible = [
        p for p in plans
        if p.get("eligible_by_threshold", True)
        and p.get("effective_total") is not None
    ]
    eligible.sort(
        key=lambda p: (
            float(p.get("effective_total") or 0.0),
            int(p.get("stores_count") or 0),
            str(p.get("plan_key") or ""),
        )
    )

    within = [
        p for p in eligible
        if float(p.get("effective_total") or 0.0) <= budget
    ]

    cheapest = eligible[0] if eligible else None
    best_within = within[0] if within else None

    return BudgetEvaluationV69(
        budget_cap=round(budget, 2),
        recommended_total=round(recommended_total, 2),
        within_budget=recommended_total <= budget,
        difference=round(abs(recommended_total - budget), 2),
        best_plan_within_budget_key=(
            str(best_within.get("plan_key"))
            if best_within and best_within.get("plan_key") is not None
            else None
        ),
        cheapest_eligible_plan_key=(
            str(cheapest.get("plan_key"))
            if cheapest and cheapest.get("plan_key") is not None
            else None
        ),
        cheapest_eligible_total=(
            round(float(cheapest.get("effective_total")), 2)
            if cheapest else None
        ),
    )
