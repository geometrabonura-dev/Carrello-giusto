
class ReviewResolutionServiceV55:
    def __init__(
        self,
        *,
        review_repository,
        raw_review_repository,
        reprocess_service,
        audit,
    ):
        self.review_repository = review_repository
        self.raw_review_repository = raw_review_repository
        self.reprocess_service = reprocess_service
        self.audit = audit

    def resolve_store(
        self,
        *,
        review_id: str,
        source_key: str,
        external_ref: str,
        store_id: str,
        actor: str,
    ):
        self.review_repository.resolve_store_review(
            review_id=review_id,
            source_key=source_key,
            external_ref=external_ref,
            store_id=store_id,
        )

        payloads = self.raw_review_repository.payloads_for_resolved_mapping(
            source_key=source_key,
            external_ref=external_ref,
            review_type="store",
            limit=200,
        )

        result = None
        if payloads:
            result = self.reprocess_service.reprocess_payloads(
                source_key=source_key,
                payloads=payloads,
            )

        self.audit.log(
            actor=actor,
            action="resolve_store_review",
            entity_type="review",
            entity_id=review_id,
            source_key=source_key,
            details={
                "external_ref": external_ref,
                "store_id": store_id,
                "reprocessed_count": len(payloads),
            },
        )

        return {
            "status": "resolved",
            "review_id": review_id,
            "reprocessed_count": len(payloads),
            "reprocess_result": result,
        }

    def resolve_product(
        self,
        *,
        review_id: str,
        source_key: str,
        external_ref: str,
        product_id: str,
        actor: str,
    ):
        self.review_repository.resolve_product_review(
            review_id=review_id,
            source_key=source_key,
            external_ref=external_ref,
            product_id=product_id,
        )

        payloads = self.raw_review_repository.payloads_for_resolved_mapping(
            source_key=source_key,
            external_ref=external_ref,
            review_type="product",
            limit=200,
        )

        result = None
        if payloads:
            result = self.reprocess_service.reprocess_payloads(
                source_key=source_key,
                payloads=payloads,
            )

        self.audit.log(
            actor=actor,
            action="resolve_product_review",
            entity_type="review",
            entity_id=review_id,
            source_key=source_key,
            details={
                "external_ref": external_ref,
                "product_id": product_id,
                "reprocessed_count": len(payloads),
            },
        )

        return {
            "status": "resolved",
            "review_id": review_id,
            "reprocessed_count": len(payloads),
            "reprocess_result": result,
        }
