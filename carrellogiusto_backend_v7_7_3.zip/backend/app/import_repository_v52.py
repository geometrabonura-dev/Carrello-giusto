
import json
from .db import get_conn

class ImportRepositoryV52:
    def create_run(self, source_key: str, feed_name: str | None = None):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO offer_import_runs
                        (source_key, status, started_at, metrics)
                    VALUES (%s, 'running', NOW(), %s)
                    RETURNING id::text
                    """,
                    (
                        source_key,
                        json.dumps({"feed_name": feed_name}),
                    ),
                )
                return cur.fetchone()[0]

    def finish_run(self, run_id: str, status: str, metrics: dict):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE offer_import_runs
                    SET status=%s, finished_at=NOW(), metrics=%s
                    WHERE id::text=%s
                    """,
                    (status, json.dumps(metrics), run_id),
                )

    def resolve_store(self, *, source_key: str, external_ref: str):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT s.id::text, s.name
                    FROM stores s
                    JOIN store_sources ss ON ss.store_id = s.id
                    JOIN sources src ON src.id = ss.source_id
                    WHERE src.source_key=%s
                      AND ss.external_ref=%s
                    LIMIT 1
                    """,
                    (source_key, external_ref),
                )
                row = cur.fetchone()
        if not row:
            return None
        return {"id": row[0], "name": row[1]}

    def store_raw_offer(
        self,
        *,
        run_id: str,
        source_key: str,
        payload: dict,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO offer_raw
                        (import_run_id, source_key, raw_payload, imported_at)
                    VALUES (%s, %s, %s, NOW())
                    RETURNING id::text
                    """,
                    (run_id, source_key, json.dumps(payload)),
                )
                return cur.fetchone()[0]

    def upsert_offer(
        self,
        *,
        store_id: str,
        product_id: str,
        source_key: str,
        store_external_ref: str,
        price: float,
        regular_price: float | None,
        valid_from: str | None,
        valid_to: str | None,
        loyalty_required: bool,
        verification_status: str,
        verified: bool,
        source_url: str | None,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO offers (
                        store_id,
                        product_id,
                        price,
                        regular_price,
                        valid_from,
                        valid_to,
                        loyalty_required,
                        verified,
                        verification_status,
                        source_key,
                        store_external_ref,
                        source_url,
                        source_checked_at,
                        freshness_status
                    )
                    VALUES (
                        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW(),
                        'fresh'
                    )
                    ON CONFLICT (store_id, product_id)
                    DO UPDATE SET
                        price=EXCLUDED.price,
                        regular_price=EXCLUDED.regular_price,
                        valid_from=EXCLUDED.valid_from,
                        valid_to=EXCLUDED.valid_to,
                        loyalty_required=EXCLUDED.loyalty_required,
                        verified=EXCLUDED.verified,
                        verification_status=EXCLUDED.verification_status,
                        source_key=EXCLUDED.source_key,
                        store_external_ref=EXCLUDED.store_external_ref,
                        source_url=EXCLUDED.source_url,
                        source_checked_at=NOW(),
                        freshness_status='fresh'
                    RETURNING id::text
                    """,
                    (
                        store_id,
                        product_id,
                        price,
                        regular_price,
                        valid_from,
                        valid_to,
                        loyalty_required,
                        verified,
                        verification_status,
                        source_key,
                        store_external_ref,
                        source_url,
                    ),
                )
                return cur.fetchone()[0]

    def recent_runs(self, limit=50):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id::text, source_key, status, started_at, finished_at, metrics
                    FROM offer_import_runs
                    ORDER BY started_at DESC
                    LIMIT %s
                    """,
                    (limit,),
                )
                rows = cur.fetchall()

        return [
            {
                "id": r[0],
                "source_key": r[1],
                "status": r[2],
                "started_at": r[3].isoformat() if r[3] else None,
                "finished_at": r[4].isoformat() if r[4] else None,
                "metrics": r[5] or {},
            }
            for r in rows
        ]
