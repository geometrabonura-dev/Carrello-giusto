from __future__ import annotations

from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class ProductIdentityV63:
    ean_gtin: str | None
    product_key: str | None
    brand: str | None
    normalized_name: str | None
    quantity: float | None
    unit: str | None

def normalize_gtin(value: Any) -> str | None:
    if value in (None, ""):
        return None
    digits = "".join(ch for ch in str(value) if ch.isdigit())
    if len(digits) not in {8, 12, 13, 14}:
        return None
    return digits

def normalize_unit(value: Any) -> str | None:
    if value in (None, ""):
        return None
    v = str(value).strip().lower()
    aliases = {
        "g": "g",
        "gram": "g",
        "grams": "g",
        "grammo": "g",
        "grammi": "g",
        "kg": "kg",
        "kilogram": "kg",
        "kilograms": "kg",
        "kilogrammo": "kg",
        "kilogrammi": "kg",
        "ml": "ml",
        "milliliter": "ml",
        "milliliters": "ml",
        "l": "l",
        "lt": "l",
        "litro": "l",
        "litri": "l",
        "piece": "piece",
        "pezzo": "piece",
        "pack": "pack",
        "confezione": "pack",
    }
    return aliases.get(v, v)

def normalize_quantity(quantity: Any, unit: Any):
    if quantity in (None, ""):
        return None, normalize_unit(unit)
    q = float(quantity)
    u = normalize_unit(unit)
    if u == "g":
        return round(q / 1000.0, 6), "kg"
    if u == "ml":
        return round(q / 1000.0, 6), "l"
    return q, u

def normalize_name(value: Any) -> str | None:
    if value in (None, ""):
        return None
    return " ".join(str(value).strip().lower().split())

def variant_key(*, product_key=None, ean=None, brand=None, name=None, quantity=None, unit=None):
    gtin = normalize_gtin(ean)
    if gtin:
        return f"gtin:{gtin}"

    nq, nu = normalize_quantity(quantity, unit)
    parts = [
        f"pk:{product_key or ''}",
        f"brand:{(brand or '').strip().lower()}",
        f"name:{normalize_name(name) or ''}",
        f"qty:{'' if nq is None else nq}",
        f"unit:{nu or ''}",
    ]
    return "|".join(parts)
