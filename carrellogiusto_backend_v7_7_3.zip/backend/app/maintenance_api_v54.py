
from fastapi import APIRouter
from pydantic import BaseModel, Field

router = APIRouter(prefix="/v5/maintenance", tags=["maintenance-v5-4"])

class RefreshRequest(BaseModel):
    stale_after_hours: int = Field(default=48, ge=1, le=720)

@router.post("/offers/refresh-status")
def refresh_offer_statuses(payload: RefreshRequest):
    from .offer_maintenance_v54 import OfferMaintenanceV54
    return OfferMaintenanceV54().refresh_statuses(
        stale_after_hours=payload.stale_after_hours
    )
