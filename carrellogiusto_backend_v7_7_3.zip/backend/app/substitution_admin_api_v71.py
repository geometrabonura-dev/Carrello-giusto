from __future__ import annotations

from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field

from .auth import require_admin
from .product_substitution_admin_v71 import ProductSubstitutionAdminV71
from .ai_provider_factory_v66 import build_ai_client_v66
from .substitution_ai_candidate_v71 import suggest_from_closed_catalog_v71
from .admin_search_v56 import AdminSearchV56
from .substitution_preview_v72 import SubstitutionPreviewV72

router = APIRouter(
    prefix="/admin/substitutions-v71",
    tags=["admin-substitutions-v7-1"],
    dependencies=[Depends(require_admin)],
)

class ProposeV71(BaseModel):
    source_product_key: str = Field(min_length=1, max_length=200)
    alternative_product_key: str = Field(min_length=1, max_length=200)
    relation_type: str = Field(default="equivalent", max_length=80)
    note: str | None = Field(default=None, max_length=1000)

class ReviewActionV71(BaseModel):
    source_product_key: str = Field(min_length=1, max_length=200)
    alternative_product_key: str = Field(min_length=1, max_length=200)
    note: str | None = Field(default=None, max_length=1000)
    force: bool = False

class AISuggestV71(BaseModel):
    source_product_key: str = Field(min_length=1, max_length=200)
    candidate_product_keys: list[str] = Field(min_length=1, max_length=20)

@router.get("")
def list_substitutions(status: str | None = None, limit: int = 100):
    return ProductSubstitutionAdminV71().list(
        status=status or None,
        limit=limit,
    )

@router.post("/propose")
def propose_substitution(payload: ProposeV71):
    try:
        return ProductSubstitutionAdminV71().propose(
            source_product_key=payload.source_product_key,
            alternative_product_key=payload.alternative_product_key,
            relation_type=payload.relation_type,
            note=payload.note,
            proposed_by="manual_admin",
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

@router.get("/compatibility")
def compatibility(source_product_key: str, alternative_product_key: str):
    try:
        return ProductSubstitutionAdminV71().compatibility(
            source_product_key=source_product_key,
            alternative_product_key=alternative_product_key,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

@router.post("/approve")
def approve_substitution(
    payload: ReviewActionV71,
    x_admin_actor: str | None = Header(default=None),
):
    try:
        return ProductSubstitutionAdminV71().approve(
            source_product_key=payload.source_product_key,
            alternative_product_key=payload.alternative_product_key,
            actor=x_admin_actor or "admin",
            force=payload.force,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

@router.post("/reject")
def reject_substitution(
    payload: ReviewActionV71,
    x_admin_actor: str | None = Header(default=None),
):
    try:
        return ProductSubstitutionAdminV71().reject(
            source_product_key=payload.source_product_key,
            alternative_product_key=payload.alternative_product_key,
            actor=x_admin_actor or "admin",
            note=payload.note,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

@router.post("/suggest-ai")
def suggest_ai_candidate(payload: AISuggestV71):
    admin = ProductSubstitutionAdminV71()
    source = admin._product(payload.source_product_key)
    if source is None:
        raise HTTPException(status_code=422, detail="Prodotto sorgente inesistente.")

    candidates = []
    for key in payload.candidate_product_keys:
        product = admin._product(key)
        if product is not None and product["product_key"] != source["product_key"]:
            candidates.append(product)

    if not candidates:
        raise HTTPException(status_code=422, detail="Nessun candidato catalogo valido.")

    client = build_ai_client_v66()
    if client is None:
        raise HTTPException(status_code=503, detail="AI provider non configurato.")

    try:
        suggestion = suggest_from_closed_catalog_v71(
            llm_client=client,
            source=source,
            candidates=candidates,
        )
    except (ValueError, TypeError) as exc:
        raise HTTPException(status_code=502, detail=str(exc))

    key = suggestion.get("alternative_product_key")
    if not key:
        return {
            **suggestion,
            "queued": False,
            "principle": "Suggerimento AI advisory-only; nessuna approvazione automatica.",
        }

    admin.propose(
        source_product_key=source["product_key"],
        alternative_product_key=key,
        relation_type="ai_candidate",
        note=suggestion.get("reason"),
        proposed_by="ai_candidate",
    )

    return {
        **suggestion,
        "queued": True,
        "review_status": "pending",
        "principle": "Suggerimento AI advisory-only; richiede approvazione admin.",
    }


@router.get("/search-products")
def search_products(q: str, limit: int = 20):
    return AdminSearchV56().search_products(
        q=q,
        limit=max(1, min(limit, 50)),
    )

@router.get("/preview")
def preview_substitution(
    source_product_key: str,
    alternative_product_key: str,
):
    try:
        return SubstitutionPreviewV72().build(
            source_product_key=source_product_key,
            alternative_product_key=alternative_product_key,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
