
from html import escape
from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse
from .auth import require_admin

router = APIRouter(prefix="/admin/review-console", tags=["admin-review-console-v5-6"])

@router.get("", response_class=HTMLResponse, dependencies=[Depends(require_admin)])
def review_console():
    from .review_repository_v53 import ReviewRepositoryV53

    rows = ReviewRepositoryV53().pending(limit=200)
    cards = []

    for r in rows:
        payload = r.get("payload") or {}
        label = (
            payload.get("product_name")
            or payload.get("name")
            or payload.get("store_name")
            or r.get("external_ref")
            or ""
        )

        cards.append(
            f"""
            <section class="card"
              data-review-id="{escape(str(r.get('id') or ''))}"
              data-source-key="{escape(str(r.get('source_key') or ''))}"
              data-review-type="{escape(str(r.get('review_type') or ''))}"
              data-external-ref="{escape(str(r.get('external_ref') or ''))}">
              <h3>{escape(str(r.get('review_type') or '').upper())}</h3>
              <p><b>Fonte:</b> {escape(str(r.get('source_key') or ''))}</p>
              <p><b>Riferimento:</b> {escape(str(r.get('external_ref') or ''))}</p>
              <p><b>Descrizione:</b> {escape(str(label))}</p>

              <div class="actions">
                <input class="search" placeholder="Cerca target..." />
                <button onclick="searchTarget(this)">Cerca</button>
                <button onclick="retryReview(this)">Retry</button>
                <button class="danger" onclick="rejectReview(this)">Rifiuta</button>
              </div>

              <div class="results"></div>
            </section>
            """
        )

    html = """
    <html>
    <head>
      <title>CarrelloGiusto - Review Console</title>
      <style>
        body { font-family: sans-serif; margin: 0; background: #f7f7f7; }
        header { padding: 20px 28px; background: white; border-bottom: 1px solid #ddd; }
        main { padding: 24px; display: grid; gap: 16px; }
        .card { background: white; padding: 18px; border-radius: 12px; border: 1px solid #ddd; }
        .actions { display: flex; gap: 8px; flex-wrap: wrap; margin-top: 14px; }
        input { padding: 9px; min-width: 260px; }
        button { padding: 9px 12px; cursor: pointer; }
        .danger { color: #a00; }
        .candidate { padding: 8px; border-top: 1px solid #eee; display: flex; justify-content: space-between; gap: 12px; }
        code { font-size: 12px; }
      </style>
    </head>
    <body>
      <header>
        <h1>Review Console</h1>
        <p>Risolvi store/prodotti, ritenta una singola review o rifiutala.</p>
      </header>
      <main>
    """ + "".join(cards) + """
      </main>
      <script>
        function cardFrom(btn) {
          return btn.closest('.card');
        }

        async function searchTarget(btn) {
          const card = cardFrom(btn);
          const q = card.querySelector('.search').value.trim();
          if (!q) return;
          const type = card.dataset.reviewType;
          const endpoint = type === 'store'
            ? '/admin/review-actions/search/stores'
            : '/admin/review-actions/search/products';
          const response = await fetch(endpoint + '?q=' + encodeURIComponent(q), {
            headers: {'X-Admin-Token': localStorage.getItem('adminToken') || ''}
          });
          const data = await response.json();
          const target = card.querySelector('.results');
          target.innerHTML = '';
          for (const row of data) {
            const div = document.createElement('div');
            div.className = 'candidate';
            div.innerHTML = '<span>' +
              (row.name || '') + ' ' +
              (row.brand || row.city || '') +
              '</span><button>Usa</button>';
            div.querySelector('button').onclick = () => resolveCandidate(card, row.id);
            target.appendChild(div);
          }
        }

        async function resolveCandidate(card, targetId) {
          const type = card.dataset.reviewType;
          const endpoint = type === 'store'
            ? '/v5/reviews/resolve-store'
            : '/v5/reviews/resolve-product';
          const body = {
            review_id: card.dataset.reviewId,
            source_key: card.dataset.sourceKey,
            external_ref: card.dataset.externalRef
          };
          if (type === 'store') body.store_id = targetId;
          else body.product_id = targetId;

          const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
              'Content-Type':'application/json',
              'X-Admin-Token': localStorage.getItem('adminToken') || '',
              'X-Admin-Actor': 'browser-admin'
            },
            body: JSON.stringify(body)
          });
          if (response.ok) location.reload();
          else alert(await response.text());
        }

        async function retryReview(btn) {
          const card = cardFrom(btn);
          const response = await fetch('/admin/review-actions/retry', {
            method: 'POST',
            headers: {
              'Content-Type':'application/json',
              'X-Admin-Token': localStorage.getItem('adminToken') || '',
              'X-Admin-Actor': 'browser-admin'
            },
            body: JSON.stringify({
              source_key: card.dataset.sourceKey,
              external_ref: card.dataset.externalRef,
              review_type: card.dataset.reviewType,
              limit: 50
            })
          });
          alert(await response.text());
        }

        async function rejectReview(btn) {
          const card = cardFrom(btn);
          const reason = prompt('Motivo del rifiuto?');
          if (!reason) return;
          const response = await fetch('/admin/review-actions/reject', {
            method: 'POST',
            headers: {
              'Content-Type':'application/json',
              'X-Admin-Token': localStorage.getItem('adminToken') || '',
              'X-Admin-Actor': 'browser-admin'
            },
            body: JSON.stringify({
              review_id: card.dataset.reviewId,
              source_key: card.dataset.sourceKey,
              review_type: card.dataset.reviewType,
              external_ref: card.dataset.externalRef,
              reason: reason
            })
          });
          if (response.ok) location.reload();
          else alert(await response.text());
        }
      </script>
    </body>
    </html>
    """
    return HTMLResponse(html)
