
from dataclasses import dataclass
from typing import Optional

@dataclass(frozen=True)
class AuthorizedSource:
    key: str
    chain: str
    display_name: str
    source_type: str
    official: bool
    authorized_for_auto_verification: bool
    requires_store_scope: bool = True
    notes: Optional[str] = None

SOURCES = {
    "esselunga_official": AuthorizedSource(
        key="esselunga_official",
        chain="Esselunga",
        display_name="Esselunga - fonte ufficiale",
        source_type="official",
        official=True,
        authorized_for_auto_verification=False,
        requires_store_scope=True,
        notes=(
            "La fonte è ufficiale, ma l'auto-verifica è disabilitata "
            "finché non viene configurato un feed o accesso esplicitamente autorizzato."
        ),
    ),
    "conad_official": AuthorizedSource(
        key="conad_official",
        chain="Conad",
        display_name="Conad - fonte ufficiale",
        source_type="official",
        official=True,
        authorized_for_auto_verification=False,
        requires_store_scope=True,
        notes=(
            "Le offerte possono variare per punto vendita. "
            "Serve una sorgente autorizzata e store-specific."
        ),
    ),
}

def get_source(key: str) -> AuthorizedSource | None:
    return SOURCES.get(key)

def list_sources():
    return list(SOURCES.values())
