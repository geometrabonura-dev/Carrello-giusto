
from fastapi import APIRouter, Depends
from .auth import require_admin

router = APIRouter(prefix="/admin/release", tags=["release-v6-0"])

@router.get("/readiness", dependencies=[Depends(require_admin)])
def readiness():
    from .release_readiness_v60 import release_readiness
    return release_readiness(".")
