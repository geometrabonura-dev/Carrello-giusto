from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any, Callable

DETERMINISTIC_AUTHORITIES = {
    "price": "database_offers",
    "verification": "verification_policy",
    "freshness": "freshness_policy",
    "routing": "route_optimizer",
    "threshold": "optimizer_threshold_rule",
    "effective_total": "optimizer",
}

AI_ALLOWED_TASKS = {
    "parse_user_intent",
    "normalize_free_text",
    "suggest_product_matches",
    "explain_result",
    "triage_review",
    "summarize_import_errors",
    "update_cart_conversation",
}

AI_FORBIDDEN_TASKS = {
    "invent_price",
    "mark_offer_verified_without_policy",
    "override_freshness",
    "override_threshold",
    "override_route_cost",
    "override_effective_total",
}

@dataclass(frozen=True)
class AIActionV64:
    task: str
    allowed: bool
    reason: str

    def to_dict(self):
        return asdict(self)

def authorize_ai_task(task: str) -> AIActionV64:
    if task in AI_ALLOWED_TASKS:
        return AIActionV64(
            task=task,
            allowed=True,
            reason="Task consentito come supporto non autoritativo.",
        )
    if task in AI_FORBIDDEN_TASKS:
        return AIActionV64(
            task=task,
            allowed=False,
            reason="Task riservato a logica deterministica o policy verificabile.",
        )
    return AIActionV64(
        task=task,
        allowed=False,
        reason="Task AI non registrato.",
    )

class AIOrchestratorV64:
    """
    Thin orchestration layer.

    `llm_client` is optional and must expose:
        complete(system: str, user: str) -> str

    Without a configured client this class still provides deterministic
    policy/guardrails and can be used in tests and local development.
    """

    def __init__(self, llm_client=None):
        self.llm_client = llm_client

    def can(self, task: str) -> bool:
        return authorize_ai_task(task).allowed

    def run(self, *, task: str, system: str, user: str) -> dict[str, Any]:
        decision = authorize_ai_task(task)
        if not decision.allowed:
            return {
                "ok": False,
                "task": task,
                "reason": decision.reason,
                "output": None,
                "used_ai": False,
            }

        if self.llm_client is None:
            return {
                "ok": False,
                "task": task,
                "reason": "AI provider non configurato.",
                "output": None,
                "used_ai": False,
            }

        output = self.llm_client.complete(system=system, user=user)
        return {
            "ok": True,
            "task": task,
            "reason": decision.reason,
            "output": output,
            "used_ai": True,
        }
