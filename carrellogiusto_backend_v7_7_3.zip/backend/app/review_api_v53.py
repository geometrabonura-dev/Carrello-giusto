
from fastapi import APIRouter, HTTPException, Header, Depends
from pydantic import BaseModel

from .auth import require_admin

router = APIRouter(prefix="/v5/reviews", tags=["reviews-v5-3"])

class ResolveStoreRequest(BaseModel):
    review_id: str
    source_key: str
    external_ref: str
    store_id: str

class ResolveProductRequest(BaseModel):
    review_id: str
    source_key: str
    external_ref: str
    product_id: str

@router.get("")
def pending_reviews(review_type: str | None = None, limit: int = 100):
    from .review_repository_v53 import ReviewRepositoryV53
    if review_type not in (None, "store", "product"):
        raise HTTPException(
            status_code=422,
            detail="review_type deve essere store o product",
        )
    return ReviewRepositoryV53().pending(
        review_type=review_type,
        limit=max(1, min(limit, 200)),
    )

@router.post("/resolve-store", dependencies=[Depends(require_admin)])
def resolve_store(
    payload: ResolveStoreRequest,
    x_admin_actor: str = Header(default="admin"),
):
    from .review_repository_v53 import ReviewRepositoryV53
    from .raw_review_repository_v54 import RawReviewRepositoryV54
    from .raw_reprocess_v54 import RawReprocessServiceV54
    from .import_repository_v52 import ImportRepositoryV52
    from .product_match_adapter_v52 import ProductMatchAdapterV52
    from .source_product_mapping_v53 import SourceProductMappingV53
    from .manual_audit_v55 import ManualAuditV55
    from .review_resolution_service_v55 import ReviewResolutionServiceV55

    return ReviewResolutionServiceV55(
        review_repository=ReviewRepositoryV53(),
        raw_review_repository=RawReviewRepositoryV54(),
        reprocess_service=RawReprocessServiceV54(
            import_repository=ImportRepositoryV52(),
            product_matcher=ProductMatchAdapterV52(),
            review_repository=ReviewRepositoryV53(),
            product_mapping_repository=SourceProductMappingV53(),
        ),
        audit=ManualAuditV55(),
    ).resolve_store(
        review_id=payload.review_id,
        source_key=payload.source_key,
        external_ref=payload.external_ref,
        store_id=payload.store_id,
        actor=x_admin_actor,
    )

@router.post("/resolve-product", dependencies=[Depends(require_admin)])
def resolve_product(
    payload: ResolveProductRequest,
    x_admin_actor: str = Header(default="admin"),
):
    from .review_repository_v53 import ReviewRepositoryV53
    from .raw_review_repository_v54 import RawReviewRepositoryV54
    from .raw_reprocess_v54 import RawReprocessServiceV54
    from .import_repository_v52 import ImportRepositoryV52
    from .product_match_adapter_v52 import ProductMatchAdapterV52
    from .source_product_mapping_v53 import SourceProductMappingV53
    from .manual_audit_v55 import ManualAuditV55
    from .review_resolution_service_v55 import ReviewResolutionServiceV55

    return ReviewResolutionServiceV55(
        review_repository=ReviewRepositoryV53(),
        raw_review_repository=RawReviewRepositoryV54(),
        reprocess_service=RawReprocessServiceV54(
            import_repository=ImportRepositoryV52(),
            product_matcher=ProductMatchAdapterV52(),
            review_repository=ReviewRepositoryV53(),
            product_mapping_repository=SourceProductMappingV53(),
        ),
        audit=ManualAuditV55(),
    ).resolve_product(
        review_id=payload.review_id,
        source_key=payload.source_key,
        external_ref=payload.external_ref,
        product_id=payload.product_id,
        actor=x_admin_actor,
    )
