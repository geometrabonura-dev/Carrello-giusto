
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from .auth import require_admin

router = APIRouter(prefix="/admin/reviews-v57", tags=["admin-reviews-v5-7"])

class ReopenRequest(BaseModel):
    review_id: str
    source_key: str
    reason: str = Field(min_length=2, max_length=500)

@router.get("", dependencies=[Depends(require_admin)])
def list_reviews(
    status: str | None = "pending",
    review_type: str | None = None,
    source_key: str | None = None,
    q: str | None = None,
    limit: int = 50,
    offset: int = 0,
):
    if status not in (None, "pending", "resolved", "rejected"):
        raise HTTPException(status_code=422, detail="status non valido")
    if review_type not in (None, "store", "product"):
        raise HTTPException(status_code=422, detail="review_type non valido")

    from .review_query_v57 import ReviewQueryV57
    return ReviewQueryV57().list(
        status=status,
        review_type=review_type,
        source_key=source_key,
        q=q,
        limit=max(1, min(limit, 200)),
        offset=max(0, offset),
    )

@router.get("/metrics", dependencies=[Depends(require_admin)])
def metrics():
    from .review_metrics_v57 import ReviewMetricsV57
    return ReviewMetricsV57().summary()

@router.post("/reopen", dependencies=[Depends(require_admin)])
def reopen(
    payload: ReopenRequest,
    x_admin_actor: str = Header(default="admin"),
):
    from .review_repository_v53 import ReviewRepositoryV53
    from .manual_audit_v55 import ManualAuditV55
    from .review_state_actions_v57 import ReviewStateActionsV57

    return ReviewStateActionsV57(
        review_repository=ReviewRepositoryV53(),
        audit=ManualAuditV55(),
    ).reopen(
        review_id=payload.review_id,
        source_key=payload.source_key,
        actor=x_admin_actor,
        reason=payload.reason,
    )
