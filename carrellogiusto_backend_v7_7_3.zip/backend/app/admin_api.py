
from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse
from .quality_dashboard import dashboard_summary
from .auth import require_admin

router = APIRouter(prefix="/admin", tags=["admin"])

@router.get("", response_class=HTMLResponse, dependencies=[Depends(require_admin)])
def admin_home():
    data = dashboard_summary()
    o = data["overview"]

    source_rows = "".join(
        f"""
        <tr>
          <td>{s['chain_name']}</td>
          <td>{s['source_name']}</td>
          <td>{'Sì' if s['authorized'] else 'No'}</td>
          <td>{s['active_offers']}</td>
          <td>{s['verified_offers']}</td>
          <td>{s['completeness_score']:.2f}</td>
          <td>{s['historical_accuracy']:.2f}</td>
        </tr>
        """
        for s in data["sources"]
    )

    return f"""
    <!doctype html>
    <html lang="it">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>CarrelloGiusto — Data Quality</title>
      <style>
        body {{ font-family: system-ui, sans-serif; margin: 0; background: #f6f7f8; color: #202124; }}
        .wrap {{ max-width: 1100px; margin: auto; padding: 24px; }}
        .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 12px; margin-bottom: 24px; }}
        .card {{ background: white; border-radius: 14px; padding: 16px; box-shadow: 0 2px 8px rgba(0,0,0,.06); }}
        .value {{ font-size: 28px; font-weight: 700; }}
        table {{ width: 100%; border-collapse: collapse; background: white; border-radius: 14px; overflow: hidden; }}
        th, td {{ padding: 12px; border-bottom: 1px solid #eee; text-align: left; }}
        th {{ background: #f0f2f4; }}
      </style>
    </head>
    <body>
      <div class="wrap">
        <h1>CarrelloGiusto — Data Quality</h1>
        <div class="grid">
          <div class="card"><div>Offerte attive</div><div class="value">{o['active_offers']}</div></div>
          <div class="card"><div>Offerte verificate</div><div class="value">{o['verified_offers']}</div></div>
          <div class="card"><div>Verified ratio</div><div class="value">{o['verified_ratio']:.0%}</div></div>
          <div class="card"><div>Stale</div><div class="value">{o['stale_offers']}</div></div>
          <div class="card"><div>Da revisionare</div><div class="value">{o['review_offers']}</div></div>
          <div class="card"><div>Prodotti unmatched</div><div class="value">{o['pending_unmatched_products']}</div></div>
        </div>
        <h2>Fonti</h2>
        <table>
          <thead>
            <tr>
              <th>Catena</th><th>Fonte</th><th>Autorizzata</th>
              <th>Attive</th><th>Verificate</th><th>Completezza</th><th>Accuratezza</th>
            </tr>
          </thead>
          <tbody>{source_rows}</tbody>
        </table>
      </div>
    </body>
    </html>
    """
