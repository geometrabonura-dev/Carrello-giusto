
import csv
import io
import json
from typing import Iterable

def read_json_feed(payload: bytes) -> list[dict]:
    data = json.loads(payload.decode("utf-8"))
    if isinstance(data, dict):
        if "offers" in data and isinstance(data["offers"], list):
            data = data["offers"]
        else:
            data = [data]
    if not isinstance(data, list):
        raise ValueError("JSON feed must contain a list of offers.")
    return [dict(row) for row in data]

def read_csv_feed(payload: bytes) -> list[dict]:
    text = payload.decode("utf-8-sig")
    reader = csv.DictReader(io.StringIO(text))
    return [dict(row) for row in reader]

def read_feed(payload: bytes, content_type: str) -> list[dict]:
    c = (content_type or "").lower()
    if "json" in c:
        return read_json_feed(payload)
    if "csv" in c or "text/plain" in c:
        return read_csv_feed(payload)
    raise ValueError(f"Unsupported content type: {content_type}")
