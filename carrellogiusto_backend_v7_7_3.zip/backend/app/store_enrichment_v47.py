
from .db import get_conn

def enrich_pricebook_with_store_coordinates(pricebook):
    ids = list(pricebook.keys())
    if not ids:
        return pricebook

    placeholders = ",".join(["%s"] * len(ids))
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                SELECT id::text, latitude, longitude
                FROM stores
                WHERE id::text IN ({placeholders})
                """,
                tuple(ids),
            )
            rows = cur.fetchall()

    coords = {
        row[0]: {"lat": row[1], "lon": row[2]}
        for row in rows
    }

    for sid, store in pricebook.items():
        c = coords.get(sid)
        if c:
            store["lat"] = c["lat"]
            store["lon"] = c["lon"]

    return pricebook
