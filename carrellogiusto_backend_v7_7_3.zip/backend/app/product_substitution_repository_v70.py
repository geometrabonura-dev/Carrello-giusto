from __future__ import annotations

from dataclasses import dataclass

@dataclass(frozen=True)
class ApprovedSubstitutionV70:
    source_product_key: str
    alternative_product_key: str
    relation_type: str
    note: str | None

class ProductSubstitutionRepositoryV70:
    def _conn(self):
        from .db import get_conn
        return get_conn()

    def approved_for(self, source_product_key: str) -> list[ApprovedSubstitutionV70]:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        source_product_key,
                        alternative_product_key,
                        relation_type,
                        note
                    FROM product_substitutions
                    WHERE source_product_key = %s
                      AND approved = TRUE
                    ORDER BY alternative_product_key
                    """,
                    (source_product_key,),
                )
                rows = cur.fetchall()

        return [
            ApprovedSubstitutionV70(
                source_product_key=str(r[0]),
                alternative_product_key=str(r[1]),
                relation_type=str(r[2]),
                note=r[3],
            )
            for r in rows
        ]
