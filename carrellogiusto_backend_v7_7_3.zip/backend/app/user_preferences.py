
from dataclasses import dataclass, asdict
from typing import Optional
from .db import get_conn

@dataclass
class UserPreferences:
    user_id: str
    radius_km: float = 10.0
    travel_profile: str = "car"
    min_saving_to_travel: float = 3.0
    max_travel_minutes: Optional[float] = None
    max_stores: int = 3
    vehicle_cost_per_km: Optional[float] = None
    time_value_per_hour: Optional[float] = None
    weight_saving: float = 0.50
    weight_time: float = 0.25
    weight_simplicity: float = 0.25
    store_penalty_eur: float = 0.75

def get_preferences(user_id: str) -> UserPreferences:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT
                    user_id, radius_km, travel_profile, min_saving_to_travel,
                    max_travel_minutes, max_stores, vehicle_cost_per_km,
                    time_value_per_hour, weight_saving, weight_time,
                    weight_simplicity, store_penalty_eur
                FROM user_preferences
                WHERE user_id=%s
            """, (user_id,))
            row = cur.fetchone()

    if not row:
        return UserPreferences(user_id=user_id)

    return UserPreferences(
        user_id=row[0],
        radius_km=float(row[1]),
        travel_profile=row[2],
        min_saving_to_travel=float(row[3]),
        max_travel_minutes=float(row[4]) if row[4] is not None else None,
        max_stores=int(row[5]),
        vehicle_cost_per_km=float(row[6]) if row[6] is not None else None,
        time_value_per_hour=float(row[7]) if row[7] is not None else None,
        weight_saving=float(row[8]),
        weight_time=float(row[9]),
        weight_simplicity=float(row[10]),
        store_penalty_eur=float(row[11]),
    )

def save_preferences(p: UserPreferences):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO user_preferences (
                    user_id, radius_km, travel_profile, min_saving_to_travel,
                    max_travel_minutes, max_stores, vehicle_cost_per_km,
                    time_value_per_hour, weight_saving, weight_time,
                    weight_simplicity, store_penalty_eur
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT (user_id) DO UPDATE SET
                    radius_km=EXCLUDED.radius_km,
                    travel_profile=EXCLUDED.travel_profile,
                    min_saving_to_travel=EXCLUDED.min_saving_to_travel,
                    max_travel_minutes=EXCLUDED.max_travel_minutes,
                    max_stores=EXCLUDED.max_stores,
                    vehicle_cost_per_km=EXCLUDED.vehicle_cost_per_km,
                    time_value_per_hour=EXCLUDED.time_value_per_hour,
                    weight_saving=EXCLUDED.weight_saving,
                    weight_time=EXCLUDED.weight_time,
                    weight_simplicity=EXCLUDED.weight_simplicity,
                    store_penalty_eur=EXCLUDED.store_penalty_eur,
                    updated_at=NOW()
            """, (
                p.user_id, p.radius_km, p.travel_profile, p.min_saving_to_travel,
                p.max_travel_minutes, p.max_stores, p.vehicle_cost_per_km,
                p.time_value_per_hour, p.weight_saving, p.weight_time,
                p.weight_simplicity, p.store_penalty_eur
            ))
        conn.commit()
