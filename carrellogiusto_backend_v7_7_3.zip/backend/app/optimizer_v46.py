
from itertools import combinations
from .weighted_product_v63 import cost_for_weight

def _required_cost(item, offer):
    requested_qty = float(item.get("quantity", 1.0))
    requested_unit = str(item.get("unit") or "").strip().lower()
    offer_unit = str(getattr(offer, "unit", "") or "").strip().lower()

    # Weighted products: price is interpreted as €/kg when the cart/catalog unit is kg
    # and the offer unit is kg. This covers items such as Fiorentina sold by weight.
    if requested_unit == "kg" and offer_unit == "kg":
        return cost_for_weight(
            requested_kg=requested_qty,
            price_per_kg=float(offer.price),
        )

    pack_qty = float(offer.quantity or 1.0)
    if pack_qty <= 0:
        pack_qty = 1.0

    packs = int(-(-requested_qty // pack_qty))
    if packs < 1:
        packs = 1

    return {
        "packs": packs,
        "cost": round(packs * offer.price, 2),
        "supplied_quantity": round(packs * pack_qty, 3),
        "pricing_basis": "per_pack",
        "unit_price": round(float(offer.price), 4),
    }

def build_store_pricebook(coverage):
    """
    Converts covered cart offers into:
    {
      store_id: {
        "store_name": str,
        "items": {
          product_key: {offer/cost metadata}
        }
      }
    }
    """
    stores = {}

    for covered in coverage.covered:
        item = covered.item
        key = item["product_key"]

        for offer in covered.offers:
            calc = _required_cost(item, offer)

            store = stores.setdefault(
                offer.store_id,
                {
                    "store_id": offer.store_id,
                    "store_name": offer.store_name,
                    "items": {},
                },
            )

            current = store["items"].get(key)
            candidate = {
                "product_key": key,
                "product_name": item.get("name"),
                "brand": offer.brand,
                "offer_id": offer.offer_id,
                "unit_price": offer.price,
                "packs": calc["packs"],
                "supplied_quantity": calc["supplied_quantity"],
                "cost": calc["cost"],
                "pricing_basis": calc.get("pricing_basis", "per_pack"),
                "verified": offer.verified,
                "source_status": offer.source_status,
                "loyalty_required": offer.loyalty_required,
            }

            if current is None or candidate["cost"] < current["cost"]:
                store["items"][key] = candidate

    return stores

def optimize_price_only(coverage, max_stores=3):
    """
    v4.6 bridge optimizer:
    finds the cheapest complete basket across up to max_stores stores.
    Routing/time scoring remains handled by the existing route-aware optimizer
    in later integration. This function ensures DB offer selection is real.
    """
    stores = build_store_pricebook(coverage)
    product_keys = [c.item["product_key"] for c in coverage.covered]

    if not product_keys:
        return None

    candidates = []
    store_ids = list(stores.keys())

    for count in range(1, min(max_stores, len(store_ids)) + 1):
        for combo in combinations(store_ids, count):
            assignments = []
            total = 0.0
            complete = True

            for product_key in product_keys:
                choices = []
                for sid in combo:
                    entry = stores[sid]["items"].get(product_key)
                    if entry:
                        choices.append((entry["cost"], sid, entry))

                if not choices:
                    complete = False
                    break

                cost, sid, entry = min(choices, key=lambda x: x[0])
                assignments.append({
                    **entry,
                    "store_id": sid,
                    "store_name": stores[sid]["store_name"],
                })
                total += cost

            if complete:
                candidates.append({
                    "stores": [
                        {
                            "id": sid,
                            "name": stores[sid]["store_name"],
                        }
                        for sid in combo
                    ],
                    "assignments": assignments,
                    "product_total": round(total, 2),
                    "stores_count": len(combo),
                    "all_offers_verified": all(
                        bool(a["verified"]) for a in assignments
                    ),
                })

    if not candidates:
        return None

    candidates.sort(key=lambda x: (x["product_total"], x["stores_count"]))
    return candidates[0]
