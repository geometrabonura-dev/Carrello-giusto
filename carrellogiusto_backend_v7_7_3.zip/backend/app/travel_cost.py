
def calculate_travel_cost(distance_km: float, cost_per_km: float) -> float:
    return round(max(0.0, distance_km) * max(0.0, cost_per_km), 2)
