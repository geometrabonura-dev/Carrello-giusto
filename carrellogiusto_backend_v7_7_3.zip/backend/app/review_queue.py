
from .db import get_conn

def enqueue_unmatched(
    import_run_id: str,
    source_id: str,
    external_store_ref: str,
    external_product_ref: str,
    product_name: str,
    ean: str | None,
    brand: str | None,
    best_candidate_name: str | None,
    match_confidence: float,
):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                INSERT INTO unmatched_product_queue (
                    import_run_id,
                    source_id,
                    external_store_ref,
                    external_product_ref,
                    product_name,
                    ean,
                    brand,
                    best_candidate_name,
                    match_confidence,
                    status
                )
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,'pending')
                ON CONFLICT (source_id, external_product_ref)
                DO UPDATE SET
                    import_run_id = EXCLUDED.import_run_id,
                    product_name = EXCLUDED.product_name,
                    ean = EXCLUDED.ean,
                    brand = EXCLUDED.brand,
                    best_candidate_name = EXCLUDED.best_candidate_name,
                    match_confidence = EXCLUDED.match_confidence,
                    status = 'pending',
                    updated_at = NOW()
                """,
                (
                    import_run_id,
                    source_id,
                    external_store_ref,
                    external_product_ref,
                    product_name,
                    ean,
                    brand,
                    best_candidate_name,
                    match_confidence,
                ),
            )
        conn.commit()
