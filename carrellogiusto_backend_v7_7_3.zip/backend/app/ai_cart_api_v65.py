from __future__ import annotations

import json
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from .ai_cart_intent_v64 import build_parse_prompt
from .ai_orchestrator_v64 import AIOrchestratorV64
from .ai_provider_factory_v66 import build_ai_client_v66
from .catalog_match_v66 import resolve_catalog_item_v66
from .user_catalog_mapping_v67 import UserCatalogMappingRepositoryV67

router = APIRouter(prefix="/v6/ai-cart", tags=["ai-cart-v6-5"])

class AICartParseRequestV65(BaseModel):
    text: str = Field(min_length=2, max_length=2000)
    user_id: str | None = Field(default=None, min_length=1, max_length=128)

class AICartConfirmMappingRequestV67(BaseModel):
    user_id: str = Field(min_length=1, max_length=128)
    label: str = Field(min_length=1, max_length=300)
    preferred_brand: str | None = Field(default=None, max_length=200)
    product_key: str = Field(min_length=1, max_length=200)

class AICartParsedItemV65(BaseModel):
    product_key: str | None = None
    label: str
    quantity: float = Field(gt=0)
    unit: str
    preferred_brand: str | None = None
    allow_equivalents: bool = True
    constraints: list[str] = []
    match_status: str = "unmatched"
    match_confidence: float = 0.0
    catalog_candidates: list[dict[str, Any]] = []

class AICartParseResponseV65(BaseModel):
    raw_text: str
    items: list[AICartParsedItemV65]
    ambiguities: list[str]
    notes: list[str]
    requires_confirmation: bool = True
    used_ai: bool

def _fallback_parse(text: str) -> dict[str, Any]:
    """
    Safe fallback: preserve the request but do not invent product IDs.
    The client can present the text and force manual confirmation/editing.
    """
    chunks = [c.strip() for c in text.replace("\n", ",").split(",") if c.strip()]
    return {
        "raw_text": text,
        "items": [
            {
                "product_key": None,
                "label": chunk,
                "quantity": 1.0,
                "unit": "piece",
                "preferred_brand": None,
                "allow_equivalents": True,
                "constraints": [],
                "match_status": "unmatched",
                "match_confidence": 0.0,
                "catalog_candidates": [],
            }
            for chunk in chunks
        ],
        "ambiguities": [
            "AI non configurata: gli articoli richiedono conferma manuale."
        ],
        "notes": [],
        "requires_confirmation": True,
        "used_ai": False,
    }

def _parse_ai_json(
    output: str,
    raw_text: str,
    *,
    user_id: str | None = None,
) -> dict[str, Any]:
    try:
        data = json.loads(output)
    except Exception as exc:
        raise ValueError("Risposta AI non JSON.") from exc

    if not isinstance(data, dict) or not isinstance(data.get("items"), list):
        raise ValueError("Struttura AI non valida.")

    items = []
    for raw in data["items"]:
        if not isinstance(raw, dict):
            continue
        label = str(raw.get("label") or raw.get("name") or "").strip()
        if not label:
            continue
        preferred_brand = raw.get("preferred_brand")
        resolution = resolve_catalog_item_v66(
            label=label,
            preferred_brand=preferred_brand,
            user_id=user_id,
        )
        items.append({
            # Never trust an AI-supplied product_key. The catalog resolver
            # is the only authority that can populate this field.
            "product_key": resolution.product_key,
            "label": label,
            "quantity": float(raw.get("quantity") or 1.0),
            "unit": str(raw.get("unit") or "piece"),
            "preferred_brand": preferred_brand,
            "allow_equivalents": bool(raw.get("allow_equivalents", True)),
            "constraints": list(raw.get("constraints") or []),
            "match_status": resolution.status,
            "match_confidence": resolution.confidence,
            "catalog_candidates": [
                candidate.to_dict() for candidate in resolution.candidates
            ],
        })

    return {
        "raw_text": raw_text,
        "items": items,
        "ambiguities": list(data.get("ambiguities") or []),
        "notes": list(data.get("notes") or []),
        "requires_confirmation": any(
            item["product_key"] is None for item in items
        ),
        "used_ai": True,
    }

@router.post("/parse", response_model=AICartParseResponseV65)
def parse_ai_cart(payload: AICartParseRequestV65):
    orchestrator = AIOrchestratorV64(
        llm_client=build_ai_client_v66()
    )
    system, user = build_parse_prompt(payload.text)

    result = orchestrator.run(
        task="parse_user_intent",
        system=system + (
            "\nRestituisci SOLO JSON con chiavi: items, ambiguities, notes. "
            "Ogni item: label, quantity, unit, preferred_brand, "
            "allow_equivalents, constraints, product_key opzionale."
        ),
        user=user,
    )

    if not result["ok"]:
        return _fallback_parse(payload.text)

    try:
        return _parse_ai_json(
            result["output"],
            payload.text,
            user_id=payload.user_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=502, detail={
            "code": "ai_parse_invalid",
            "message": str(exc),
        })


@router.post("/confirm-mapping")
def confirm_ai_cart_mapping(payload: AICartConfirmMappingRequestV67):
    from .catalog_repository_v44 import CatalogRepositoryV44

    catalog = CatalogRepositoryV44()
    product = catalog.resolve_key(payload.product_key)
    if product is None:
        raise HTTPException(
            status_code=422,
            detail={
                "code": "unknown_product_key",
                "message": "Il prodotto selezionato non esiste nel catalogo.",
            },
        )

    saved = UserCatalogMappingRepositoryV67().save(
        user_id=payload.user_id,
        label=payload.label,
        preferred_brand=payload.preferred_brand,
        product_key=payload.product_key,
    )

    return {
        "status": "saved",
        "product_key": saved.product_key,
        "normalized_label": saved.normalized_label,
        "normalized_brand": saved.normalized_brand,
    }
