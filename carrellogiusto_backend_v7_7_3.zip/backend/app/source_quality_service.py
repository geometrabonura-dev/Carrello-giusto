
from datetime import datetime, timezone
from .db import get_conn
from .source_quality import SourceQuality

def calculate_source_quality(source_id: str) -> float:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    authorized,
                    COALESCE(completeness_score, 0.80),
                    COALESCE(historical_accuracy, 0.80),
                    last_success_at
                FROM sources
                WHERE id = %s
                """,
                (source_id,),
            )
            row = cur.fetchone()

    if not row:
        return 0.0

    authorized, completeness, accuracy, last_success_at = row

    if last_success_at:
        now = datetime.now(timezone.utc)
        freshness_hours = max(
            0.0,
            (now - last_success_at).total_seconds() / 3600.0
        )
    else:
        freshness_hours = 9999.0

    quality = SourceQuality(
        authorized=bool(authorized),
        freshness_hours=freshness_hours,
        completeness=float(completeness),
        historical_accuracy=float(accuracy),
    )
    return quality.score()
