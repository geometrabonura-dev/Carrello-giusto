
from .db import get_conn

class AdminSearchV56:
    def search_stores(self, q: str, limit: int = 20):
        like = f"%{q.strip()}%"
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id::text, name, address, city
                    FROM stores
                    WHERE name ILIKE %s
                       OR address ILIKE %s
                       OR city ILIKE %s
                    ORDER BY name ASC
                    LIMIT %s
                    """,
                    (like, like, like, limit),
                )
                rows = cur.fetchall()

        return [
            {
                "id": r[0],
                "name": r[1],
                "address": r[2],
                "city": r[3],
            }
            for r in rows
        ]

    def search_products(self, q: str, limit: int = 20):
        like = f"%{q.strip()}%"
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        id::text,
                        name,
                        brand,
                        ean,
                        product_key,
                        quantity,
                        unit,
                        gtin
                    FROM products
                    WHERE name ILIKE %s
                       OR COALESCE(brand, '') ILIKE %s
                       OR COALESCE(ean, '') ILIKE %s
                       OR COALESCE(product_key, '') ILIKE %s
                    ORDER BY name ASC
                    LIMIT %s
                    """,
                    (like, like, like, like, limit),
                )
                rows = cur.fetchall()

        return [
            {
                "id": r[0],
                "name": r[1],
                "brand": r[2],
                "ean": r[3],
                "product_key": r[4],
                "quantity": float(r[5]) if r[5] is not None else None,
                "unit": r[6],
                "gtin": r[7],
            }
            for r in rows
        ]
