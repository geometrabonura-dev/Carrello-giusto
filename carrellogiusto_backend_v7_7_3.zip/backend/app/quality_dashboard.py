
from .db import get_conn
from .metrics import ACTIVE_OFFERS, VERIFIED_OFFERS, UNMATCHED_PRODUCTS

def dashboard_summary():
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                SELECT
                    COUNT(*) FILTER (WHERE active = TRUE) AS active_offers,
                    COUNT(*) FILTER (WHERE verified = TRUE AND active = TRUE) AS verified_offers,
                    COUNT(*) FILTER (WHERE source_status = 'stale' AND active = TRUE) AS stale_offers,
                    COUNT(*) FILTER (WHERE source_status = 'needs_review' AND active = TRUE) AS review_offers,
                    AVG(match_confidence) FILTER (WHERE active = TRUE) AS avg_match_confidence,
                    AVG(source_quality_score) FILTER (WHERE active = TRUE) AS avg_source_quality,
                    AVG(quality_score) FILTER (WHERE active = TRUE) AS avg_quality_score
                FROM offers
            """)
            row = cur.fetchone()

            cur.execute("""
                SELECT COUNT(*)
                FROM unmatched_product_queue
                WHERE status = 'pending'
            """)
            pending_unmatched = cur.fetchone()[0]

            cur.execute("""
                SELECT
                    s.chain_name,
                    s.source_name,
                    s.authorized,
                    s.completeness_score,
                    s.historical_accuracy,
                    s.last_success_at,
                    COUNT(o.id) FILTER (WHERE o.active = TRUE) AS active_offers,
                    COUNT(o.id) FILTER (WHERE o.verified = TRUE AND o.active = TRUE) AS verified_offers
                FROM sources s
                LEFT JOIN offers o ON o.source_id = s.id
                GROUP BY
                    s.id, s.chain_name, s.source_name, s.authorized,
                    s.completeness_score, s.historical_accuracy, s.last_success_at
                ORDER BY s.chain_name, s.source_name
            """)
            source_rows = cur.fetchall()

    active = int(row[0] or 0)
    verified = int(row[1] or 0)
    unmatched = int(pending_unmatched or 0)

    ACTIVE_OFFERS.set(active)
    VERIFIED_OFFERS.set(verified)
    UNMATCHED_PRODUCTS.set(unmatched)

    return {
        "overview": {
            "active_offers": active,
            "verified_offers": verified,
            "verified_ratio": round(verified / active, 4) if active else 0.0,
            "stale_offers": int(row[2] or 0),
            "review_offers": int(row[3] or 0),
            "pending_unmatched_products": unmatched,
            "avg_match_confidence": round(float(row[4] or 0), 4),
            "avg_source_quality": round(float(row[5] or 0), 4),
            "avg_quality_score": round(float(row[6] or 0), 4),
        },
        "sources": [
            {
                "chain_name": r[0],
                "source_name": r[1],
                "authorized": bool(r[2]),
                "completeness_score": float(r[3] or 0),
                "historical_accuracy": float(r[4] or 0),
                "last_success_at": r[5].isoformat() if r[5] else None,
                "active_offers": int(r[6] or 0),
                "verified_offers": int(r[7] or 0),
            }
            for r in source_rows
        ],
    }
