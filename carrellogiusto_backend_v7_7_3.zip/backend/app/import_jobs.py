
from .import_pipeline import ImportPipeline, IncomingOffer
from decimal import Decimal
from datetime import date

def process_import_job(payload: dict):
    pipeline = ImportPipeline()
    source_id = payload["source_id"]
    offers = []

    for item in payload.get("offers", []):
        offers.append(
            IncomingOffer(
                source_id=source_id,
                external_store_ref=item["external_store_ref"],
                external_product_ref=item["external_product_ref"],
                product_name=item["product_name"],
                price=Decimal(str(item["price"])),
                regular_price=Decimal(str(item["regular_price"])) if item.get("regular_price") is not None else None,
                ean=item.get("ean"),
                brand=item.get("brand"),
                loyalty_required=bool(item.get("loyalty_required", False)),
                valid_from=date.fromisoformat(item["valid_from"]) if item.get("valid_from") else None,
                valid_to=date.fromisoformat(item["valid_to"]) if item.get("valid_to") else None,
                source_url=item.get("source_url"),
                raw_payload=item.get("raw_payload"),
            )
        )

    pipeline.import_offers(source_id, offers)
