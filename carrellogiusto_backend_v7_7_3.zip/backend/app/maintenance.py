
from .db import get_conn

def expire_old_offers() -> int:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE offers
                SET active = FALSE,
                    source_status = 'expired',
                    updated_at = NOW()
                WHERE active = TRUE
                  AND valid_to IS NOT NULL
                  AND valid_to < CURRENT_DATE
                """
            )
            count = cur.rowcount
        conn.commit()
    return count

def mark_stale_offers(hours: int = 48) -> int:
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE offers
                SET source_status = 'stale',
                    verified = FALSE,
                    updated_at = NOW()
                WHERE active = TRUE
                  AND checked_at IS NOT NULL
                  AND checked_at < NOW() - (%s || ' hours')::interval
                """,
                (hours,),
            )
            count = cur.rowcount
        conn.commit()
    return count
