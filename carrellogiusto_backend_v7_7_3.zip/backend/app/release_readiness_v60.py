
from pathlib import Path

def release_readiness(root: str = "."):
    base = Path(root)
    checks = []

    def add(name, ok, detail):
        checks.append({"name": name, "ok": bool(ok), "detail": detail})

    add(
        "backend_main",
        (base / "backend/app/main.py").exists(),
        "Backend entrypoint presente.",
    )
    add(
        "android_manifest",
        (base / "android/app/src/main/AndroidManifest.xml").exists(),
        "Manifest Android presente.",
    )
    add(
        "ios_info_plist",
        (base / "ios/Runner/Info.plist").exists(),
        "Info.plist iOS presente.",
    )
    add(
        "privacy_checklist",
        (base / "store_metadata/privacy_checklist.md").exists(),
        "Checklist privacy/store presente.",
    )
    add(
        "store_metadata",
        (base / "store_metadata/google_play_it.md").exists()
        and (base / "store_metadata/app_store_it.md").exists(),
        "Bozze metadata store presenti.",
    )
    add(
        "typed_errors",
        (base / "backend/app/api_errors_v60.py").exists(),
        "Error handling tipizzato disponibile.",
    )
    add(
        "scalable_routing",
        (base / "backend/app/route_ordering_v60.py").exists(),
        "Routing euristico disponibile per 5-6 store.",
    )

    passed = sum(1 for c in checks if c["ok"])
    return {
        "checks": checks,
        "passed": passed,
        "total": len(checks),
        "ready_for_internal_testing": passed == len(checks),
        "ready_for_store_submission": False,
        "store_submission_note": (
            "Richiede ancora build firmate, privacy policy pubblica, "
            "verifica permessi e configurazione store."
        ),
    }
