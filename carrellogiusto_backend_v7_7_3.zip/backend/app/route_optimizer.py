
from itertools import permutations
from .routing_service import RoutingService

def optimize_stop_order(origin: dict, stops: list[dict], profile: str = "driving"):
    """
    Exact permutation search for small stop counts (CarrelloGiusto currently max 3 stores).
    Returns the shortest round trip origin -> stops -> origin.
    """
    if not stops:
        return {
            "ordered_stops": [],
            "distance_km": 0.0,
            "duration_minutes": 0.0,
            "provider": "none",
            "verified": True,
        }

    service = RoutingService()
    best = None

    for perm in permutations(stops):
        route = service.estimate([origin, *perm, origin], profile=profile)
        candidate = {
            "ordered_stops": list(perm),
            "distance_km": route.distance_km,
            "duration_minutes": route.duration_minutes,
            "provider": route.provider,
            "verified": route.verified,
        }
        if best is None or candidate["distance_km"] < best["distance_km"]:
            best = candidate

    return best
