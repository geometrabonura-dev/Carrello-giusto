
from .db import get_conn

class OfferMaintenanceV54:
    def refresh_statuses(self, stale_after_hours=48):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE offers
                    SET source_status='expired'
                    WHERE valid_to IS NOT NULL
                      AND valid_to < NOW()
                      AND COALESCE(source_status, '') <> 'expired'
                    """
                )
                expired = cur.rowcount

                cur.execute(
                    """
                    UPDATE offers
                    SET source_status='stale'
                    WHERE source_checked_at IS NOT NULL
                      AND source_checked_at <
                          NOW() - (%s || ' hours')::interval
                      AND (valid_to IS NULL OR valid_to >= NOW())
                      AND COALESCE(source_status, '') NOT IN ('expired','rejected')
                    """,
                    (int(stale_after_hours),),
                )
                stale = cur.rowcount

                cur.execute(
                    """
                    UPDATE offers
                    SET source_status='active'
                    WHERE source_checked_at IS NOT NULL
                      AND source_checked_at >=
                          NOW() - (%s || ' hours')::interval
                      AND (valid_from IS NULL OR valid_from <= NOW())
                      AND (valid_to IS NULL OR valid_to >= NOW())
                      AND COALESCE(source_status, '') NOT IN ('rejected')
                    """,
                    (int(stale_after_hours),),
                )
                active = cur.rowcount

        return {
            "expired": expired,
            "stale": stale,
            "active": active,
            "stale_after_hours": stale_after_hours,
        }
