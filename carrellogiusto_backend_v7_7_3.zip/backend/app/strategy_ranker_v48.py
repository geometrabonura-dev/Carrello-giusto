
from dataclasses import dataclass

@dataclass(frozen=True)
class StrategyWeights:
    key: str
    label: str
    saving: float
    time: float
    simplicity: float
    store_penalty_eur: float

STRATEGIES = {
    "max_saving": StrategyWeights(
        key="max_saving",
        label="Massimo risparmio",
        saving=0.75,
        time=0.15,
        simplicity=0.10,
        store_penalty_eur=0.25,
    ),
    "balanced": StrategyWeights(
        key="balanced",
        label="Bilanciato",
        saving=0.50,
        time=0.25,
        simplicity=0.25,
        store_penalty_eur=0.75,
    ),
    "max_comfort": StrategyWeights(
        key="max_comfort",
        label="Massima comodità",
        saving=0.25,
        time=0.35,
        simplicity=0.40,
        store_penalty_eur=1.50,
    ),
}

def get_strategy(key: str):
    return STRATEGIES.get(key, STRATEGIES["balanced"])

def _normalize(value, min_v, max_v, inverse=False):
    if max_v <= min_v:
        return 1.0
    x = (value - min_v) / (max_v - min_v)
    score = 1.0 - x if inverse else x
    return max(0.0, min(1.0, score))

def rank_eligible_plans(plans, strategy_key="balanced"):
    """
    IMPORTANT:
    receives only plans already eligible under the € threshold.
    Therefore strategy ranking can never resurrect an ineligible farther plan.
    """
    strategy = get_strategy(strategy_key)
    if not plans:
        return None, []

    product_totals = [p["product_total"] for p in plans]
    durations = [
        p["duration_minutes"] if p["duration_minutes"] is not None else 10_000
        for p in plans
    ]
    store_counts = [p["stores_count"] for p in plans]

    pmin, pmax = min(product_totals), max(product_totals)
    tmin, tmax = min(durations), max(durations)
    smin, smax = min(store_counts), max(store_counts)

    ranked = []
    for p in plans:
        saving_score = _normalize(
            p["product_total"], pmin, pmax, inverse=True
        )
        time_score = _normalize(
            p["duration_minutes"] if p["duration_minutes"] is not None else tmax,
            tmin,
            tmax,
            inverse=True,
        )
        simplicity_score = _normalize(
            p["stores_count"], smin, smax, inverse=True
        )
        store_penalty = max(0, p["stores_count"] - 1) * strategy.store_penalty_eur

        score = (
            strategy.saving * saving_score
            + strategy.time * time_score
            + strategy.simplicity * simplicity_score
            - store_penalty / 100.0
        )

        ranked.append({
            **p,
            "strategy_score": round(score, 6),
            "store_penalty": round(store_penalty, 2),
            "strategy": strategy.key,
        })

    ranked.sort(
        key=lambda p: (
            -p["strategy_score"],
            p["effective_total"] + p["store_penalty"],
            p["stores_count"],
        )
    )
    return ranked[0], ranked
