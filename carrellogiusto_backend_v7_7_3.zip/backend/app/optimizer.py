
from itertools import combinations

def optimize(items, stores, offers, vehicle_cost_per_km=0.20,
             min_saving_to_travel=3.0, max_stores=3):
    prices = {(o.item_name, o.store_id): o.price for o in offers}
    plans = []

    if not stores:
        return {"plans": [], "recommendation": None}

    closest_store = min(stores, key=lambda s: s.distance_km)

    for n in range(1, min(max_stores, len(stores)) + 1):
        for combo in combinations(stores, n):
            combo_ids = {s.id for s in combo}
            if any(not any((item, sid) in prices for sid in combo_ids) for item in items):
                continue

            assignment = {}
            product_total = 0.0

            for item in items:
                candidates = [
                    (prices[(item, s.id)], s)
                    for s in combo
                    if (item, s.id) in prices
                ]
                price, store = min(candidates, key=lambda x: x[0])
                product_total += price
                assignment[item] = {
                    "store_name": store.name,
                    "price": round(price, 2),
                }

            # v2.2: approximate multi-stop travel with sum of store distances.
            distance = sum(s.distance_km for s in combo)
            travel_cost = round(distance * 2 * vehicle_cost_per_km, 2)

            plans.append({
                "stores": [s.name for s in combo],
                "store_count": len(combo),
                "product_total": round(product_total, 2),
                "travel_cost": travel_cost,
                "effective_total": round(product_total + travel_cost, 2),
                "distance_km": round(distance, 2),
                "assignment": assignment,
            })

    if not plans:
        return {"plans": [], "recommendation": None}

    closest_plan = min(
        (
            p for p in plans
            if p["store_count"] == 1
            and p["stores"] == [closest_store.name]
        ),
        key=lambda p: p["effective_total"],
        default=min(plans, key=lambda p: p["effective_total"]),
    )

    for p in plans:
        p["saving_vs_closest"] = round(
            closest_plan["effective_total"] - p["effective_total"], 2
        )

        if p is closest_plan:
            p["reason"] = "È la soluzione di riferimento più vicina."
            p["recommended"] = True
        elif p["saving_vs_closest"] >= min_saving_to_travel:
            p["reason"] = (
                f"Risparmia {p['saving_vs_closest']:.2f} € rispetto alla soluzione vicina "
                f"e supera la soglia di {min_saving_to_travel:.2f} €."
            )
            p["recommended"] = True
        else:
            p["reason"] = (
                f"Il vantaggio di {p['saving_vs_closest']:.2f} € non raggiunge "
                f"la soglia di {min_saving_to_travel:.2f} €."
            )
            p["recommended"] = False

    eligible = [p for p in plans if p["recommended"]]
    recommendation = min(eligible, key=lambda p: p["effective_total"])
    max_saving = min(plans, key=lambda p: p["product_total"])
    best_single = min(
        (p for p in plans if p["store_count"] == 1),
        key=lambda p: p["effective_total"],
        default=None,
    )

    return {
        "recommendation": recommendation,
        "closest_plan": closest_plan,
        "max_saving_plan": max_saving,
        "best_single_store": best_single,
        "plans": sorted(plans, key=lambda p: p["effective_total"]),
    }
