
import time
from dataclasses import dataclass

@dataclass
class CachedRoute:
    value: object
    expires_at: float

class RouteCache:
    def __init__(self, ttl_seconds: int = 900):
        self.ttl_seconds = ttl_seconds
        self._store = {}

    def _key(self, coordinates, profile):
        rounded = tuple(
            (round(float(c["latitude"]), 3), round(float(c["longitude"]), 3))
            for c in coordinates
        )
        return (profile, rounded)

    def get(self, coordinates, profile):
        key = self._key(coordinates, profile)
        item = self._store.get(key)
        if not item:
            return None
        if item.expires_at < time.time():
            self._store.pop(key, None)
            return None
        return item.value

    def set(self, coordinates, profile, value):
        self._store[self._key(coordinates, profile)] = CachedRoute(
            value=value,
            expires_at=time.time() + self.ttl_seconds,
        )
