
from dataclasses import dataclass

@dataclass(frozen=True)
class TravelProfile:
    key: str
    routing_profile: str
    cost_per_km: float
    default_time_value_per_hour: float

PROFILES = {
    "car": TravelProfile("car", "driving", 0.20, 8.0),
    "motorbike": TravelProfile("motorbike", "driving", 0.10, 8.0),
    "bike": TravelProfile("bike", "cycling", 0.0, 6.0),
    "walking": TravelProfile("walking", "walking", 0.0, 6.0),
}

def get_profile(key: str) -> TravelProfile:
    return PROFILES.get(key, PROFILES["car"])
