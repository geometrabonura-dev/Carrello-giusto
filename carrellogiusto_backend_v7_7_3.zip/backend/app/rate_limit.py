
import time
from collections import defaultdict, deque
from fastapi import Request
from fastapi.responses import JSONResponse

WINDOW_SECONDS = 60
MAX_REQUESTS = 120

_buckets = defaultdict(deque)

async def rate_limit_middleware(request: Request, call_next):
    if request.url.path in {"/health/live", "/health/ready", "/metrics"}:
        return await call_next(request)

    client_ip = request.client.host if request.client else "unknown"
    now = time.time()
    bucket = _buckets[client_ip]

    while bucket and bucket[0] < now - WINDOW_SECONDS:
        bucket.popleft()

    if len(bucket) >= MAX_REQUESTS:
        return JSONResponse(
            status_code=429,
            content={"detail": "Rate limit exceeded"},
        )

    bucket.append(now)
    return await call_next(request)
