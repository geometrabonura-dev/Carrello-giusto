
def to_optimizer_items(resolved_items):
    """
    Adapter tra il contratto v4.5 e gli optimizer esistenti.

    Mantiene le product_key canoniche e porta con sé le preferenze
    necessarie per matching/equivalenze.
    """
    return [
        {
            "product_key": item.product_key,
            "name": item.product_name,
            "brand": item.brand,
            "quantity": item.quantity,
            "unit": item.unit,
            "preferred_brand": item.preferred_brand,
            "allow_equivalents": item.allow_equivalents,
            "strict_brand": item.strict_brand,
        }
        for item in resolved_items
    ]
