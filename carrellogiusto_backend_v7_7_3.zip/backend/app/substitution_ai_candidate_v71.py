from __future__ import annotations

import json
from typing import Any

from .ai_orchestrator_v64 import AIOrchestratorV64

SYSTEM_PROMPT_V71 = """
Sei un assistente che propone SOLO candidati di sostituzione prodotto per revisione umana.
Ricevi un prodotto sorgente e una lista chiusa di prodotti candidati reali del catalogo.
Puoi scegliere solo un alternative_product_key presente nella lista.
Non approvare nulla, non inventare product_key, prezzi, EAN o disponibilità.
Restituisci SOLO JSON:
{"alternative_product_key":"...","reason":"...","confidence":0.0}
oppure {"alternative_product_key":null,"reason":"...","confidence":0.0}
""".strip()

def suggest_from_closed_catalog_v71(
    *,
    llm_client,
    source: dict[str, Any],
    candidates: list[dict[str, Any]],
) -> dict[str, Any]:
    orchestrator = AIOrchestratorV64(llm_client=llm_client)
    result = orchestrator.run(
        task="suggest_product_matches",
        system=SYSTEM_PROMPT_V71,
        user=json.dumps(
            {"source": source, "candidates": candidates},
            ensure_ascii=False,
        ),
    )
    if not result["ok"]:
        return {
            "ok": False,
            "alternative_product_key": None,
            "reason": result["reason"],
            "confidence": 0.0,
        }

    data = json.loads(result["output"])
    allowed = {str(c.get("product_key")) for c in candidates}
    key = data.get("alternative_product_key")
    if key is not None and str(key) not in allowed:
        raise ValueError("L'AI ha proposto un product_key fuori dalla lista chiusa.")

    return {
        "ok": True,
        "alternative_product_key": str(key) if key is not None else None,
        "reason": str(data.get("reason") or ""),
        "confidence": max(0.0, min(float(data.get("confidence") or 0.0), 1.0)),
    }
