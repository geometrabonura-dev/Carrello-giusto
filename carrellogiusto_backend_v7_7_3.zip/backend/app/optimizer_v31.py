
from itertools import combinations
from typing import List
from .route_matrix import estimate_round_trip
from .travel_cost import calculate_travel_cost

def optimize_with_routes(
    items,
    stores,
    offers,
    origin,
    vehicle_cost_per_km=0.20,
    min_saving_to_travel=3.0,
    max_stores=3,
    travel_profile="driving",
):
    if not stores:
        return {
            "recommendation": None,
            "closest_plan": None,
            "max_saving_plan": None,
            "best_single_store": None,
            "plans": [],
        }

    offer_map = {}
    for offer in offers:
        offer_map.setdefault(offer.item_name, []).append(offer)

    plans = []
    for count in range(1, min(max_stores, len(stores)) + 1):
        for combo in combinations(stores, count):
            combo_ids = {s.id for s in combo}
            assignments = []
            valid = True
            product_total = 0.0

            for item in items:
                candidates = [o for o in offer_map.get(item, []) if o.store_id in combo_ids]
                if not candidates:
                    valid = False
                    break
                best = min(candidates, key=lambda x: x.price)
                product_total += best.price
                assignments.append({
                    "item": item,
                    "store_id": best.store_id,
                    "price": round(best.price, 2),
                })

            if not valid:
                continue

            used_store_ids = []
            for a in assignments:
                if a["store_id"] not in used_store_ids:
                    used_store_ids.append(a["store_id"])

            used_stores = [next(s for s in combo if s.id == sid) for sid in used_store_ids]
            stops = [
                {
                    "latitude": float(getattr(s, "latitude")),
                    "longitude": float(getattr(s, "longitude")),
                }
                for s in used_stores
            ]

            route = estimate_round_trip(
                origin=origin,
                stops=stops,
                profile=travel_profile,
            )
            travel_cost = calculate_travel_cost(route.distance_km, vehicle_cost_per_km)
            effective_total = round(product_total + travel_cost, 2)

            plans.append({
                "stores": [{"id": s.id, "name": s.name} for s in used_stores],
                "assignments": assignments,
                "product_total": round(product_total, 2),
                "distance_km": route.distance_km,
                "duration_minutes": route.duration_minutes,
                "routing_provider": route.provider,
                "route_verified": route.verified,
                "travel_cost": travel_cost,
                "effective_total": effective_total,
            })

    if not plans:
        return {
            "recommendation": None,
            "closest_plan": None,
            "max_saving_plan": None,
            "best_single_store": None,
            "plans": [],
        }

    plans.sort(key=lambda p: p["effective_total"])

    closest_plan = min(plans, key=lambda p: p["distance_km"])
    best_effective = plans[0]
    max_saving = min(plans, key=lambda p: p["product_total"])
    single_store_plans = [p for p in plans if len(p["stores"]) == 1]
    best_single_store = min(single_store_plans, key=lambda p: p["effective_total"]) if single_store_plans else None

    for p in plans:
        p["saving_vs_closest"] = round(closest_plan["effective_total"] - p["effective_total"], 2)
        p["recommended"] = (
            p is closest_plan or
            p["saving_vs_closest"] >= min_saving_to_travel
        )
        p["reason"] = (
            "È il piano più vicino."
            if p is closest_plan
            else (
                f"Fa risparmiare €{p['saving_vs_closest']:.2f} rispetto al piano più vicino."
                if p["recommended"]
                else f"Il risparmio di €{p['saving_vs_closest']:.2f} non raggiunge la soglia di €{min_saving_to_travel:.2f}."
            )
        )

    recommendation = best_effective if best_effective["recommended"] else closest_plan

    return {
        "recommendation": recommendation,
        "closest_plan": closest_plan,
        "max_saving_plan": max_saving,
        "best_single_store": best_single_store,
        "plans": plans,
    }
