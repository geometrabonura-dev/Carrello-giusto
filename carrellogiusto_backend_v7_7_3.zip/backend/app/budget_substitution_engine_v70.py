from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

@dataclass(frozen=True)
class BudgetSubstitutionSuggestionV70:
    source_product_key: str
    source_label: str
    alternative_product_key: str
    alternative_label: str
    store_id: str
    store_name: str
    current_cost: float
    alternative_cost: float
    saving: float
    current_brand: str | None
    alternative_brand: str | None
    relation_type: str
    alternative_verified: bool
    loyalty_required: bool

    def to_dict(self):
        return asdict(self)

def _cost(entry: dict[str, Any]) -> float:
    return float(entry.get("cost") or 0.0)

def suggest_budget_substitutions_v70(
    *,
    recommendation: dict[str, Any],
    pricebook: dict[str, dict[str, Any]],
    substitution_repo,
    max_suggestions: int = 5,
) -> list[BudgetSubstitutionSuggestionV70]:
    """
    Suggest only explicitly approved product substitutions.

    Safety/accuracy rule:
    - alternative must be approved in product_substitutions;
    - alternative must have a real priced entry in a store already used by
      the recommended route;
    - comparison uses `cost`, i.e. the normalized required quantity cost;
    - same store means route/time cost does not need to be guessed/recomputed.
    """
    suggestions: list[BudgetSubstitutionSuggestionV70] = []

    assignments = recommendation.get("assignments") or []
    for current in assignments:
        source_key = str(current.get("product_key") or "")
        store_id = str(current.get("store_id") or "")
        if not source_key or not store_id:
            continue

        current_cost = _cost(current)
        if current_cost <= 0:
            continue

        store = pricebook.get(store_id) or {}
        items = store.get("items") or {}

        for relation in substitution_repo.approved_for(source_key):
            alternative = items.get(relation.alternative_product_key)
            if not alternative:
                continue

            alternative_cost = _cost(alternative)
            saving = round(current_cost - alternative_cost, 2)
            if saving <= 0:
                continue

            suggestions.append(
                BudgetSubstitutionSuggestionV70(
                    source_product_key=source_key,
                    source_label=str(
                        current.get("product_name")
                        or current.get("label")
                        or source_key
                    ),
                    alternative_product_key=relation.alternative_product_key,
                    alternative_label=str(
                        alternative.get("product_name")
                        or relation.alternative_product_key
                    ),
                    store_id=store_id,
                    store_name=str(
                        current.get("store_name")
                        or store.get("store_name")
                        or ""
                    ),
                    current_cost=round(current_cost, 2),
                    alternative_cost=round(alternative_cost, 2),
                    saving=saving,
                    current_brand=current.get("brand"),
                    alternative_brand=alternative.get("brand"),
                    relation_type=relation.relation_type,
                    alternative_verified=bool(alternative.get("verified")),
                    loyalty_required=bool(
                        alternative.get("loyalty_required")
                    ),
                )
            )

    suggestions.sort(
        key=lambda x: (
            -x.saving,
            x.source_product_key,
            x.alternative_product_key,
        )
    )
    return suggestions[:max(1, max_suggestions)]

def build_budget_recovery_v70(
    *,
    budget_gap: float,
    suggestions: list[BudgetSubstitutionSuggestionV70],
) -> dict[str, Any]:
    gap = max(float(budget_gap), 0.0)
    cumulative = 0.0
    selected = []

    for suggestion in suggestions:
        if cumulative >= gap:
            break
        selected.append(suggestion)
        cumulative = round(cumulative + suggestion.saving, 2)

    return {
        "budget_gap": round(gap, 2),
        "suggested_saving": round(cumulative, 2),
        "can_close_gap": cumulative >= gap if gap > 0 else True,
        "substitutions": [s.to_dict() for s in selected],
    }
