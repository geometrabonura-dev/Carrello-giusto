
class StoreMapperV52:
    def __init__(self, repository):
        self.repository = repository

    def resolve(self, source_key: str, external_ref: str):
        return self.repository.resolve_store(
            source_key=source_key,
            external_ref=external_ref,
        )
