
from dataclasses import dataclass
from typing import List, Optional

@dataclass(frozen=True)
class StoreRecord:
    id: str
    name: str
    distance_km: float
    source_status: str = "demo"

@dataclass(frozen=True)
class OfferRecord:
    item_name: str
    store_id: str
    price: float
    source_status: str = "demo"
    verified: bool = False

class CatalogRepository:
    def find_stores(self, radius_km: float, origin: Optional[dict] = None) -> List[StoreRecord]:
        raise NotImplementedError

    def find_offers(self, item_names: List[str], store_ids: List[str]) -> List[OfferRecord]:
        raise NotImplementedError

class DemoCatalogRepository(CatalogRepository):
    def find_stores(self, radius_km: float, origin: Optional[dict] = None) -> List[StoreRecord]:
        stores = [
            StoreRecord("near", "Supermercato vicino", 2.0),
            StoreRecord("a", "Supermercato A", 4.0),
            StoreRecord("b", "Supermercato B", 8.0),
            StoreRecord("c", "Supermercato C", 14.0),
        ]
        return [s for s in stores if s.distance_km <= radius_km]

    def find_offers(self, item_names: List[str], store_ids: List[str]) -> List[OfferRecord]:
        pricebook = {
            "Supermercato vicino": {
                "Pasta 1 kg": 2.40,
                "Olio 1 L": 6.90,
                "Rio Mare all'olio": 4.20,
                "Uva senza semi 1 kg": 3.80,
                "Fiorentina": 32.70,
            },
            "Supermercato A": {
                "Pasta 1 kg": 1.90,
                "Olio 1 L": 5.90,
                "Rio Mare all'olio": 3.99,
                "Uva senza semi 1 kg": 3.10,
                "Fiorentina": 33.01,
            },
            "Supermercato B": {
                "Pasta 1 kg": 1.60,
                "Olio 1 L": 5.20,
                "Rio Mare all'olio": 3.59,
                "Uva senza semi 1 kg": 2.98,
                "Fiorentina": 30.83,
            },
            "Supermercato C": {
                "Pasta 1 kg": 1.75,
                "Olio 1 L": 5.40,
                "Rio Mare all'olio": 3.80,
                "Uva senza semi 1 kg": 2.90,
                "Fiorentina": 31.50,
            },
        }
        id_to_name = {
            "near": "Supermercato vicino",
            "a": "Supermercato A",
            "b": "Supermercato B",
            "c": "Supermercato C",
        }
        out = []
        for sid in store_ids:
            store_name = id_to_name[sid]
            for item in item_names:
                if item in pricebook[store_name]:
                    out.append(
                        OfferRecord(
                            item_name=item,
                            store_id=sid,
                            price=pricebook[store_name][item],
                            source_status="demo",
                            verified=False,
                        )
                    )
        return out
