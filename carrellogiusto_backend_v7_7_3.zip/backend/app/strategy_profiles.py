
from dataclasses import dataclass

@dataclass(frozen=True)
class StrategyProfile:
    key: str
    label: str
    weight_saving: float
    weight_time: float
    weight_simplicity: float
    store_penalty_eur: float
    description: str

STRATEGIES = {
    "max_saving": StrategyProfile(
        key="max_saving",
        label="Massimo risparmio",
        weight_saving=0.75,
        weight_time=0.15,
        weight_simplicity=0.10,
        store_penalty_eur=0.25,
        description="Privilegia il prezzo finale anche se richiede più tempo o più negozi.",
    ),
    "balanced": StrategyProfile(
        key="balanced",
        label="Bilanciato",
        weight_saving=0.50,
        weight_time=0.25,
        weight_simplicity=0.25,
        store_penalty_eur=0.75,
        description="Bilancia risparmio, tempo e semplicità.",
    ),
    "max_comfort": StrategyProfile(
        key="max_comfort",
        label="Massima comodità",
        weight_saving=0.25,
        weight_time=0.35,
        weight_simplicity=0.40,
        store_penalty_eur=1.50,
        description="Riduce spostamenti, tempo e numero di supermercati.",
    ),
}

def get_strategy(key: str) -> StrategyProfile:
    return STRATEGIES.get(key, STRATEGIES["balanced"])
