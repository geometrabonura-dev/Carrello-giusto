
from itertools import combinations
from .route_optimizer import optimize_stop_order
from .travel_cost import calculate_travel_cost

def optimize_with_ordered_routes(
    items,
    stores,
    offers,
    origin,
    vehicle_cost_per_km=0.20,
    min_saving_to_travel=3.0,
    max_stores=3,
    travel_profile="driving",
    max_travel_minutes=None,
):
    if not stores:
        return {
            "recommendation": None,
            "closest_plan": None,
            "max_saving_plan": None,
            "best_single_store": None,
            "plans": [],
        }

    offer_map = {}
    for offer in offers:
        offer_map.setdefault(offer.item_name, []).append(offer)

    plans = []

    for count in range(1, min(max_stores, len(stores)) + 1):
        for combo in combinations(stores, count):
            combo_ids = {s.id for s in combo}
            assignments = []
            product_total = 0.0
            valid = True

            for item in items:
                candidates = [o for o in offer_map.get(item, []) if o.store_id in combo_ids]
                if not candidates:
                    valid = False
                    break
                best = min(candidates, key=lambda x: x.price)
                product_total += best.price
                assignments.append({
                    "item": item,
                    "store_id": best.store_id,
                    "price": round(best.price, 2),
                })

            if not valid:
                continue

            used_ids = []
            for a in assignments:
                if a["store_id"] not in used_ids:
                    used_ids.append(a["store_id"])

            used_stores = [next(s for s in combo if s.id == sid) for sid in used_ids]
            stop_nodes = [
                {
                    "id": s.id,
                    "name": s.name,
                    "latitude": float(s.latitude),
                    "longitude": float(s.longitude),
                }
                for s in used_stores
            ]

            route = optimize_stop_order(origin, stop_nodes, travel_profile)

            if (
                max_travel_minutes is not None
                and route["duration_minutes"] is not None
                and route["duration_minutes"] > max_travel_minutes
            ):
                continue

            travel_cost = calculate_travel_cost(
                route["distance_km"],
                vehicle_cost_per_km,
            )
            effective_total = round(product_total + travel_cost, 2)

            plans.append({
                "stores": [
                    {"id": s["id"], "name": s["name"]}
                    for s in route["ordered_stops"]
                ],
                "assignments": assignments,
                "product_total": round(product_total, 2),
                "distance_km": route["distance_km"],
                "duration_minutes": route["duration_minutes"],
                "routing_provider": route["provider"],
                "route_verified": route["verified"],
                "travel_cost": travel_cost,
                "effective_total": effective_total,
            })

    if not plans:
        return {
            "recommendation": None,
            "closest_plan": None,
            "max_saving_plan": None,
            "best_single_store": None,
            "plans": [],
        }

    plans.sort(key=lambda p: p["effective_total"])
    closest = min(plans, key=lambda p: p["distance_km"])
    max_saving = min(plans, key=lambda p: p["product_total"])
    singles = [p for p in plans if len(p["stores"]) == 1]
    best_single = min(singles, key=lambda p: p["effective_total"]) if singles else None

    for p in plans:
        p["saving_vs_closest"] = round(closest["effective_total"] - p["effective_total"], 2)
        p["recommended"] = (
            p is closest or
            p["saving_vs_closest"] >= min_saving_to_travel
        )
        if p is closest:
            p["reason"] = "È il piano con il tragitto più corto."
        elif p["recommended"]:
            p["reason"] = (
                f"Fa risparmiare €{p['saving_vs_closest']:.2f} rispetto al piano più vicino."
            )
        else:
            p["reason"] = (
                f"Il risparmio di €{p['saving_vs_closest']:.2f} non raggiunge "
                f"la soglia di €{min_saving_to_travel:.2f}."
            )

    best_effective = plans[0]
    recommendation = best_effective if best_effective["recommended"] else closest

    return {
        "recommendation": recommendation,
        "closest_plan": closest,
        "max_saving_plan": max_saving,
        "best_single_store": best_single,
        "plans": plans,
    }
