
class ProductMapperV52:
    def __init__(self, matcher):
        self.matcher = matcher

    def resolve(
        self,
        *,
        ean=None,
        product_key=None,
        product_name=None,
        brand=None,
    ):
        # Prefer exact identifiers first.
        if ean:
            result = self.matcher.match(ean=ean)
            if result:
                return result

        if product_key:
            result = self.matcher.match(product_key=product_key)
            if result:
                return result

        return self.matcher.match(
            name=product_name,
            brand=brand,
        )
