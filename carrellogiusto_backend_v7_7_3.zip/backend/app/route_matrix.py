
from dataclasses import dataclass
from typing import List
from .routing_service import RoutingService

@dataclass
class MatrixEntry:
    from_id: str
    to_id: str
    distance_km: float
    duration_minutes: float | None
    provider: str
    verified: bool

def build_pairwise_matrix(origin: dict, stores: List[dict], profile: str = "driving"):
    service = RoutingService()
    nodes = [{"id": "origin", **origin}, *stores]
    rows = []

    for a in nodes:
        for b in nodes:
            if a["id"] == b["id"]:
                continue
            route = service.estimate(
                [
                    {"latitude": a["latitude"], "longitude": a["longitude"]},
                    {"latitude": b["latitude"], "longitude": b["longitude"]},
                ],
                profile=profile,
            )
            rows.append(
                MatrixEntry(
                    from_id=a["id"],
                    to_id=b["id"],
                    distance_km=route.distance_km,
                    duration_minutes=route.duration_minutes,
                    provider=route.provider,
                    verified=route.verified,
                )
            )
    return rows
