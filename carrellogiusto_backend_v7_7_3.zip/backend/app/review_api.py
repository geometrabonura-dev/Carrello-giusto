
from fastapi import APIRouter
from pydantic import BaseModel
from .db import get_conn

router = APIRouter(prefix="/v2/review", tags=["review"])

class ResolveMatchPayload(BaseModel):
    product_id: str

@router.get("/unmatched")
def list_unmatched(limit: int = 100):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                SELECT
                    id::text,
                    product_name,
                    ean,
                    brand,
                    best_candidate_name,
                    match_confidence,
                    status
                FROM unmatched_product_queue
                WHERE status = 'pending'
                ORDER BY created_at ASC
                LIMIT %s
                """,
                (limit,),
            )
            rows = cur.fetchall()

    return [
        {
            "id": r[0],
            "product_name": r[1],
            "ean": r[2],
            "brand": r[3],
            "best_candidate_name": r[4],
            "match_confidence": float(r[5] or 0),
            "status": r[6],
        }
        for r in rows
    ]

@router.post("/unmatched/{queue_id}/resolve")
def resolve(queue_id: str, payload: ResolveMatchPayload):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE unmatched_product_queue
                SET resolved_product_id = %s,
                    status = 'resolved',
                    resolved_at = NOW(),
                    updated_at = NOW()
                WHERE id = %s
                """,
                (payload.product_id, queue_id),
            )
        conn.commit()
    return {"status": "resolved", "queue_id": queue_id}
