
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from .choice_history import ChoiceEvent, record_choice, recent_choices
from .feedback_service import FeedbackEvent, record_feedback, ALLOWED_FEEDBACK
from .preference_learning import (
    apply_feedback,
    learning_summary,
    reset_learning,
    suggest_strategy,
)

router = APIRouter(prefix="/v3/history", tags=["history"])

class ChoicePayload(BaseModel):
    user_id: str
    strategy: str
    chosen_plan_key: str
    recommended_plan_key: Optional[str] = None
    accepted_recommendation: bool = False
    stores_count: int
    product_total: float
    travel_cost: float
    time_cost: float
    effective_total: float
    duration_minutes: Optional[float] = None
    distance_km: Optional[float] = None

class FeedbackPayload(BaseModel):
    user_id: str
    choice_id: Optional[str] = None
    feedback_type: str
    value: Optional[float] = None
    note: Optional[str] = None
    apply_learning: bool = True

@router.post("/choices")
def create_choice(payload: ChoicePayload):
    event_id = record_choice(ChoiceEvent(**payload.model_dump()))
    return {"id": event_id, "recorded": True}

@router.get("/choices/{user_id}")
def get_choices(user_id: str, limit: int = 50):
    return {"choices": recent_choices(user_id, min(max(limit, 1), 100))}

@router.post("/feedback")
def create_feedback(payload: FeedbackPayload):
    if payload.feedback_type not in ALLOWED_FEEDBACK:
        raise HTTPException(status_code=422, detail="feedback_type non valido")

    feedback_id = record_feedback(
        FeedbackEvent(
            user_id=payload.user_id,
            choice_id=payload.choice_id,
            feedback_type=payload.feedback_type,
            value=payload.value,
            note=payload.note,
        )
    )

    updated = None
    if payload.apply_learning:
        updated = apply_feedback(payload.user_id, payload.feedback_type).__dict__

    return {
        "id": feedback_id,
        "recorded": True,
        "preferences_updated": updated,
        "suggested_strategy": suggest_strategy(payload.user_id),
    }

@router.get("/learning/{user_id}")
def get_learning(user_id: str):
    return learning_summary(user_id)

@router.get("/suggested-strategy/{user_id}")
def get_suggested_strategy(user_id: str):
    return suggest_strategy(user_id)

@router.post("/reset/{user_id}")
def reset_user_learning(user_id: str):
    prefs = reset_learning(user_id)
    return {
        "reset": True,
        "preferences": prefs.__dict__,
        "suggested_strategy": suggest_strategy(user_id),
    }
