
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import Optional

from .authorized_sources_v51 import list_sources, get_source
from .real_offer_models_v51 import RealOfferInput
from .real_feed_importer_v51 import RealFeedImporterV51

router = APIRouter(prefix="/v5/sources", tags=["sources-v5-1"])

class EvaluateOfferRequest(BaseModel):
    source_key: str
    store_external_ref: str
    product_key: Optional[str] = None
    ean: Optional[str] = None
    product_name: str
    brand: Optional[str] = None
    price: float = Field(gt=0)
    regular_price: Optional[float] = None
    quantity: Optional[float] = None
    unit: Optional[str] = None
    valid_from: Optional[str] = None
    valid_to: Optional[str] = None
    loyalty_required: bool = False
    source_url: Optional[str] = None
    raw_payload: dict = {}
    product_match_confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    store_resolved: bool = True

@router.get("")
def sources():
    return [
        {
            "key": s.key,
            "chain": s.chain,
            "display_name": s.display_name,
            "source_type": s.source_type,
            "official": s.official,
            "authorized_for_auto_verification":
                s.authorized_for_auto_verification,
            "requires_store_scope": s.requires_store_scope,
            "notes": s.notes,
        }
        for s in list_sources()
    ]

@router.get("/{source_key}")
def source(source_key: str):
    s = get_source(source_key)
    if s is None:
        raise HTTPException(status_code=404, detail="Fonte non registrata")
    return {
        "key": s.key,
        "chain": s.chain,
        "display_name": s.display_name,
        "source_type": s.source_type,
        "official": s.official,
        "authorized_for_auto_verification":
            s.authorized_for_auto_verification,
        "requires_store_scope": s.requires_store_scope,
        "notes": s.notes,
    }

@router.post("/evaluate-offer")
def evaluate_offer(payload: EvaluateOfferRequest):
    importer = RealFeedImporterV51()
    offer = RealOfferInput(
        source_key=payload.source_key,
        store_external_ref=payload.store_external_ref,
        product_key=payload.product_key,
        ean=payload.ean,
        product_name=payload.product_name,
        brand=payload.brand,
        price=payload.price,
        regular_price=payload.regular_price,
        quantity=payload.quantity,
        unit=payload.unit,
        valid_from=payload.valid_from,
        valid_to=payload.valid_to,
        loyalty_required=payload.loyalty_required,
        source_url=payload.source_url,
        raw_payload=payload.raw_payload,
    )
    return importer.evaluate_offer(
        offer,
        product_match_confidence=payload.product_match_confidence,
        store_resolved=payload.store_resolved,
    )
