from __future__ import annotations

import json
import os
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

class OpenAIResponsesClientV66:
    """
    Minimal dependency-free client for OpenAI Responses API.

    Environment:
      OPENAI_API_KEY   required
      AI_MODEL         optional, default gpt-5.6-luna
      OPENAI_BASE_URL  optional, default https://api.openai.com/v1
      AI_TIMEOUT_SECONDS optional, default 20

    The API key stays server-side and is never returned to Flutter.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        model: str | None = None,
        base_url: str | None = None,
        timeout_seconds: float | None = None,
    ):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.model = model or os.getenv("AI_MODEL", "gpt-5.6-luna")
        self.base_url = (
            base_url or os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
        ).rstrip("/")
        self.timeout_seconds = float(
            timeout_seconds
            if timeout_seconds is not None
            else os.getenv("AI_TIMEOUT_SECONDS", "20")
        )

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    def complete(self, *, system: str, user: str) -> str:
        if not self.api_key:
            raise RuntimeError("OPENAI_API_KEY non configurata.")

        body = json.dumps({
            "model": self.model,
            "input": [
                {
                    "role": "system",
                    "content": [{"type": "input_text", "text": system}],
                },
                {
                    "role": "user",
                    "content": [{"type": "input_text", "text": user}],
                },
            ],
        }).encode("utf-8")

        req = Request(
            f"{self.base_url}/responses",
            data=body,
            method="POST",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "CarrelloGiusto/6.6",
            },
        )

        try:
            with urlopen(req, timeout=self.timeout_seconds) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError) as exc:
            raise RuntimeError(f"Provider AI non raggiungibile: {exc}") from exc

        # Responses API may expose output_text in SDKs, while raw HTTP returns
        # structured output. Extract text conservatively from the structure.
        pieces = []
        for output in payload.get("output") or []:
            for content in output.get("content") or []:
                if content.get("type") == "output_text" and content.get("text"):
                    pieces.append(str(content["text"]))

        if not pieces:
            raise RuntimeError("Risposta AI priva di output testuale.")
        return "\n".join(pieces)
