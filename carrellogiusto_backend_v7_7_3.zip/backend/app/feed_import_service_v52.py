
from .authorized_sources_v51 import get_source
from .feed_reader_v52 import read_feed
from .product_match_adapter_v52 import ProductMatchAdapterV52
from .verification_policy_v51 import decide_verification
from .feed_parsing_v62 import parse_bool, parse_decimal, parse_datetime_iso

class FeedImportServiceV52:
    def __init__(
        self,
        repository=None,
        product_matcher=None,
    ):
        if repository is None:
            from .import_repository_v52 import ImportRepositoryV52
            repository = ImportRepositoryV52()
        self.repository = repository
        self.product_matcher = product_matcher or ProductMatchAdapterV52()

    def import_bytes(
        self,
        *,
        source_key: str,
        payload: bytes,
        content_type: str,
        feed_name: str | None = None,
    ):
        source = get_source(source_key)
        if source is None:
            raise ValueError("Fonte non registrata.")

        rows = read_feed(payload, content_type)
        run_id = self.repository.create_run(source_key, feed_name)

        metrics = {
            "received": len(rows),
            "accepted": 0,
            "verified": 0,
            "needs_review": 0,
            "rejected": 0,
            "unmatched_store": 0,
            "unmatched_product": 0,
        }

        try:
            for raw in rows:
                self.repository.store_raw_offer(
                    run_id=run_id,
                    source_key=source_key,
                    payload=raw,
                )

                store_ref = (
                    raw.get("store_external_ref")
                    or raw.get("store_id")
                    or raw.get("store")
                )
                store = None
                if store_ref:
                    store = self.repository.resolve_store(
                        source_key=source_key,
                        external_ref=str(store_ref),
                    )

                if not store:
                    metrics["unmatched_store"] += 1

                match = self.product_matcher.match(
                    ean=raw.get("ean"),
                    product_key=raw.get("product_key"),
                    name=raw.get("product_name") or raw.get("name"),
                    brand=raw.get("brand"),
                    quantity=raw.get("quantity"),
                    unit=raw.get("unit"),
                )

                if not match or not match.get("product_id"):
                    metrics["unmatched_product"] += 1
                    confidence = 0.0
                else:
                    confidence = float(match.get("confidence", 0.0))

                price = parse_decimal(raw.get("price"), required=True) or 0.0
                decision = decide_verification(
                    source_key=source_key,
                    product_match_confidence=confidence,
                    store_resolved=bool(store),
                    has_valid_price=price > 0,
                )

                if decision.verification_status == "verified":
                    metrics["verified"] += 1
                elif decision.verification_status == "needs_review":
                    metrics["needs_review"] += 1
                elif decision.verification_status == "rejected":
                    metrics["rejected"] += 1

                if (
                    decision.accepted
                    and store
                    and match
                    and match.get("product_id")
                ):
                    metrics["accepted"] += 1
                    self.repository.upsert_offer(
                        store_id=store["id"],
                        product_id=match["product_id"],
                        source_key=source_key,
                        store_external_ref=str(store_ref),
                        price=price,
                        regular_price=parse_decimal(raw.get("regular_price")),
                        valid_from=parse_datetime_iso(raw.get("valid_from")),
                        valid_to=parse_datetime_iso(raw.get("valid_to")),
                        loyalty_required=parse_bool(raw.get("loyalty_required"), default=False),
                        verification_status=decision.verification_status,
                        verified=decision.verification_status == "verified",
                        source_url=raw.get("source_url"),
                    )

            self.repository.finish_run(run_id, "completed", metrics)
            return {"run_id": run_id, "status": "completed", "metrics": metrics}

        except Exception:
            self.repository.finish_run(run_id, "failed", metrics)
            raise
