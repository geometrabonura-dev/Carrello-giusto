
from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse
from .auth import require_admin

router = APIRouter(prefix="/admin/imports", tags=["admin-imports-v5-2"])

@router.get("", response_class=HTMLResponse, dependencies=[Depends(require_admin)])
def imports_dashboard():
    from .import_repository_v52 import ImportRepositoryV52
    runs = ImportRepositoryV52().recent_runs(limit=50)

    rows = []
    for r in runs:
        m = r.get("metrics") or {}
        rows.append(
            "<tr>"
            f"<td>{r.get('started_at') or ''}</td>"
            f"<td>{r.get('source_key') or ''}</td>"
            f"<td>{r.get('status') or ''}</td>"
            f"<td>{m.get('received', 0)}</td>"
            f"<td>{m.get('accepted', 0)}</td>"
            f"<td>{m.get('verified', 0)}</td>"
            f"<td>{m.get('needs_review', 0)}</td>"
            f"<td>{m.get('rejected', 0)}</td>"
            "</tr>"
        )

    return HTMLResponse(
        """
        <html>
        <head><title>CarrelloGiusto - Import runs</title></head>
        <body>
          <h1>Import runs</h1>
          <table border="1" cellpadding="6" cellspacing="0">
            <tr>
              <th>Avvio</th>
              <th>Fonte</th>
              <th>Stato</th>
              <th>Ricevute</th>
              <th>Accettate</th>
              <th>Verificate</th>
              <th>Review</th>
              <th>Rifiutate</th>
            </tr>
            """ + "".join(rows) + """
          </table>
        </body>
        </html>
        """
    )
