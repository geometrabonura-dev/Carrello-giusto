
import logging
from pythonjsonlogger import jsonlogger
from .config import settings

def configure_logging():
    logger = logging.getLogger()
    logger.setLevel(settings.log_level)

    if logger.handlers:
        return

    handler = logging.StreamHandler()
    formatter = jsonlogger.JsonFormatter(
        "%(asctime)s %(levelname)s %(name)s %(message)s"
    )
    handler.setFormatter(formatter)
    logger.addHandler(handler)
