
from pydantic import BaseModel, Field
from typing import Optional

class CartItemV43(BaseModel):
    product_key: str
    quantity: float = Field(gt=0)
    unit: str
    preferred_brand: Optional[str] = None
    allow_equivalents: bool = True
