from __future__ import annotations

from dataclasses import dataclass
from typing import Any

def normalize_mapping_text(value: Any) -> str:
    return " ".join(str(value or "").strip().lower().split())

@dataclass(frozen=True)
class LearnedCatalogMappingV67:
    user_id: str
    normalized_label: str
    normalized_brand: str
    product_key: str

class UserCatalogMappingRepositoryV67:
    def _conn(self):
        from .db import get_conn
        return get_conn()

    def resolve(
        self,
        *,
        user_id: str,
        label: str,
        preferred_brand: str | None = None,
    ) -> str | None:
        normalized_label = normalize_mapping_text(label)
        normalized_brand = normalize_mapping_text(preferred_brand)

        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT product_key
                    FROM user_catalog_mappings
                    WHERE user_id = %s
                      AND normalized_label = %s
                      AND normalized_brand = %s
                    LIMIT 1
                    """,
                    (user_id, normalized_label, normalized_brand),
                )
                row = cur.fetchone()

        return str(row[0]) if row else None

    def save(
        self,
        *,
        user_id: str,
        label: str,
        preferred_brand: str | None,
        product_key: str,
    ) -> LearnedCatalogMappingV67:
        normalized_label = normalize_mapping_text(label)
        normalized_brand = normalize_mapping_text(preferred_brand)

        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO user_catalog_mappings(
                        user_id,
                        normalized_label,
                        normalized_brand,
                        product_key,
                        created_at,
                        updated_at
                    )
                    VALUES (%s, %s, %s, %s, NOW(), NOW())
                    ON CONFLICT (user_id, normalized_label, normalized_brand)
                    DO UPDATE SET
                        product_key = EXCLUDED.product_key,
                        updated_at = NOW()
                    """,
                    (
                        user_id,
                        normalized_label,
                        normalized_brand,
                        product_key,
                    ),
                )
            conn.commit()

        return LearnedCatalogMappingV67(
            user_id=user_id,
            normalized_label=normalized_label,
            normalized_brand=normalized_brand,
            product_key=product_key,
        )
