
import json
from .db import get_conn

class ManualAuditV55:
    def log(
        self,
        *,
        actor: str,
        action: str,
        entity_type: str,
        entity_id: str | None = None,
        source_key: str | None = None,
        details: dict | None = None,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO manual_audit_log (
                        actor,
                        action,
                        entity_type,
                        entity_id,
                        source_key,
                        details,
                        created_at
                    )
                    VALUES (%s,%s,%s,%s,%s,%s,NOW())
                    RETURNING id::text
                    """,
                    (
                        actor,
                        action,
                        entity_type,
                        entity_id,
                        source_key,
                        json.dumps(details or {}),
                    ),
                )
                return cur.fetchone()[0]

    def recent(self, limit=100):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id::text, actor, action, entity_type,
                           entity_id::text, source_key, details, created_at
                    FROM manual_audit_log
                    ORDER BY created_at DESC
                    LIMIT %s
                    """,
                    (limit,),
                )
                rows = cur.fetchall()

        return [
            {
                "id": r[0],
                "actor": r[1],
                "action": r[2],
                "entity_type": r[3],
                "entity_id": r[4],
                "source_key": r[5],
                "details": r[6] or {},
                "created_at": r[7].isoformat() if r[7] else None,
            }
            for r in rows
        ]
