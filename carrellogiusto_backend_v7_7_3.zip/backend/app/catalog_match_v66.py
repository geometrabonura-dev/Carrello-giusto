from __future__ import annotations

from dataclasses import dataclass, asdict
from difflib import SequenceMatcher


def _norm(value) -> str:
    return " ".join(str(value or "").strip().lower().split())

@dataclass(frozen=True)
class CatalogCandidateV66:
    product_key: str
    label: str
    brand: str | None
    unit: str
    confidence: float

    def to_dict(self):
        return asdict(self)

@dataclass(frozen=True)
class CatalogResolutionV66:
    status: str
    product_key: str | None
    confidence: float
    candidates: list[CatalogCandidateV66]

    def to_dict(self):
        return {
            "status": self.status,
            "product_key": self.product_key,
            "confidence": self.confidence,
            "candidates": [c.to_dict() for c in self.candidates],
        }

def _score(label: str, preferred_brand: str | None, row) -> float:
    name_score = SequenceMatcher(None, _norm(label), _norm(row.name)).ratio()

    if preferred_brand:
        if row.brand:
            brand_score = SequenceMatcher(
                None, _norm(preferred_brand), _norm(row.brand)
            ).ratio()
        else:
            brand_score = 0.0
        return round((name_score * 0.82) + (brand_score * 0.18), 4)

    return round(name_score, 4)

def resolve_catalog_item_v66(
    *,
    label: str,
    preferred_brand: str | None = None,
    repo=None,
    limit: int = 8,
    user_id: str | None = None,
    mapping_repo=None,
) -> CatalogResolutionV66:
    if repo is None:
        from .catalog_repository_v44 import CatalogRepositoryV44
        repo = CatalogRepositoryV44()

    if user_id:
        if mapping_repo is None:
            from .user_catalog_mapping_v67 import UserCatalogMappingRepositoryV67
            mapping_repo = UserCatalogMappingRepositoryV67()

        learned_key = mapping_repo.resolve(
            user_id=user_id,
            label=label,
            preferred_brand=preferred_brand,
        )
        if learned_key:
            learned = repo.resolve_key(learned_key)
            if learned is not None:
                learned_candidate = CatalogCandidateV66(
                    product_key=learned.product_key,
                    label=learned.name,
                    brand=learned.brand,
                    unit=learned.unit,
                    confidence=1.0,
                )
                return CatalogResolutionV66(
                    status="learned_mapping",
                    product_key=learned.product_key,
                    confidence=1.0,
                    candidates=[learned_candidate],
                )

    rows = repo.search(label, limit=limit)

    scored = sorted(
        [
            CatalogCandidateV66(
                product_key=row.product_key,
                label=row.name,
                brand=row.brand,
                unit=row.unit,
                confidence=_score(label, preferred_brand, row),
            )
            for row in rows
        ],
        key=lambda x: (-x.confidence, x.product_key),
    )

    if not scored:
        return CatalogResolutionV66(
            status="unmatched",
            product_key=None,
            confidence=0.0,
            candidates=[],
        )

    best = scored[0]
    second_conf = scored[1].confidence if len(scored) > 1 else 0.0
    gap = best.confidence - second_conf

    # Auto-resolution is intentionally conservative: high score and clear gap.
    if best.confidence >= 0.97 and gap >= 0.08:
        return CatalogResolutionV66(
            status="auto_resolved",
            product_key=best.product_key,
            confidence=best.confidence,
            candidates=scored[:3],
        )

    return CatalogResolutionV66(
        status="needs_confirmation",
        product_key=None,
        confidence=best.confidence,
        candidates=scored[:3],
    )
