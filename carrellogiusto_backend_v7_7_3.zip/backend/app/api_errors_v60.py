
from dataclasses import dataclass

@dataclass(frozen=True)
class ApiErrorV60(Exception):
    code: str
    message: str
    status_code: int = 400
    details: dict | None = None

def classify_http_error(status_code: int, payload: dict | None = None):
    payload = payload or {}
    detail = payload.get("detail", payload)
    if isinstance(detail, dict):
        code = detail.get("code")
        message = detail.get("message") or detail.get("detail") or str(detail)
    else:
        code = None
        message = str(detail)

    if status_code == 409 and code in {
        "cart_incomplete",
        "no_complete_plan",
        "no_stores_in_radius",
    }:
        return ApiErrorV60(code=code, message=message, status_code=status_code, details=payload)

    if status_code == 422:
        return ApiErrorV60(
            code=code or "validation_error",
            message=message or "Dati non validi",
            status_code=status_code,
            details=payload,
        )

    if status_code >= 500:
        return ApiErrorV60(
            code=code or "server_error",
            message=message or "Errore del server",
            status_code=status_code,
            details=payload,
        )

    return ApiErrorV60(
        code=code or "api_error",
        message=message or "Errore API",
        status_code=status_code,
        details=payload,
    )

def should_fallback_to_demo(error: Exception) -> bool:
    if isinstance(error, ApiErrorV60):
        return error.status_code in {408, 429} or error.code in {
            "network_error",
            "timeout",
            "temporary_unavailable",
        }
    return False
