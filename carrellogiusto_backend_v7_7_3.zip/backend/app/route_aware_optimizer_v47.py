
from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from math import inf
from typing import Any

from .travel_profiles import get_profile
from .route_optimizer import optimize_stop_order

@dataclass(frozen=True)
class PlanCandidate:
    stores: list[dict[str, Any]]
    assignments: list[dict[str, Any]]
    product_total: float
    distance_km: float
    duration_minutes: float | None
    travel_cost: float
    time_cost: float
    effective_total: float
    stores_count: int
    route_verified: bool
    routing_provider: str
    all_offers_verified: bool
    plan_key: str

def _plan_key(stores, assignments):
    store_ids = sorted(str(s["id"]) for s in stores)
    assignment_bits = sorted(
        f'{a["product_key"]}:{a["store_id"]}:{a.get("offer_id","")}'
        for a in assignments
    )
    return "|".join(store_ids) + "::" + "|".join(assignment_bits)

def _assign_products_to_combo(pricebook, product_keys, combo):
    assignments = []
    total = 0.0

    for product_key in product_keys:
        choices = []
        for sid in combo:
            entry = pricebook[sid]["items"].get(product_key)
            if entry:
                choices.append((entry["cost"], sid, entry))

        if not choices:
            return None

        cost, sid, entry = min(choices, key=lambda x: x[0])
        assignments.append({
            **entry,
            "store_id": sid,
            "store_name": pricebook[sid]["store_name"],
        })
        total += float(cost)

    return assignments, round(total, 2)

def _route_for_combo(origin, store_rows, routing_provider, travel_profile):
    if not store_rows:
        return {
            "distance_km": 0.0,
            "duration_minutes": 0.0,
            "verified": True,
            "provider": "none",
        }

    coords = []
    for store in store_rows:
        lat = store.get("lat")
        lon = store.get("lon")
        if lat is None or lon is None:
            return {
                "distance_km": 0.0,
                "duration_minutes": None,
                "verified": False,
                "provider": "missing_coordinates",
            }
        coords.append((float(lat), float(lon)))

    try:
        stops = [
            {"latitude": lat, "longitude": lon}
            for lat, lon in coords
        ]
        summary = optimize_stop_order(
            origin={
                "latitude": float(origin["latitude"]),
                "longitude": float(origin["longitude"]),
            },
            stops=stops,
            profile=travel_profile,
        )
        return {
            "distance_km": round(float(summary["distance_km"]), 3),
            "duration_minutes": (
                round(float(summary["duration_minutes"]), 2)
                if summary["duration_minutes"] is not None else None
            ),
            "verified": bool(summary["verified"]),
            "provider": str(summary["provider"]),
        }
    except Exception:
        return {
            "distance_km": 0.0,
            "duration_minutes": None,
            "verified": False,
            "provider": "routing_unavailable",
        }

def optimize_db_cart_route_aware(
    *,
    pricebook: dict[str, dict[str, Any]],
    product_keys: list[str],
    origin: dict[str, float],
    routing_provider,
    travel_profile: str = "car",
    max_stores: int = 3,
    min_saving_to_travel: float = 3.0,
    vehicle_cost_per_km: float | None = None,
    time_value_per_hour: float | None = None,
):
    profile = get_profile(travel_profile)
    cost_per_km = (
        float(vehicle_cost_per_km)
        if vehicle_cost_per_km is not None
        else float(profile.cost_per_km)
    )
    value_per_hour = (
        float(time_value_per_hour)
        if time_value_per_hour is not None
        else float(profile.default_time_value_per_hour)
    )

    store_ids = list(pricebook.keys())
    candidates: list[PlanCandidate] = []

    for count in range(1, min(max_stores, len(store_ids)) + 1):
        for combo in combinations(store_ids, count):
            assigned = _assign_products_to_combo(pricebook, product_keys, combo)
            if assigned is None:
                continue

            assignments, product_total = assigned
            stores = []
            for sid in combo:
                src = pricebook[sid]
                stores.append({
                    "id": sid,
                    "name": src["store_name"],
                    "lat": src.get("lat"),
                    "lon": src.get("lon"),
                })

            route = _route_for_combo(
                origin, stores, routing_provider, travel_profile
            )

            distance_km = float(route["distance_km"])
            duration_minutes = route["duration_minutes"]
            travel_cost = round(distance_km * cost_per_km, 2)
            time_cost = round(
                ((duration_minutes or 0.0) / 60.0) * value_per_hour,
                2,
            )
            effective_total = round(
                product_total + travel_cost + time_cost, 2
            )

            candidates.append(
                PlanCandidate(
                    stores=stores,
                    assignments=assignments,
                    product_total=product_total,
                    distance_km=distance_km,
                    duration_minutes=duration_minutes,
                    travel_cost=travel_cost,
                    time_cost=time_cost,
                    effective_total=effective_total,
                    stores_count=len(stores),
                    route_verified=bool(route["verified"]),
                    routing_provider=route["provider"],
                    all_offers_verified=all(
                        bool(a.get("verified")) for a in assignments
                    ),
                    plan_key=_plan_key(stores, assignments),
                )
            )

    if not candidates:
        return None

    closest = min(
        candidates,
        key=lambda p: (
            p.distance_km,
            p.effective_total,
            p.stores_count,
        ),
    )
    max_saving = min(
        candidates,
        key=lambda p: (
            p.product_total,
            p.effective_total,
            p.stores_count,
        ),
    )
    single_store_candidates = [p for p in candidates if p.stores_count == 1]
    single_store = (
        min(single_store_candidates, key=lambda p: p.effective_total)
        if single_store_candidates else None
    )

    # IMPORTANT: the closest plan is always eligible. A farther plan must save
    # at least min_saving_to_travel versus the closest effective total.
    eligible = []
    for p in candidates:
        saving_vs_closest = round(
            closest.effective_total - p.effective_total, 2
        )
        is_closest = p.plan_key == closest.plan_key
        if is_closest or saving_vs_closest >= float(min_saving_to_travel):
            eligible.append((p, saving_vs_closest))

    recommended = min(
        eligible,
        key=lambda row: (
            row[0].effective_total,
            row[0].stores_count,
            row[0].distance_km,
        ),
    )[0]

    def serialize(p: PlanCandidate | None):
        if p is None:
            return None
        saving_vs_closest = round(
            closest.effective_total - p.effective_total, 2
        )
        return {
            "plan_key": p.plan_key,
            "stores": p.stores,
            "assignments": p.assignments,
            "product_total": p.product_total,
            "distance_km": p.distance_km,
            "duration_minutes": p.duration_minutes,
            "travel_cost": p.travel_cost,
            "time_cost": p.time_cost,
            "effective_total": p.effective_total,
            "stores_count": p.stores_count,
            "route_verified": p.route_verified,
            "routing_provider": p.routing_provider,
            "all_offers_verified": p.all_offers_verified,
            "saving_vs_closest": saving_vs_closest,
            "recommended": p.plan_key == recommended.plan_key,
            "eligible_by_threshold": (
                p.plan_key == closest.plan_key
                or saving_vs_closest >= float(min_saving_to_travel)
            ),
        }

    return {
        "recommendation": serialize(recommended),
        "closest_plan": serialize(closest),
        "max_saving_plan": serialize(max_saving),
        "best_single_store": serialize(single_store),
        "plans": [serialize(p) for p in candidates],
        "rule": {
            "min_saving_to_travel": float(min_saving_to_travel),
            "vehicle_cost_per_km": cost_per_km,
            "time_value_per_hour": value_per_hour,
            "travel_profile": travel_profile,
        },
    }
