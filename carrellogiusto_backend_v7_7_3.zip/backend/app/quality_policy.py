
from dataclasses import dataclass

@dataclass
class QualityDecision:
    accepted: bool
    verified: bool
    status: str
    reason: str
    score: float

class QualityPolicy:
    """
    Conservative policy:
    - source_quality >= 0.90 and match_confidence >= 0.98 -> accepted + verified
    - source_quality >= 0.75 and match_confidence >= 0.90 -> accepted, not verified
    - otherwise -> rejected/review
    """

    def decide(self, source_quality: float, match_confidence: float) -> QualityDecision:
        combined = round((source_quality * 0.65) + (match_confidence * 0.35), 4)

        if source_quality >= 0.90 and match_confidence >= 0.98:
            return QualityDecision(
                accepted=True,
                verified=True,
                status="verified",
                reason="Fonte ad alta qualità e matching prodotto ad alta confidenza.",
                score=combined,
            )

        if source_quality >= 0.75 and match_confidence >= 0.90:
            return QualityDecision(
                accepted=True,
                verified=False,
                status="accepted_unverified",
                reason="Dato accettato ma non sufficientemente forte per la verifica automatica.",
                score=combined,
            )

        return QualityDecision(
            accepted=False,
            verified=False,
            status="needs_review",
            reason="Qualità fonte o confidenza di matching insufficienti.",
            score=combined,
        )
