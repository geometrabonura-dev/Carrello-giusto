from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any

@dataclass
class ParsedCartIntentV64:
    raw_text: str
    items: list[dict[str, Any]] = field(default_factory=list)
    ambiguities: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)

    def to_dict(self):
        return asdict(self)

SYSTEM_PROMPT = """
Sei il parser della lista della spesa di CarrelloGiusto.
Devi estrarre intenzioni e possibili prodotti, senza inventare prezzi,
EAN, disponibilità, promozioni o stato di verifica.

Per ogni articolo prova a ricavare:
- nome;
- quantità;
- unità;
- marca preferita;
- se equivalenti sono ammessi;
- eventuali vincoli come 'in offerta' o 'senza semi'.

Se qualcosa è ambiguo, segnalalo esplicitamente.
Non prendere decisioni economiche: il motore deterministico farà i calcoli.
""".strip()

def build_parse_prompt(text: str) -> tuple[str, str]:
    return SYSTEM_PROMPT, text
