
from pathlib import Path
from .db import get_conn

MIGRATION_DIR = Path(__file__).resolve().parent.parent / "sql"

def _migration_files():
    return sorted(
        p for p in MIGRATION_DIR.glob("migration_*.sql")
        if p.is_file()
    )

def ensure_migrations_table():
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    filename TEXT PRIMARY KEY,
                    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
                )
            """)
        conn.commit()

def applied_migrations():
    ensure_migrations_table()
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT filename FROM schema_migrations")
            return {row[0] for row in cur.fetchall()}

def apply_pending_migrations():
    ensure_migrations_table()
    already = applied_migrations()
    applied = []

    for path in _migration_files():
        if path.name in already:
            continue
        sql = path.read_text(encoding="utf-8")
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                cur.execute(
                    "INSERT INTO schema_migrations(filename) VALUES (%s)",
                    (path.name,),
                )
            conn.commit()
        applied.append(path.name)

    return applied
