
def explain_plan(plan, closest_plan=None, cheapest_product_plan=None):
    if not plan:
        return {
            "headline": "Nessun piano disponibile",
            "reasons": [],
        }

    reasons = []

    stores = len(plan.get("stores", []))
    if stores == 1:
        reasons.append("Tutta la spesa si può fare in un solo supermercato.")
    else:
        reasons.append(f"Il piano usa {stores} supermercati.")

    if plan.get("travel_cost") is not None:
        reasons.append(f"Costo viaggio stimato: €{plan['travel_cost']:.2f}.")

    if plan.get("time_cost") is not None:
        reasons.append(f"Valore del tempo stimato: €{plan['time_cost']:.2f}.")

    if plan.get("duration_minutes") is not None:
        reasons.append(f"Tempo di viaggio stimato: {plan['duration_minutes']:.0f} minuti.")

    if closest_plan and plan is not closest_plan:
        diff = round(closest_plan["effective_total"] - plan["effective_total"], 2)
        if diff > 0:
            reasons.append(f"Risparmia €{diff:.2f} rispetto al piano più vicino.")
        elif diff < 0:
            reasons.append(f"Costa €{abs(diff):.2f} in più del piano più vicino.")

    if cheapest_product_plan and plan is not cheapest_product_plan:
        diff = round(plan["product_total"] - cheapest_product_plan["product_total"], 2)
        if diff > 0:
            reasons.append(
                f"I prodotti costano €{diff:.2f} in più del minimo assoluto, "
                "ma il piano può essere migliore considerando viaggio e semplicità."
            )

    score = plan.get("personalized_score")
    if score is not None:
        reasons.append(f"Punteggio personalizzato: {score:.2f}.")

    return {
        "headline": "Questo è il piano che offre il miglior equilibrio per le tue preferenze.",
        "reasons": reasons,
    }
