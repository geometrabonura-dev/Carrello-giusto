
from dataclasses import dataclass
from typing import Optional
from .db import get_conn

@dataclass(frozen=True)
class CatalogProductRow:
    product_key: str
    name: str
    brand: Optional[str]
    unit: str
    default_quantity: float
    strict_brand: bool
    allow_fractional_quantity: bool

class CatalogRepositoryV44:
    def search(self, query: str, limit: int = 20):
        q = f"%{query.strip().lower()}%"
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT
                        COALESCE(p.product_key, p.id::text) AS product_key,
                        p.name,
                        p.brand,
                        COALESCE(p.unit, 'pezzo') AS unit,
                        COALESCE(p.default_quantity, 1.0) AS default_quantity,
                        COALESCE(p.strict_brand, FALSE) AS strict_brand,
                        COALESCE(p.allow_fractional_quantity, FALSE)
                    FROM products p
                    WHERE LOWER(p.name) LIKE %s
                       OR LOWER(COALESCE(p.brand, '')) LIKE %s
                    ORDER BY
                        CASE WHEN LOWER(p.name) = LOWER(%s) THEN 0 ELSE 1 END,
                        p.name
                    LIMIT %s
                """, (q, q, query, limit))
                rows = cur.fetchall()

        return [
            CatalogProductRow(
                product_key=r[0],
                name=r[1],
                brand=r[2],
                unit=r[3],
                default_quantity=float(r[4]),
                strict_brand=bool(r[5]),
                allow_fractional_quantity=bool(r[6]),
            )
            for r in rows
        ]

    def resolve_key(self, product_key: str):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("""
                    SELECT
                        COALESCE(product_key, id::text),
                        name,
                        brand,
                        COALESCE(unit, 'pezzo'),
                        COALESCE(default_quantity, 1.0),
                        COALESCE(strict_brand, FALSE),
                        COALESCE(allow_fractional_quantity, FALSE)
                    FROM products
                    WHERE product_key = %s
                    LIMIT 1
                """, (product_key,))
                r = cur.fetchone()

        if not r:
            return None

        return CatalogProductRow(
            product_key=r[0],
            name=r[1],
            brand=r[2],
            unit=r[3],
            default_quantity=float(r[4]),
            strict_brand=bool(r[5]),
            allow_fractional_quantity=bool(r[6]),
        )
