
from fastapi import APIRouter, Depends
from .auth import require_admin
from .migrations import applied_migrations, apply_pending_migrations

router = APIRouter(prefix="/admin/migrations", tags=["admin-migrations"])

@router.get("", dependencies=[Depends(require_admin)])
def list_migrations():
    return {"applied": sorted(applied_migrations())}

@router.post("/apply", dependencies=[Depends(require_admin)])
def apply_migrations():
    return {"applied_now": apply_pending_migrations()}
