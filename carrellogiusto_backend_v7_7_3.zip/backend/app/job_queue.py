
import json
import time
import threading
from dataclasses import dataclass
from typing import Callable, Any
from .db import get_conn
from .audit import write_audit

@dataclass
class Job:
    id: str
    job_type: str
    payload: dict
    attempts: int
    max_attempts: int

class DatabaseJobQueue:
    def enqueue(self, job_type: str, payload: dict, max_attempts: int = 5) -> str:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO background_jobs (
                        job_type, payload, status, attempts, max_attempts, available_at
                    )
                    VALUES (%s, %s, 'pending', 0, %s, NOW())
                    RETURNING id::text
                    """,
                    (job_type, payload, max_attempts),
                )
                job_id = cur.fetchone()[0]
            conn.commit()

        write_audit(
            action="job_enqueued",
            resource_type="background_job",
            resource_id=job_id,
            detail={"job_type": job_type},
        )
        return job_id

    def claim_next(self) -> Job | None:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id::text, job_type, payload, attempts, max_attempts
                    FROM background_jobs
                    WHERE status IN ('pending', 'retry')
                      AND available_at <= NOW()
                    ORDER BY created_at ASC
                    FOR UPDATE SKIP LOCKED
                    LIMIT 1
                    """
                )
                row = cur.fetchone()
                if not row:
                    conn.rollback()
                    return None

                cur.execute(
                    """
                    UPDATE background_jobs
                    SET status='running',
                        started_at=NOW(),
                        attempts=attempts+1,
                        updated_at=NOW()
                    WHERE id=%s
                    """,
                    (row[0],),
                )
            conn.commit()

        return Job(
            id=row[0],
            job_type=row[1],
            payload=row[2],
            attempts=row[3] + 1,
            max_attempts=row[4],
        )

    def complete(self, job_id: str):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE background_jobs
                    SET status='completed',
                        finished_at=NOW(),
                        updated_at=NOW(),
                        last_error=NULL
                    WHERE id=%s
                    """,
                    (job_id,),
                )
            conn.commit()

        write_audit(
            action="job_completed",
            resource_type="background_job",
            resource_id=job_id,
        )

    def fail_or_retry(self, job: Job, error: str):
        if job.attempts >= job.max_attempts:
            status = "failed"
            delay_seconds = 0
        else:
            status = "retry"
            delay_seconds = min(3600, 2 ** job.attempts * 30)

        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE background_jobs
                    SET status=%s,
                        last_error=%s,
                        available_at=NOW() + (%s || ' seconds')::interval,
                        updated_at=NOW()
                    WHERE id=%s
                    """,
                    (status, error, delay_seconds, job.id),
                )
            conn.commit()

        write_audit(
            action="job_failed" if status == "failed" else "job_retry_scheduled",
            resource_type="background_job",
            resource_id=job.id,
            detail={"attempts": job.attempts, "error": error, "delay_seconds": delay_seconds},
        )

class Worker:
    def __init__(self):
        self.queue = DatabaseJobQueue()
        self.handlers: dict[str, Callable[[dict], Any]] = {}
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def register(self, job_type: str, handler: Callable[[dict], Any]):
        self.handlers[job_type] = handler

    def run_once(self):
        job = self.queue.claim_next()
        if not job:
            return False

        handler = self.handlers.get(job.job_type)
        if not handler:
            self.queue.fail_or_retry(job, f"No handler for job type {job.job_type}")
            return True

        try:
            handler(job.payload)
            self.queue.complete(job.id)
        except Exception as exc:
            self.queue.fail_or_retry(job, str(exc))

        return True

    def start(self):
        if self._thread and self._thread.is_alive():
            return

        def loop():
            while not self._stop.is_set():
                had_job = self.run_once()
                if not had_job:
                    self._stop.wait(2)

        self._thread = threading.Thread(target=loop, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop.set()
