from __future__ import annotations

from dataclasses import dataclass, asdict

_UNIT_ALIASES = {
    "g": ("mass", 0.001),
    "kg": ("mass", 1.0),
    "ml": ("volume", 0.001),
    "l": ("volume", 1.0),
    "lt": ("volume", 1.0),
    "piece": ("count", 1.0),
    "pezzo": ("count", 1.0),
    "pc": ("count", 1.0),
    "pack": ("count", 1.0),
    "confezione": ("count", 1.0),
}

@dataclass(frozen=True)
class CompatibilityDecisionV71:
    compatible: bool
    reason: str
    source_dimension: str | None
    alternative_dimension: str | None
    source_normalized_quantity: float | None
    alternative_normalized_quantity: float | None
    suggested_relation_type: str

    def to_dict(self):
        return asdict(self)

def _unit_info(unit: str | None):
    if not unit:
        return None
    return _UNIT_ALIASES.get(str(unit).strip().lower())

def _normalized_quantity(quantity, unit):
    info = _unit_info(unit)
    if not info or quantity is None:
        return None, None
    dimension, factor = info
    return dimension, round(float(quantity) * factor, 6)

def evaluate_substitution_compatibility_v71(
    *,
    source_quantity,
    source_unit,
    alternative_quantity,
    alternative_unit,
) -> CompatibilityDecisionV71:
    s_dim, s_qty = _normalized_quantity(source_quantity, source_unit)
    a_dim, a_qty = _normalized_quantity(alternative_quantity, alternative_unit)

    if s_dim is None or a_dim is None:
        return CompatibilityDecisionV71(
            compatible=False,
            reason="Unità o quantità non sufficienti per verificare la compatibilità.",
            source_dimension=s_dim,
            alternative_dimension=a_dim,
            source_normalized_quantity=s_qty,
            alternative_normalized_quantity=a_qty,
            suggested_relation_type="unknown",
        )

    if s_dim != a_dim:
        return CompatibilityDecisionV71(
            compatible=False,
            reason="Le unità appartengono a dimensioni diverse.",
            source_dimension=s_dim,
            alternative_dimension=a_dim,
            source_normalized_quantity=s_qty,
            alternative_normalized_quantity=a_qty,
            suggested_relation_type="incompatible_dimension",
        )

    if s_dim in {"mass", "volume"}:
        # Different pack sizes are acceptable because optimizer cost normalization
        # handles the requested quantity; extreme ratios are kept for human review.
        ratio = max(s_qty, a_qty) / max(min(s_qty, a_qty), 1e-9)
        if ratio > 4.0:
            return CompatibilityDecisionV71(
                compatible=False,
                reason="Formati troppo distanti per approvazione automatica.",
                source_dimension=s_dim,
                alternative_dimension=a_dim,
                source_normalized_quantity=s_qty,
                alternative_normalized_quantity=a_qty,
                suggested_relation_type="format_variant",
            )
        relation = "weighted_equivalent" if str(source_unit).lower() == "kg" and str(alternative_unit).lower() == "kg" else "format_equivalent"
        return CompatibilityDecisionV71(
            compatible=True,
            reason="Stessa dimensione; costo confrontabile dopo normalizzazione quantità.",
            source_dimension=s_dim,
            alternative_dimension=a_dim,
            source_normalized_quantity=s_qty,
            alternative_normalized_quantity=a_qty,
            suggested_relation_type=relation,
        )

    # Count products: allow only roughly comparable pack counts.
    ratio = max(s_qty, a_qty) / max(min(s_qty, a_qty), 1e-9)
    compatible = ratio <= 2.0
    return CompatibilityDecisionV71(
        compatible=compatible,
        reason=(
            "Conteggi compatibili."
            if compatible
            else "Conteggi troppo diversi per considerarli equivalenti."
        ),
        source_dimension=s_dim,
        alternative_dimension=a_dim,
        source_normalized_quantity=s_qty,
        alternative_normalized_quantity=a_qty,
        suggested_relation_type="pack_equivalent",
    )
