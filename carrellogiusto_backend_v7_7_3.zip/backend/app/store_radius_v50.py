
from math import radians, sin, cos, asin, sqrt

def haversine_km(lat1, lon1, lat2, lon2):
    r = 6371.0088
    p1, p2 = radians(lat1), radians(lat2)
    dphi = radians(lat2 - lat1)
    dlambda = radians(lon2 - lon1)
    a = sin(dphi/2)**2 + cos(p1)*cos(p2)*sin(dlambda/2)**2
    return 2 * r * asin(sqrt(a))

def filter_pricebook_by_radius(pricebook, origin, radius_km):
    radius = max(2.0, min(float(radius_km), 30.0))
    out = {}
    for sid, store in pricebook.items():
        lat, lon = store.get("lat"), store.get("lon")
        if lat is None or lon is None:
            continue
        d = haversine_km(
            float(origin["latitude"]),
            float(origin["longitude"]),
            float(lat),
            float(lon),
        )
        if d <= radius:
            copy = dict(store)
            copy["air_distance_km"] = round(d, 3)
            out[sid] = copy
    return out
