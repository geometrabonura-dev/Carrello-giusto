from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .substitution_compatibility_v71 import (
    evaluate_substitution_compatibility_v71,
)

class ProductSubstitutionAdminV71:
    def _conn(self):
        from .db import get_conn
        return get_conn()

    def _product(self, product_key: str) -> dict[str, Any] | None:
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        COALESCE(product_key, id::text),
                        name,
                        brand,
                        quantity,
                        unit
                    FROM products
                    WHERE COALESCE(product_key, id::text) = %s
                    LIMIT 1
                    """,
                    (product_key,),
                )
                row = cur.fetchone()
        if not row:
            return None
        return {
            "product_key": str(row[0]),
            "name": row[1],
            "brand": row[2],
            "quantity": float(row[3]) if row[3] is not None else None,
            "unit": row[4],
        }

    def list(self, *, status: str | None = None, limit: int = 100):
        params = []
        clause = ""
        if status:
            clause = "WHERE review_status = %s"
            params.append(status)
        params.append(max(1, min(limit, 500)))

        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    SELECT
                        source_product_key,
                        alternative_product_key,
                        relation_type,
                        approved,
                        review_status,
                        note,
                        proposed_by,
                        reviewed_by,
                        created_at::text,
                        updated_at::text
                    FROM product_substitutions
                    {clause}
                    ORDER BY updated_at DESC
                    LIMIT %s
                    """,
                    tuple(params),
                )
                rows = cur.fetchall()

        return [
            {
                "source_product_key": r[0],
                "alternative_product_key": r[1],
                "relation_type": r[2],
                "approved": bool(r[3]),
                "review_status": r[4],
                "note": r[5],
                "proposed_by": r[6],
                "reviewed_by": r[7],
                "created_at": r[8],
                "updated_at": r[9],
            }
            for r in rows
        ]

    def propose(
        self,
        *,
        source_product_key: str,
        alternative_product_key: str,
        relation_type: str = "equivalent",
        note: str | None = None,
        proposed_by: str = "manual",
    ):
        if source_product_key == alternative_product_key:
            raise ValueError("Un prodotto non può sostituire se stesso.")
        if self._product(source_product_key) is None:
            raise ValueError("Prodotto sorgente inesistente.")
        if self._product(alternative_product_key) is None:
            raise ValueError("Prodotto alternativo inesistente.")

        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO product_substitutions(
                        source_product_key,
                        alternative_product_key,
                        relation_type,
                        approved,
                        review_status,
                        note,
                        proposed_by,
                        created_at,
                        updated_at
                    )
                    VALUES (%s,%s,%s,FALSE,'pending',%s,%s,NOW(),NOW())
                    ON CONFLICT (source_product_key, alternative_product_key)
                    DO UPDATE SET
                        relation_type = EXCLUDED.relation_type,
                        approved = FALSE,
                        review_status = 'pending',
                        note = EXCLUDED.note,
                        proposed_by = EXCLUDED.proposed_by,
                        reviewed_by = NULL,
                        updated_at = NOW()
                    """,
                    (
                        source_product_key,
                        alternative_product_key,
                        relation_type,
                        note,
                        proposed_by,
                    ),
                )
            conn.commit()

        return {"status": "pending"}

    def compatibility(self, *, source_product_key: str, alternative_product_key: str):
        source = self._product(source_product_key)
        alternative = self._product(alternative_product_key)
        if source is None or alternative is None:
            raise ValueError("Prodotto non trovato.")

        decision = evaluate_substitution_compatibility_v71(
            source_quantity=source["quantity"],
            source_unit=source["unit"],
            alternative_quantity=alternative["quantity"],
            alternative_unit=alternative["unit"],
        )
        return {
            "source": source,
            "alternative": alternative,
            "decision": decision.to_dict(),
        }

    def approve(
        self,
        *,
        source_product_key: str,
        alternative_product_key: str,
        actor: str,
        force: bool = False,
    ):
        check = self.compatibility(
            source_product_key=source_product_key,
            alternative_product_key=alternative_product_key,
        )
        decision = check["decision"]
        if not decision["compatible"] and not force:
            raise ValueError(decision["reason"])

        relation_type = (
            decision["suggested_relation_type"]
            if decision["compatible"]
            else "manual_override"
        )
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE product_substitutions
                    SET approved = TRUE,
                        review_status = 'approved',
                        relation_type = %s,
                        reviewed_by = %s,
                        updated_at = NOW()
                    WHERE source_product_key = %s
                      AND alternative_product_key = %s
                    """,
                    (
                        relation_type,
                        actor,
                        source_product_key,
                        alternative_product_key,
                    ),
                )
                if cur.rowcount == 0:
                    raise ValueError("Candidato non trovato.")
            conn.commit()
        return {
            "status": "approved",
            "relation_type": relation_type,
            "compatibility": check,
        }

    def reject(
        self,
        *,
        source_product_key: str,
        alternative_product_key: str,
        actor: str,
        note: str | None = None,
    ):
        with self._conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE product_substitutions
                    SET approved = FALSE,
                        review_status = 'rejected',
                        reviewed_by = %s,
                        note = COALESCE(%s, note),
                        updated_at = NOW()
                    WHERE source_product_key = %s
                      AND alternative_product_key = %s
                    """,
                    (
                        actor,
                        note,
                        source_product_key,
                        alternative_product_key,
                    ),
                )
                if cur.rowcount == 0:
                    raise ValueError("Candidato non trovato.")
            conn.commit()
        return {"status": "rejected"}
