
from .db import get_conn

class ReviewMetricsV57:
    def summary(self):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT
                        COUNT(*) FILTER (WHERE status='pending') AS pending,
                        COUNT(*) FILTER (WHERE status='resolved') AS resolved,
                        COUNT(*) FILTER (WHERE status='rejected') AS rejected,
                        AVG(EXTRACT(EPOCH FROM (resolved_at - created_at))/3600.0)
                            FILTER (WHERE resolved_at IS NOT NULL)
                            AS avg_resolution_hours,
                        PERCENTILE_CONT(0.5) WITHIN GROUP (
                            ORDER BY EXTRACT(EPOCH FROM (resolved_at - created_at))/3600.0
                        ) FILTER (WHERE resolved_at IS NOT NULL)
                            AS median_resolution_hours
                    FROM import_review_queue
                    """
                )
                row = cur.fetchone()

        return {
            "pending": int(row[0] or 0),
            "resolved": int(row[1] or 0),
            "rejected": int(row[2] or 0),
            "avg_resolution_hours": float(row[3]) if row[3] is not None else None,
            "median_resolution_hours": float(row[4]) if row[4] is not None else None,
        }
