
from math import inf

def route_cost(order, matrix):
    if not order:
        return 0.0
    total = 0.0
    prev = 0  # origin
    for node in order:
        total += matrix[prev][node]
        prev = node
    total += matrix[prev][0]
    return total

def nearest_neighbor_route(matrix, stop_nodes):
    remaining = set(stop_nodes)
    order = []
    current = 0

    while remaining:
        nxt = min(remaining, key=lambda n: matrix[current][n])
        order.append(nxt)
        remaining.remove(nxt)
        current = nxt

    return order

def two_opt(order, matrix):
    best = list(order)
    best_cost = route_cost(best, matrix)

    improved = True
    while improved:
        improved = False
        n = len(best)
        for i in range(n - 1):
            for j in range(i + 1, n):
                candidate = best[:i] + list(reversed(best[i:j+1])) + best[j+1:]
                cost = route_cost(candidate, matrix)
                if cost + 1e-9 < best_cost:
                    best = candidate
                    best_cost = cost
                    improved = True
        # stop when a full pass produces no improvement
    return best

def scalable_stop_order(matrix, stop_nodes):
    stop_nodes = list(stop_nodes)

    if len(stop_nodes) <= 1:
        return stop_nodes

    # Exact brute-force remains reasonable for <=4 stores.
    if len(stop_nodes) <= 4:
        from itertools import permutations
        return min(permutations(stop_nodes), key=lambda p: route_cost(p, matrix))

    # 5-6 stores: nearest-neighbor + 2-opt.
    seed = nearest_neighbor_route(matrix, stop_nodes)
    return two_opt(seed, matrix)
