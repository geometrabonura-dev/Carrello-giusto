
from html import escape
from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse
from .auth import require_admin

router = APIRouter(prefix="/admin/reviews", tags=["admin-reviews-v5-4"])

@router.get("", response_class=HTMLResponse, dependencies=[Depends(require_admin)])
def reviews_dashboard():
    from .review_repository_v53 import ReviewRepositoryV53
    rows = ReviewRepositoryV53().pending(limit=200)

    body = []
    for r in rows:
        payload = r.get("payload") or {}
        label = (
            payload.get("product_name")
            or payload.get("name")
            or payload.get("store_name")
            or r.get("external_ref")
            or ""
        )
        body.append(
            "<tr>"
            f"<td>{escape(str(r.get('review_type') or ''))}</td>"
            f"<td>{escape(str(r.get('source_key') or ''))}</td>"
            f"<td>{escape(str(r.get('external_ref') or ''))}</td>"
            f"<td>{escape(str(label))}</td>"
            f"<td>{escape(str(r.get('created_at') or ''))}</td>"
            f"<td>{escape(str(r.get('id') or ''))}</td>"
            "</tr>"
        )

    return HTMLResponse(
        """
        <html>
        <head>
          <title>CarrelloGiusto - Review queue</title>
          <style>
            body { font-family: sans-serif; padding: 24px; }
            table { border-collapse: collapse; width: 100%; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background: #f2f2f2; }
            .pill { padding: 2px 6px; border-radius: 12px; background: #eee; }
          </style>
        </head>
        <body>
          <h1>Review queue</h1>
          <p>Elementi da mappare manualmente. Dopo la risoluzione possono essere rielaborati.</p>
          <table>
            <tr>
              <th>Tipo</th>
              <th>Fonte</th>
              <th>Rif. esterno</th>
              <th>Descrizione</th>
              <th>Creato</th>
              <th>Review ID</th>
            </tr>
            """ + "".join(body) + """
          </table>
        </body>
        </html>
        """
    )
