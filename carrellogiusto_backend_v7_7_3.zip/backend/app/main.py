from .substitution_console_v71 import router as substitution_console_v71_router
from .substitution_admin_api_v71 import router as substitution_admin_v71_router
from .ai_cart_chat_api_v68 import router as ai_cart_chat_v68_router
from .ai_cart_api_v65 import router as ai_cart_v65_router
from .ai_api_v64 import router as ai_v64_router
from .release_api_v60 import router as release_v60_router
from .review_console_v57 import router as review_console_v57_router
from .review_api_v57 import router as review_v57_router
from .review_console_v56 import router as review_console_v56_router
from .review_admin_api_v56 import router as review_admin_v56_router
from .admin_audit_api_v55 import router as admin_audit_v55_router
from .review_reprocess_api_v54 import router as reprocess_v54_router
from .maintenance_api_v54 import router as maintenance_v54_router
from .review_dashboard_v54 import router as review_dashboard_v54_router
from .review_api_v53 import router as review_v53_router
from .import_dashboard_v52 import router as import_dashboard_v52_router
from .import_api_v52 import router as import_v52_router
from .source_api_v51 import router as source_v51_router
from .cart_api_v48 import router as cart_v48_router
from .cart_api_v47 import router as cart_v47_router
from .cart_api_v46 import router as cart_v46_router
from .cart_api_v45 import router as cart_v45_router
from .catalog_api_v44 import router as catalog_v44_router

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from .repository_factory import get_repository
from .optimizer import optimize
from .optimizer_v35 import optimize_with_strategy
from .import_api import router as import_router
from .review_api import router as review_router
from .dashboard_api import router as dashboard_router
from .admin_api import router as admin_router
from .jobs_api import router as jobs_router
from .preferences_api import router as preferences_router
from .migration_api import router as migration_router
from .history_api import router as history_router
from .health import detailed_health, liveness, readiness
from .scheduler import start_scheduler, stop_scheduler
from .logging_config import configure_logging
from .metrics_middleware import metrics_middleware
from .metrics import render_metrics
from .rate_limit import rate_limit_middleware
from .config import settings
from .job_queue import Worker
from .import_jobs import process_import_job
from .travel_profiles import PROFILES
from .strategy_profiles import STRATEGIES
from .user_preferences import get_preferences

configure_logging()

app = FastAPI(title="CarrelloGiusto API", version="7.6.0")
app.include_router(import_router)
app.include_router(review_router)
app.include_router(dashboard_router)
app.include_router(admin_router)
app.include_router(jobs_router)
app.include_router(preferences_router)
app.include_router(migration_router)
app.include_router(history_router)
app.include_router(catalog_v44_router)
app.include_router(cart_v45_router)
app.include_router(cart_v46_router)
app.include_router(cart_v47_router)
app.include_router(cart_v48_router)
app.include_router(source_v51_router)
app.include_router(import_v52_router)
app.include_router(import_dashboard_v52_router)
app.include_router(review_v53_router)
app.include_router(review_dashboard_v54_router)
app.include_router(maintenance_v54_router)
app.include_router(reprocess_v54_router)
app.include_router(admin_audit_v55_router)
app.include_router(review_admin_v56_router)
app.include_router(review_console_v56_router)
app.include_router(review_v57_router)
app.include_router(review_console_v57_router)
app.include_router(release_v60_router)
app.include_router(ai_v64_router)
app.include_router(ai_cart_v65_router)
app.include_router(ai_cart_chat_v68_router)
app.include_router(substitution_admin_v71_router)
app.include_router(substitution_console_v71_router)

worker = Worker()
worker.register("import_offers", process_import_job)

if settings.metrics_enabled:
    app.middleware("http")(metrics_middleware)
app.middleware("http")(rate_limit_middleware)

class OptimizeRequest(BaseModel):
    items: List[str]
    origin: Optional[dict] = None
    user_id: Optional[str] = None
    strategy: str = "balanced"
    radius_km: Optional[float] = None
    travel_profile: Optional[str] = None
    vehicle_cost_per_km: Optional[float] = None
    time_value_per_hour: Optional[float] = None
    min_saving_to_travel: Optional[float] = None
    max_travel_minutes: Optional[float] = None
    max_stores: Optional[int] = None

@app.on_event("startup")
def on_startup():
    start_scheduler()
    worker.start()

@app.on_event("shutdown")
def on_shutdown():
    stop_scheduler()
    worker.stop()

@app.get("/health")
def health():
    return detailed_health()

@app.get("/health/live")
def health_live():
    return liveness()

@app.get("/health/ready")
def health_ready():
    return readiness()

@app.get("/metrics")
def metrics():
    return render_metrics()

@app.get("/v3/travel-profiles")
def travel_profiles():
    return {
        k: {
            "routing_profile": v.routing_profile,
            "cost_per_km": v.cost_per_km,
            "default_time_value_per_hour": v.default_time_value_per_hour,
        }
        for k, v in PROFILES.items()
    }

@app.get("/v3/strategies")
def strategies():
    return {
        k: {
            "label": v.label,
            "description": v.description,
            "weight_saving": v.weight_saving,
            "weight_time": v.weight_time,
            "weight_simplicity": v.weight_simplicity,
            "store_penalty_eur": v.store_penalty_eur,
        }
        for k, v in STRATEGIES.items()
    }

@app.post("/v3/cart/optimize")
def cart_optimize(req: OptimizeRequest):
    if not req.origin:
        raise HTTPException(status_code=422, detail="origin richiesto")

    if req.strategy not in STRATEGIES:
        raise HTTPException(status_code=422, detail="strategy non valida")

    pref = get_preferences(req.user_id) if req.user_id else None

    def choose(value, pref_value, default):
        return value if value is not None else (pref_value if pref_value is not None else default)

    radius_km = choose(req.radius_km, pref.radius_km if pref else None, 10.0)
    travel_profile = choose(req.travel_profile, pref.travel_profile if pref else None, "car")
    min_saving = choose(req.min_saving_to_travel, pref.min_saving_to_travel if pref else None, 3.0)
    max_travel = choose(req.max_travel_minutes, pref.max_travel_minutes if pref else None, None)
    max_stores = int(choose(req.max_stores, pref.max_stores if pref else None, 3))
    vehicle_cost = choose(req.vehicle_cost_per_km, pref.vehicle_cost_per_km if pref else None, None)
    time_value = choose(req.time_value_per_hour, pref.time_value_per_hour if pref else None, None)

    if travel_profile not in PROFILES:
        raise HTTPException(status_code=422, detail="travel_profile non valido")

    repo = get_repository()
    stores = repo.find_stores(radius_km, req.origin)
    offers = repo.find_offers(req.items, [s.id for s in stores])

    if stores and all(hasattr(s, "latitude") and hasattr(s, "longitude") for s in stores):
        result = optimize_with_strategy(
            req.items,
            stores,
            offers,
            origin=req.origin,
            strategy=req.strategy,
            travel_profile=travel_profile,
            vehicle_cost_per_km=vehicle_cost,
            time_value_per_hour=time_value,
            min_saving_to_travel=min_saving,
            max_stores=max_stores,
            max_travel_minutes=max_travel,
        )
    else:
        result = optimize(
            req.items,
            stores,
            offers,
            vehicle_cost_per_km=vehicle_cost or PROFILES[travel_profile].cost_per_km,
            min_saving_to_travel=min_saving,
            max_stores=max_stores,
        )
        result["strategy"] = {
            "key": req.strategy,
            "label": STRATEGIES[req.strategy].label,
            "description": STRATEGIES[req.strategy].description,
        }
        result["explanation"] = {
            "headline": "Modalità demo",
            "reasons": ["Dati e distanze reali non ancora disponibili in questo fallback."],
        }

    return {
        "data_status": "verified" if offers and all(o.verified for o in offers) else "unverified",
        "preferences_applied": {
            "user_id": req.user_id,
            "radius_km": radius_km,
            "travel_profile": travel_profile,
            "min_saving_to_travel": min_saving,
            "max_stores": max_stores,
        },
        **result,
    }
