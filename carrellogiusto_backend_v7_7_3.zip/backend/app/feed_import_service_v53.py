
from .authorized_sources_v51 import get_source
from .feed_reader_v52 import read_feed
from .verification_policy_v51 import decide_verification
from .review_service_v53 import (
    product_external_ref,
    store_external_ref,
)

class FeedImportServiceV53:
    def __init__(
        self,
        *,
        repository,
        product_matcher,
        review_repository,
        product_mapping_repository,
    ):
        self.repository = repository
        self.product_matcher = product_matcher
        self.review_repository = review_repository
        self.product_mapping_repository = product_mapping_repository

    def import_bytes(
        self,
        *,
        source_key: str,
        payload: bytes,
        content_type: str,
        feed_name: str | None = None,
    ):
        source = get_source(source_key)
        if source is None:
            raise ValueError("Fonte non registrata.")

        rows = read_feed(payload, content_type)
        run_id = self.repository.create_run(source_key, feed_name)

        metrics = {
            "received": len(rows),
            "accepted": 0,
            "verified": 0,
            "needs_review": 0,
            "rejected": 0,
            "unmatched_store": 0,
            "unmatched_product": 0,
            "manual_product_mapping_used": 0,
        }

        try:
            for raw in rows:
                self.repository.store_raw_offer(
                    run_id=run_id,
                    source_key=source_key,
                    payload=raw,
                )

                sref = store_external_ref(raw)
                store = None
                if sref:
                    store = self.repository.resolve_store(
                        source_key=source_key,
                        external_ref=sref,
                    )
                if not store:
                    metrics["unmatched_store"] += 1
                    if sref:
                        self.review_repository.enqueue_store(
                            source_key=source_key,
                            external_ref=sref,
                            payload=raw,
                            import_run_id=run_id,
                        )

                pref = product_external_ref(raw)
                match = self.product_mapping_repository.resolve(
                    source_key=source_key,
                    external_ref=pref,
                )

                if match:
                    metrics["manual_product_mapping_used"] += 1
                else:
                    match = self.product_matcher.match(
                        ean=raw.get("ean"),
                        product_key=raw.get("product_key"),
                        name=raw.get("product_name") or raw.get("name"),
                        brand=raw.get("brand"),
                    )

                if not match or not match.get("product_id"):
                    metrics["unmatched_product"] += 1
                    self.review_repository.enqueue_product(
                        source_key=source_key,
                        external_ref=pref,
                        payload=raw,
                        import_run_id=run_id,
                    )
                    confidence = 0.0
                else:
                    confidence = float(match.get("confidence", 0.0))

                price = float(raw.get("price") or 0)
                decision = decide_verification(
                    source_key=source_key,
                    product_match_confidence=confidence,
                    store_resolved=bool(store),
                    has_valid_price=price > 0,
                )

                if decision.verification_status == "verified":
                    metrics["verified"] += 1
                elif decision.verification_status == "needs_review":
                    metrics["needs_review"] += 1
                elif decision.verification_status == "rejected":
                    metrics["rejected"] += 1

                if (
                    decision.accepted
                    and store
                    and match
                    and match.get("product_id")
                ):
                    metrics["accepted"] += 1
                    self.repository.upsert_offer(
                        store_id=store["id"],
                        product_id=match["product_id"],
                        source_key=source_key,
                        store_external_ref=sref,
                        price=price,
                        regular_price=(
                            float(raw["regular_price"])
                            if raw.get("regular_price") not in (None, "")
                            else None
                        ),
                        valid_from=raw.get("valid_from"),
                        valid_to=raw.get("valid_to"),
                        loyalty_required=bool(
                            raw.get("loyalty_required", False)
                        ),
                        verification_status=decision.verification_status,
                        verified=(
                            decision.verification_status == "verified"
                        ),
                        source_url=raw.get("source_url"),
                    )

            self.repository.finish_run(run_id, "completed", metrics)
            return {
                "run_id": run_id,
                "status": "completed",
                "metrics": metrics,
            }

        except Exception:
            self.repository.finish_run(run_id, "failed", metrics)
            raise
