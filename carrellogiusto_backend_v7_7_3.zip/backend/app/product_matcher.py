
from dataclasses import dataclass
from difflib import SequenceMatcher
from typing import Optional
from .db import get_conn

@dataclass
class MatchResult:
    product_id: Optional[str]
    method: str
    confidence: float
    matched_name: Optional[str] = None

def _norm(value: str) -> str:
    return " ".join((value or "").lower().strip().split())

class ProductMatcher:
    def match(self, product_name: str, ean: Optional[str] = None, brand: Optional[str] = None) -> MatchResult:
        with get_conn() as conn:
            with conn.cursor() as cur:
                if ean:
                    cur.execute(
                        "SELECT id::text, canonical_name FROM products WHERE ean = %s LIMIT 1",
                        (ean,),
                    )
                    row = cur.fetchone()
                    if row:
                        return MatchResult(row[0], "ean", 1.0, row[1])

                cur.execute(
                    """
                    SELECT p.id::text, p.canonical_name
                    FROM product_aliases a
                    JOIN products p ON p.id = a.product_id
                    WHERE LOWER(a.alias) = LOWER(%s)
                    LIMIT 1
                    """,
                    (product_name,),
                )
                row = cur.fetchone()
                if row:
                    return MatchResult(row[0], "alias", 0.98, row[1])

                cur.execute(
                    """
                    SELECT id::text, canonical_name, COALESCE(brand, '')
                    FROM products
                    WHERE active = TRUE
                    """
                )
                candidates = cur.fetchall()

        target = _norm(product_name)
        best = None
        best_score = 0.0

        for product_id, canonical_name, candidate_brand in candidates:
            score = SequenceMatcher(None, target, _norm(canonical_name)).ratio()

            if brand and candidate_brand:
                brand_score = SequenceMatcher(
                    None, _norm(brand), _norm(candidate_brand)
                ).ratio()
                score = (score * 0.80) + (brand_score * 0.20)

            if score > best_score:
                best_score = score
                best = (product_id, canonical_name)

        if best and best_score >= 0.88:
            return MatchResult(best[0], "fuzzy", round(best_score, 4), best[1])

        return MatchResult(None, "unmatched", round(best_score, 4), best[1] if best else None)
