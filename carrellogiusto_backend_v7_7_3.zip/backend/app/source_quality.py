
from dataclasses import dataclass

@dataclass
class SourceQuality:
    authorized: bool
    freshness_hours: float
    completeness: float
    historical_accuracy: float

    def score(self) -> float:
        auth = 1.0 if self.authorized else 0.0
        freshness = max(0.0, min(1.0, 1.0 - (self.freshness_hours / 168.0)))
        completeness = max(0.0, min(1.0, self.completeness))
        accuracy = max(0.0, min(1.0, self.historical_accuracy))

        return round(
            0.40 * auth +
            0.25 * freshness +
            0.20 * completeness +
            0.15 * accuracy,
            4
        )
