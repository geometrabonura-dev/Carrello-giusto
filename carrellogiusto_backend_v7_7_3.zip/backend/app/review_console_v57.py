
import json
from html import escape
from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse
from .auth import require_admin

router = APIRouter(prefix="/admin/review-console-v57", tags=["admin-review-console-v5-7"])

@router.get("", response_class=HTMLResponse, dependencies=[Depends(require_admin)])
def review_console_v57(
    status: str = "pending",
    review_type: str | None = None,
    source_key: str | None = None,
    q: str | None = None,
    page: int = 1,
    page_size: int = 25,
):
    from .review_query_v57 import ReviewQueryV57
    from .review_metrics_v57 import ReviewMetricsV57

    page = max(1, page)
    page_size = max(5, min(page_size, 100))
    offset = (page - 1) * page_size

    data = ReviewQueryV57().list(
        status=status or None,
        review_type=review_type or None,
        source_key=source_key or None,
        q=q or None,
        limit=page_size,
        offset=offset,
    )
    metrics = ReviewMetricsV57().summary()

    cards = []
    for r in data["items"]:
        payload = r.get("payload") or {}
        payload_text = escape(
            json.dumps(payload, ensure_ascii=False, indent=2)
        )

        actions = ""
        if r["status"] == "rejected":
            actions = """
              <button onclick="reopenReview(this)">Riapri</button>
            """

        cards.append(
            f"""
            <section class="card"
              data-review-id="{escape(str(r.get('id') or ''))}"
              data-source-key="{escape(str(r.get('source_key') or ''))}"
              data-status="{escape(str(r.get('status') or ''))}">
              <div class="head">
                <div>
                  <strong>{escape(str(r.get('review_type') or '').upper())}</strong>
                  <span class="status">{escape(str(r.get('status') or ''))}</span>
                </div>
                <code>{escape(str(r.get('external_ref') or ''))}</code>
              </div>

              <p><b>Fonte:</b> {escape(str(r.get('source_key') or ''))}</p>
              <p><b>Creato:</b> {escape(str(r.get('created_at') or ''))}</p>

              <details>
                <summary>Payload raw</summary>
                <pre>{payload_text}</pre>
              </details>

              <div class="actions">
                {actions}
              </div>
            </section>
            """
        )

    prev_link = ""
    if page > 1:
        prev_link = f'<a href="?status={escape(status)}&page={page-1}&page_size={page_size}">← Precedente</a>'

    next_link = ""
    if offset + page_size < data["total"]:
        next_link = f'<a href="?status={escape(status)}&page={page+1}&page_size={page_size}">Successiva →</a>'

    html = f"""
    <html>
    <head>
      <title>CarrelloGiusto - Review Console v5.7</title>
      <style>
        body {{ font-family: sans-serif; margin: 0; background: #f7f7f7; }}
        header {{ padding: 18px 24px; background: white; border-bottom: 1px solid #ddd; }}
        .metrics {{ display:flex; gap:12px; flex-wrap:wrap; margin:12px 0; }}
        .metric {{ background:#fff; border:1px solid #ddd; border-radius:10px; padding:10px 14px; }}
        .filters {{ display:flex; gap:8px; flex-wrap:wrap; margin-top:12px; }}
        main {{ padding:24px; display:grid; gap:14px; }}
        .card {{ background:white; padding:16px; border-radius:12px; border:1px solid #ddd; }}
        .head {{ display:flex; justify-content:space-between; gap:12px; }}
        .status {{ margin-left:8px; padding:2px 6px; border-radius:10px; background:#eee; }}
        pre {{ white-space:pre-wrap; background:#fafafa; padding:10px; border-radius:8px; }}
        .pagination {{ padding:0 24px 24px; display:flex; justify-content:space-between; }}
      </style>
    </head>
    <body>
      <header>
        <h1>Review Console v5.7</h1>
        <div class="metrics">
          <div class="metric">Pending: {metrics["pending"]}</div>
          <div class="metric">Resolved: {metrics["resolved"]}</div>
          <div class="metric">Rejected: {metrics["rejected"]}</div>
          <div class="metric">Media ore: {metrics["avg_resolution_hours"] if metrics["avg_resolution_hours"] is not None else "-"}</div>
          <div class="metric">Mediana ore: {metrics["median_resolution_hours"] if metrics["median_resolution_hours"] is not None else "-"}</div>
        </div>

        <form method="get" class="filters">
          <select name="status">
            <option value="pending" {"selected" if status=="pending" else ""}>pending</option>
            <option value="resolved" {"selected" if status=="resolved" else ""}>resolved</option>
            <option value="rejected" {"selected" if status=="rejected" else ""}>rejected</option>
          </select>
          <select name="review_type">
            <option value="">tutti i tipi</option>
            <option value="store" {"selected" if review_type=="store" else ""}>store</option>
            <option value="product" {"selected" if review_type=="product" else ""}>product</option>
          </select>
          <input name="source_key" placeholder="source_key" value="{escape(source_key or '')}" />
          <input name="q" placeholder="cerca..." value="{escape(q or '')}" />
          <input name="page_size" type="number" min="5" max="100" value="{page_size}" />
          <button type="submit">Filtra</button>
        </form>
      </header>

      <main>
        {''.join(cards)}
      </main>

      <div class="pagination">
        <div>{prev_link}</div>
        <div>Pagina {page} • {data["total"]} risultati</div>
        <div>{next_link}</div>
      </div>

      <script>
        async function reopenReview(btn) {{
          const card = btn.closest('.card');
          const reason = prompt('Motivo della riapertura?');
          if (!reason) return;

          const response = await fetch('/admin/reviews-v57/reopen', {{
            method: 'POST',
            headers: {{
              'Content-Type':'application/json',
              'X-Admin-Token': localStorage.getItem('adminToken') || '',
              'X-Admin-Actor': 'browser-admin'
            }},
            body: JSON.stringify({{
              review_id: card.dataset.reviewId,
              source_key: card.dataset.sourceKey,
              reason: reason
            }})
          }});

          if (response.ok) location.reload();
          else alert(await response.text());
        }}
      </script>
    </body>
    </html>
    """
    return HTMLResponse(html)
