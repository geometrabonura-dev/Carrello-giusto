
from fastapi import APIRouter, File, Form, HTTPException, UploadFile

router = APIRouter(prefix="/v5/imports", tags=["imports-v5-2"])

@router.post("/feed")
async def import_feed(
    source_key: str = Form(...),
    file: UploadFile = File(...),
):
    payload = await file.read()
    try:
        from .feed_import_service_v53 import FeedImportServiceV53
        from .import_repository_v52 import ImportRepositoryV52
        from .product_match_adapter_v52 import ProductMatchAdapterV52
        from .review_repository_v53 import ReviewRepositoryV53
        from .source_product_mapping_v53 import SourceProductMappingV53

        return FeedImportServiceV53(
            repository=ImportRepositoryV52(),
            product_matcher=ProductMatchAdapterV52(),
            review_repository=ReviewRepositoryV53(),
            product_mapping_repository=SourceProductMappingV53(),
        ).import_bytes(
            source_key=source_key,
            payload=payload,
            content_type=file.content_type or "",
            feed_name=file.filename,
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))

@router.get("/runs")
def recent_runs(limit: int = 50):
    from .import_repository_v52 import ImportRepositoryV52
    return ImportRepositoryV52().recent_runs(
        limit=max(1, min(limit, 200))
    )
