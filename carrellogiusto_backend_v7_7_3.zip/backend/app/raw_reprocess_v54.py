
from .feed_import_service_v53 import FeedImportServiceV53

class RawReprocessServiceV54:
    def __init__(
        self,
        *,
        import_repository,
        product_matcher,
        review_repository,
        product_mapping_repository,
    ):
        self.import_repository = import_repository
        self.product_matcher = product_matcher
        self.review_repository = review_repository
        self.product_mapping_repository = product_mapping_repository

    def reprocess_payloads(self, *, source_key: str, payloads: list[dict]):
        import json

        service = FeedImportServiceV53(
            repository=self.import_repository,
            product_matcher=self.product_matcher,
            review_repository=self.review_repository,
            product_mapping_repository=self.product_mapping_repository,
        )
        return service.import_bytes(
            source_key=source_key,
            payload=json.dumps(payloads).encode("utf-8"),
            content_type="application/json",
            feed_name="reprocessed-review-items.json",
        )
