
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from .request_models_v43 import CartItemV43
from .cart_resolution_v45 import resolve_cart_items, CartValidationError
from .optimizer_input_v45 import to_optimizer_items
from .cart_offer_resolution_v46 import resolve_offer_coverage
from .optimizer_v46 import optimize_price_only

router = APIRouter(prefix="/v4/cart", tags=["cart-v4-6"])

class OptimizeCartV46Request(BaseModel):
    items: list[CartItemV43]
    max_stores: int = 3

@router.post("/optimize-db")
def optimize_cart_db(payload: OptimizeCartV46Request):
    try:
        resolved = resolve_cart_items(payload.items)
    except CartValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    optimizer_items = to_optimizer_items(resolved)
    coverage = resolve_offer_coverage(optimizer_items)

    if coverage.missing:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "cart_incomplete",
                "message": "Non ci sono offerte utilizzabili per tutti i prodotti.",
                "missing_items": coverage.missing,
            },
        )

    plan = optimize_price_only(
        coverage,
        max_stores=max(1, min(payload.max_stores, 3)),
    )

    if plan is None:
        raise HTTPException(
            status_code=409,
            detail={
                "code": "no_complete_plan",
                "message": "Nessuna combinazione di negozi copre tutto il carrello.",
            },
        )

    return {
        "data_status": "verified" if plan["all_offers_verified"] else "unverified",
        "coverage": {
            "covered_items": len(coverage.covered),
            "missing_items": [],
        },
        "recommendation": plan,
    }
