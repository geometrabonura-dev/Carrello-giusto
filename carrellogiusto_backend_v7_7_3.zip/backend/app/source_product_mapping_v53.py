
from .db import get_conn

class SourceProductMappingV53:
    def resolve(self, *, source_key: str, external_ref: str):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT product_id::text
                    FROM source_product_mappings
                    WHERE source_key=%s
                      AND external_ref=%s
                    LIMIT 1
                    """,
                    (source_key, external_ref),
                )
                row = cur.fetchone()
        if not row:
            return None
        return {
            "product_id": row[0],
            "confidence": 1.0,
            "method": "manual_mapping",
        }
