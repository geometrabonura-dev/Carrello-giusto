
import os

class Settings:
    admin_token: str = os.getenv("ADMIN_TOKEN", "change-me")
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    stale_after_hours: int = int(os.getenv("STALE_AFTER_HOURS", "48"))
    metrics_enabled: bool = os.getenv("METRICS_ENABLED", "true").lower() == "true"

settings = Settings()
