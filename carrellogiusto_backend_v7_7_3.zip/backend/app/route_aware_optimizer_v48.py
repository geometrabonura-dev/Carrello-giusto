from .route_aware_optimizer_v47 import (
    _assign_products_to_combo,
    _plan_key,
)
from .travel_profiles import get_profile
from .store_prefilter_v48 import prefilter_store_ids
from .strategy_ranker_v48 import rank_eligible_plans
from .plan_pruning_v60 import candidate_store_sets
from .route_matrix_v61 import (
    build_pairwise_route_matrix_v61,
    route_for_store_ids_v61,
)

def _used_store_ids(assignments):
    return sorted({str(a["store_id"]) for a in assignments})

def optimize_db_cart_v48(
    *,
    pricebook,
    product_keys,
    origin,
    routing_provider,
    travel_profile="car",
    max_stores=3,
    min_saving_to_travel=3.0,
    vehicle_cost_per_km=None,
    time_value_per_hour=None,
    strategy="balanced",
    max_candidate_stores=12,
):
    """
    v6.1 implementation behind the stable v4.8 API contract.

    Improvements:
    - max 6 stores remains supported;
    - candidate prefilter remains coverage-first;
    - combinations use the v6.0 bounded generator;
    - stores receiving no assigned product are removed from the route;
    - equivalent plans are deduplicated before routing;
    - one pairwise route matrix is built and reused;
    - 1-4 stops use exact ordering, 5-6 use NN + 2-opt;
    - injected routing_provider is now honored when supplied.
    """
    profile = get_profile(travel_profile)
    cost_per_km = (
        float(vehicle_cost_per_km)
        if vehicle_cost_per_km is not None
        else float(profile.cost_per_km)
    )
    value_per_hour = (
        float(time_value_per_hour)
        if time_value_per_hour is not None
        else float(profile.default_time_value_per_hour)
    )

    max_stores = max(1, min(int(max_stores), 6))
    requested_candidates = max(1, min(int(max_candidate_stores), 12))

    store_ids = prefilter_store_ids(
        pricebook,
        product_keys,
        max_candidates=requested_candidates,
    )

    # Generate price plans first, before any routing calls.
    # Deduplicate equivalent assignment plans so supersets with unused stores
    # do not cause unnecessary route calculations.
    unique_price_plans = {}
    generated_combinations = 0
    complete_combinations = 0

    for combo in candidate_store_sets(
        store_ids,
        max_stores,
        max_candidates=requested_candidates,
    ):
        generated_combinations += 1
        assigned = _assign_products_to_combo(pricebook, product_keys, combo)
        if assigned is None:
            continue

        complete_combinations += 1
        assignments, product_total = assigned
        used_ids = _used_store_ids(assignments)

        stores = []
        for sid in used_ids:
            src = pricebook[sid]
            stores.append({
                "id": sid,
                "name": src["store_name"],
                "lat": src.get("lat"),
                "lon": src.get("lon"),
            })

        key = _plan_key(stores, assignments)
        current = unique_price_plans.get(key)
        candidate = {
            "plan_key": key,
            "stores": stores,
            "assignments": assignments,
            "product_total": product_total,
            "stores_count": len(stores),
        }
        if (
            current is None
            or candidate["product_total"] < current["product_total"]
        ):
            unique_price_plans[key] = candidate

    if not unique_price_plans:
        return None

    # Matrix includes only stores actually used by at least one unique plan.
    used_all = []
    seen = set()
    for plan in unique_price_plans.values():
        for store in plan["stores"]:
            sid = str(store["id"])
            if sid not in seen:
                seen.add(sid)
                used_all.append(store)

    # Store coordinates were already filtered/enriched by the API path.
    route_matrix = build_pairwise_route_matrix_v61(
        origin=origin,
        stores=used_all,
        travel_profile=travel_profile,
        routing_provider=routing_provider,
    )

    candidates = []
    for plan in unique_price_plans.values():
        route = route_for_store_ids_v61(
            route_matrix,
            [s["id"] for s in plan["stores"]],
        )

        order_pos = {
            sid: i for i, sid in enumerate(route["ordered_store_ids"])
        }
        ordered_stores = sorted(
            plan["stores"],
            key=lambda s: order_pos.get(str(s["id"]), 999),
        )

        distance_km = float(route["distance_km"])
        duration_minutes = route["duration_minutes"]
        travel_cost = round(distance_km * cost_per_km, 2)
        time_cost = round(
            ((duration_minutes or 0.0) / 60.0) * value_per_hour,
            2,
        )
        effective_total = round(
            plan["product_total"] + travel_cost + time_cost, 2
        )

        candidates.append({
            **plan,
            "stores": ordered_stores,
            "distance_km": distance_km,
            "duration_minutes": duration_minutes,
            "travel_cost": travel_cost,
            "time_cost": time_cost,
            "effective_total": effective_total,
            "route_verified": bool(route["verified"]),
            "routing_provider": route["provider"],
            "route_method": (
                "exact" if len(ordered_stores) <= 4 else "nearest_neighbor_2opt"
            ),
            "all_offers_verified": all(
                bool(a.get("verified")) for a in plan["assignments"]
            ),
        })

    closest = min(
        candidates,
        key=lambda p: (
            p["distance_km"],
            p["effective_total"],
            p["stores_count"],
        ),
    )

    for plan in candidates:
        plan["saving_vs_closest"] = round(
            closest["effective_total"] - plan["effective_total"], 2
        )
        plan["eligible_by_threshold"] = (
            plan["plan_key"] == closest["plan_key"]
            or plan["saving_vs_closest"] >= float(min_saving_to_travel)
        )

    eligible = [p for p in candidates if p["eligible_by_threshold"]]
    recommendation, ranked = rank_eligible_plans(
        eligible, strategy_key=strategy
    )

    max_saving = min(
        candidates,
        key=lambda p: (
            p["product_total"],
            p["effective_total"],
            p["stores_count"],
        ),
    )

    single_store_candidates = [
        p for p in candidates if p["stores_count"] == 1
    ]
    single_store = (
        min(single_store_candidates, key=lambda p: p["effective_total"])
        if single_store_candidates else None
    )

    recommended_key = recommendation["plan_key"]

    def mark(plan):
        if plan is None:
            return None
        return {
            **plan,
            "recommended": plan["plan_key"] == recommended_key,
        }

    return {
        "recommendation": mark(recommendation),
        "closest_plan": mark(closest),
        "max_saving_plan": mark(max_saving),
        "best_single_store": mark(single_store),
        "plans": [mark(p) for p in candidates],
        "ranked_eligible_plans": [mark(p) for p in ranked],
        "optimizer_stats": {
            "generated_combinations": generated_combinations,
            "complete_combinations": complete_combinations,
            "unique_plans_routed": len(candidates),
            "route_matrix_nodes": len(used_all) + 1,
        },
        "rule": {
            "min_saving_to_travel": float(min_saving_to_travel),
            "vehicle_cost_per_km": cost_per_km,
            "time_value_per_hour": value_per_hour,
            "travel_profile": travel_profile,
            "max_stores": max_stores,
            "max_candidate_stores": requested_candidates,
            "strategy": strategy,
            "routing_v61": True,
        },
    }
