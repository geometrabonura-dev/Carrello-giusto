from __future__ import annotations

def is_weight_priced(unit: str | None) -> bool:
    return (unit or "").strip().lower() in {"kg", "€/kg", "eur/kg"}

def cost_for_weight(*, requested_kg: float, price_per_kg: float):
    requested_kg = float(requested_kg)
    price_per_kg = float(price_per_kg)
    if requested_kg <= 0:
        raise ValueError("requested_kg must be > 0")
    if price_per_kg <= 0:
        raise ValueError("price_per_kg must be > 0")
    return {
        "packs": 1,
        "cost": round(requested_kg * price_per_kg, 2),
        "supplied_quantity": round(requested_kg, 3),
        "pricing_basis": "per_kg",
        "unit_price": round(price_per_kg, 4),
    }
