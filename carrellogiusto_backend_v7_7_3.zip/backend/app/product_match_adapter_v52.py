from .product_identity_v63 import normalize_gtin, normalize_quantity



class ProductMatchAdapterV52:
    def __init__(self):
        from .product_matcher import ProductMatcher
        self.matcher = ProductMatcher()

    def match(
        self,
        *,
        ean=None,
        product_key=None,
        name=None,
        brand=None,
        quantity=None,
        unit=None,
    ):
        # Existing ProductMatcher signatures may vary across older versions,
        # so this adapter normalizes what v5.2 needs.
        normalized_ean = normalize_gtin(ean)
        normalized_quantity, normalized_unit = normalize_quantity(quantity, unit)

        if normalized_ean and hasattr(self.matcher, "match_by_ean"):
            r = self.matcher.match_by_ean(normalized_ean)
            if r:
                return self._normalize(r)

        if product_key and hasattr(self.matcher, "match_by_key"):
            r = self.matcher.match_by_key(product_key)
            if r:
                return self._normalize(r)

        if hasattr(self.matcher, "match"):
            try:
                r = self.matcher.match(
                    ean=ean,
                    product_key=product_key,
                    name=name,
                    brand=brand,
                    quantity=normalized_quantity,
                    unit=normalized_unit,
                )
                if r:
                    return self._normalize(r)
            except TypeError:
                try:
                    r = self.matcher.match(
                        ean=normalized_ean,
                        product_key=product_key,
                        name=name,
                        brand=brand,
                    )
                    if r:
                        return self._normalize(r)
                except TypeError:
                    pass

        return None

    def _normalize(self, result):
        if isinstance(result, dict):
            return {
                "product_id": str(
                    result.get("product_id") or result.get("id") or ""
                ),
                "confidence": float(
                    result.get("confidence", 1.0)
                ),
                "method": result.get("method", "unknown"),
            }

        return {
            "product_id": str(getattr(result, "product_id", getattr(result, "id", ""))),
            "confidence": float(getattr(result, "confidence", 1.0)),
            "method": getattr(result, "method", "unknown"),
        }
