
from .db import get_conn

class ReviewQueryV57:
    def list(
        self,
        *,
        status: str | None = "pending",
        review_type: str | None = None,
        source_key: str | None = None,
        q: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ):
        where = []
        params = []

        if status:
            where.append("status=%s")
            params.append(status)

        if review_type:
            where.append("review_type=%s")
            params.append(review_type)

        if source_key:
            where.append("source_key=%s")
            params.append(source_key)

        if q:
            where.append(
                """
                (
                  external_ref ILIKE %s
                  OR payload::text ILIKE %s
                )
                """
            )
            like = f"%{q.strip()}%"
            params.extend([like, like])

        where_sql = " WHERE " + " AND ".join(where) if where else ""

        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    SELECT id::text, review_type, source_key,
                           external_ref, payload, import_run_id::text,
                           status, created_at, updated_at, resolved_at,
                           resolved_entity_id::text
                    FROM import_review_queue
                    {where_sql}
                    ORDER BY created_at DESC
                    LIMIT %s OFFSET %s
                    """,
                    (*params, limit, offset),
                )
                rows = cur.fetchall()

                cur.execute(
                    f"""
                    SELECT COUNT(*)
                    FROM import_review_queue
                    {where_sql}
                    """,
                    tuple(params),
                )
                total = cur.fetchone()[0]

        return {
            "items": [
                {
                    "id": r[0],
                    "review_type": r[1],
                    "source_key": r[2],
                    "external_ref": r[3],
                    "payload": r[4] or {},
                    "import_run_id": r[5],
                    "status": r[6],
                    "created_at": r[7].isoformat() if r[7] else None,
                    "updated_at": r[8].isoformat() if r[8] else None,
                    "resolved_at": r[9].isoformat() if r[9] else None,
                    "resolved_entity_id": r[10],
                }
                for r in rows
            ],
            "total": int(total),
            "limit": limit,
            "offset": offset,
        }
