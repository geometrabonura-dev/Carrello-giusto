
class ReviewActionsV56:
    def __init__(self, review_repository, audit):
        self.review_repository = review_repository
        self.audit = audit

    def reject(
        self,
        *,
        review_id: str,
        source_key: str,
        review_type: str,
        external_ref: str,
        actor: str,
        reason: str,
    ):
        self.review_repository.reject_review(
            review_id=review_id,
            reason=reason,
        )

        self.audit.log(
            actor=actor,
            action=f"reject_{review_type}_review",
            entity_type="review",
            entity_id=review_id,
            source_key=source_key,
            details={
                "external_ref": external_ref,
                "reason": reason,
            },
        )

        return {
            "status": "rejected",
            "review_id": review_id,
            "reason": reason,
        }
