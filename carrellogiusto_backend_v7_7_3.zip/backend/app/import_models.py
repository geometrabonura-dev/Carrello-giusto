
from pydantic import BaseModel, Field
from typing import Optional, Any, List
from datetime import date
from decimal import Decimal

class ImportOfferPayload(BaseModel):
    external_store_ref: str
    external_product_ref: str
    product_name: str
    price: Decimal = Field(gt=0)
    regular_price: Optional[Decimal] = None
    ean: Optional[str] = None
    brand: Optional[str] = None
    loyalty_required: bool = False
    valid_from: Optional[date] = None
    valid_to: Optional[date] = None
    source_url: Optional[str] = None
    raw_payload: Optional[dict[str, Any]] = None

class ImportBatchPayload(BaseModel):
    source_id: str
    offers: List[ImportOfferPayload]
