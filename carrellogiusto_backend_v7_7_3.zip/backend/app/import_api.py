
from fastapi import APIRouter
from .import_models import ImportBatchPayload
from .import_pipeline import ImportPipeline, IncomingOffer
from .maintenance import expire_old_offers, mark_stale_offers

router = APIRouter(prefix="/v2/import", tags=["import"])

@router.post("/batch")
def import_batch(payload: ImportBatchPayload):
    pipeline = ImportPipeline()
    offers = [
        IncomingOffer(
            source_id=payload.source_id,
            external_store_ref=o.external_store_ref,
            external_product_ref=o.external_product_ref,
            product_name=o.product_name,
            price=o.price,
            regular_price=o.regular_price,
            ean=o.ean,
            brand=o.brand,
            loyalty_required=o.loyalty_required,
            valid_from=o.valid_from,
            valid_to=o.valid_to,
            source_url=o.source_url,
            raw_payload=o.raw_payload,
        )
        for o in payload.offers
    ]
    return pipeline.import_offers(payload.source_id, offers)

@router.post("/maintenance/expire")
def expire():
    return {"expired": expire_old_offers()}

@router.post("/maintenance/stale")
def stale(hours: int = 48):
    return {"marked_stale": mark_stale_offers(hours)}
