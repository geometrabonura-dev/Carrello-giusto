
from fastapi import APIRouter, Query, HTTPException
from .catalog_repository_v44 import CatalogRepositoryV44

router = APIRouter(prefix="/v4/catalog", tags=["catalog-v4"])

_repo = CatalogRepositoryV44()

@router.get("/search")
def search_catalog(q: str = Query(min_length=1, max_length=80)):
    items = _repo.search(q)
    return {
        "items": [
            {
                "product_key": p.product_key,
                "name": p.name,
                "brand": p.brand,
                "unit": p.unit,
                "default_quantity": p.default_quantity,
                "strict_brand": p.strict_brand,
                "allow_fractional_quantity": p.allow_fractional_quantity,
            }
            for p in items
        ]
    }

@router.get("/{product_key}")
def get_catalog_product(product_key: str):
    p = _repo.resolve_key(product_key)
    if not p:
        raise HTTPException(status_code=404, detail="Prodotto non trovato")
    return {
        "product_key": p.product_key,
        "name": p.name,
        "brand": p.brand,
        "unit": p.unit,
        "default_quantity": p.default_quantity,
        "strict_brand": p.strict_brand,
        "allow_fractional_quantity": p.allow_fractional_quantity,
    }
