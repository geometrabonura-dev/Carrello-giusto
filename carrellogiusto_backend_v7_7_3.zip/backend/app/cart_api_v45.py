
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional

from .request_models_v43 import CartItemV43
from .cart_resolution_v45 import resolve_cart_items, CartValidationError
from .optimizer_input_v45 import to_optimizer_items

router = APIRouter(prefix="/v4/cart", tags=["cart-v4"])

class ResolveCartRequest(BaseModel):
    items: list[CartItemV43]

@router.post("/resolve")
def resolve_cart(payload: ResolveCartRequest):
    try:
        resolved = resolve_cart_items(payload.items)
    except CartValidationError as e:
        raise HTTPException(status_code=422, detail=str(e))

    return {
        "items": to_optimizer_items(resolved),
        "count": len(resolved),
    }
