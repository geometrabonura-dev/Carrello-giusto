from html import escape
from fastapi import APIRouter, Depends
from fastapi.responses import HTMLResponse

from .auth import require_admin
from .product_substitution_admin_v71 import ProductSubstitutionAdminV71

router = APIRouter(
    prefix="/admin/substitution-console-v71",
    tags=["admin-substitution-console-v7-2"],
)

@router.get("", response_class=HTMLResponse, dependencies=[Depends(require_admin)])
def substitution_console_v72(status: str = "pending"):
    rows = ProductSubstitutionAdminV71().list(
        status=status or None,
        limit=200,
    )

    cards = []
    for row in rows:
        source = escape(str(row["source_product_key"]))
        alternative = escape(str(row["alternative_product_key"]))
        relation = escape(str(row["relation_type"]))
        proposed_by = escape(str(row.get("proposed_by") or "-"))
        note = escape(str(row.get("note") or ""))
        review_status = escape(str(row.get("review_status") or ""))

        buttons = ""
        if row.get("review_status") == "pending":
            buttons = f"""
              <button onclick="loadPreview('{source}','{alternative}')">Anteprima</button>
              <button onclick="approve('{source}','{alternative}',false)">Approva</button>
              <button onclick="rejectPair('{source}','{alternative}')">Rifiuta</button>
            """

        cards.append(f"""
        <section class="card">
          <h3>{source} → {alternative}</h3>
          <p><b>Stato:</b> {review_status}</p>
          <p><b>Tipo:</b> {relation}</p>
          <p><b>Proposto da:</b> {proposed_by}</p>
          <p><b>Nota:</b> {note or '-'}</p>
          <div class="actions">{buttons}</div>
        </section>
        """)

    html = f"""
    <html>
    <head>
      <title>CarrelloGiusto - Equivalenze v7.2</title>
      <style>
        body {{ font-family: sans-serif; background:#f6f6f6; margin:0; }}
        header {{ background:white; padding:20px 24px; border-bottom:1px solid #ddd; }}
        main {{ padding:24px; display:grid; gap:14px; }}
        .card {{ background:white; border:1px solid #ddd; border-radius:12px; padding:16px; }}
        .builder {{ display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-top:16px; }}
        .panel {{ background:#fafafa; border:1px solid #ddd; border-radius:10px; padding:12px; }}
        .results {{ max-height:260px; overflow:auto; display:grid; gap:6px; margin-top:8px; }}
        .result {{ padding:8px; border:1px solid #ddd; border-radius:8px; background:white; cursor:pointer; }}
        .actions {{ display:flex; gap:8px; flex-wrap:wrap; }}
        button {{ padding:8px 12px; cursor:pointer; }}
        pre {{ white-space:pre-wrap; background:#111; color:#eee; padding:12px; border-radius:8px; }}
      </style>
    </head>
    <body>
      <header>
        <h1>Equivalenze prodotto v7.2</h1>
        <form method="get">
          <select name="status">
            <option value="pending" {"selected" if status=="pending" else ""}>pending</option>
            <option value="approved" {"selected" if status=="approved" else ""}>approved</option>
            <option value="rejected" {"selected" if status=="rejected" else ""}>rejected</option>
            <option value="" {"selected" if not status else ""}>tutte</option>
          </select>
          <button type="submit">Filtra</button>
        </form>

        <div class="builder">
          <div class="panel">
            <h3>Prodotto sorgente</h3>
            <input id="sourceSearch" placeholder="nome, marca, EAN/GTIN..." />
            <button onclick="searchProducts('source')">Cerca</button>
            <div id="sourceResults" class="results"></div>
            <div id="sourceSelected"></div>
          </div>

          <div class="panel">
            <h3>Prodotto alternativo</h3>
            <input id="alternativeSearch" placeholder="nome, marca, EAN/GTIN..." />
            <button onclick="searchProducts('alternative')">Cerca</button>
            <div id="alternativeResults" class="results"></div>
            <div id="alternativeSelected"></div>
          </div>
        </div>

        <div class="actions" style="margin-top:12px">
          <button onclick="previewSelected()">Calcola anteprima</button>
          <button onclick="proposeSelected()">Proponi equivalenza</button>
        </div>
        <div id="preview"></div>
      </header>

      <main>{''.join(cards) or '<p>Nessuna equivalenza in questo stato.</p>'}</main>

      <script>
        let sourceSelected = null;
        let alternativeSelected = null;

        const headers = () => ({{
          'Content-Type':'application/json',
          'X-Admin-Token': localStorage.getItem('adminToken') || '',
          'X-Admin-Actor': 'browser-admin'
        }});

        function productHtml(p) {{
          const format = p.quantity != null
            ? `${{p.quantity}} ${{p.unit || ''}}`
            : 'formato n/d';
          const code = p.gtin || p.ean || 'GTIN/EAN n/d';
          return `<b>${{p.name}}</b><br/>${{p.brand || 'marca n/d'}} · ${{format}} · ${{code}}`;
        }}

        async function searchProducts(side) {{
          const input = document.getElementById(side + 'Search');
          const target = document.getElementById(side + 'Results');
          const q = input.value.trim();
          if (!q) return;
          const r = await fetch(
            '/admin/substitutions-v71/search-products?q=' +
            encodeURIComponent(q),
            {{ headers: headers() }}
          );
          const rows = await r.json();
          target.innerHTML = '';
          rows.forEach(p => {{
            const div = document.createElement('div');
            div.className = 'result';
            div.innerHTML = productHtml(p);
            div.onclick = () => selectProduct(side, p);
            target.appendChild(div);
          }});
        }}

        function selectProduct(side, p) {{
          if (side === 'source') sourceSelected = p;
          else alternativeSelected = p;
          document.getElementById(side + 'Selected').innerHTML =
            '<p><b>Selezionato:</b><br/>' + productHtml(p) + '</p>';
        }}

        async function previewPair(source, alternative) {{
          const qs = new URLSearchParams({{
            source_product_key:source,
            alternative_product_key:alternative
          }});
          const r = await fetch(
            '/admin/substitutions-v71/preview?' + qs,
            {{ headers:headers() }}
          );
          const data = await r.json();
          document.getElementById('preview').innerHTML =
            '<h3>Anteprima economica</h3><pre>' +
            JSON.stringify(data, null, 2) + '</pre>';
          return data;
        }}

        async function previewSelected() {{
          if (!sourceSelected || !alternativeSelected) {{
            alert('Seleziona entrambi i prodotti.');
            return;
          }}
          await previewPair(
            sourceSelected.product_key,
            alternativeSelected.product_key
          );
        }}

        async function proposeSelected() {{
          if (!sourceSelected || !alternativeSelected) {{
            alert('Seleziona entrambi i prodotti.');
            return;
          }}
          const r = await fetch('/admin/substitutions-v71/propose', {{
            method:'POST',
            headers:headers(),
            body:JSON.stringify({{
              source_product_key:sourceSelected.product_key,
              alternative_product_key:alternativeSelected.product_key,
              relation_type:'equivalent',
              note:'Proposta dalla console v7.2'
            }})
          }});
          if (r.ok) location.reload();
          else alert(await r.text());
        }}

        async function loadPreview(source, alternative) {{
          await previewPair(source, alternative);
          window.scrollTo({{ top:0, behavior:'smooth' }});
        }}

        async function approve(source, alternative, force) {{
          const preview = await previewPair(source, alternative);
          if (preview.comparison_status === 'not_comparable') {{
            if (!confirm('Il risparmio reale non è confrontabile. Continuare solo come override manuale?')) return;
            force = true;
          }}
          const r = await fetch('/admin/substitutions-v71/approve', {{
            method:'POST',
            headers:headers(),
            body:JSON.stringify({{
              source_product_key:source,
              alternative_product_key:alternative,
              force:force
            }})
          }});
          if (r.ok) location.reload();
          else alert(await r.text());
        }}

        async function rejectPair(source, alternative) {{
          const note = prompt('Motivo del rifiuto?') || '';
          const r = await fetch('/admin/substitutions-v71/reject', {{
            method:'POST',
            headers:headers(),
            body:JSON.stringify({{
              source_product_key:source,
              alternative_product_key:alternative,
              note:note
            }})
          }});
          if (r.ok) location.reload();
          else alert(await r.text());
        }}
      </script>
    </body>
    </html>
    """
    return HTMLResponse(html)
