
from prometheus_client import Counter, Histogram, Gauge, generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

REQUEST_COUNT = Counter(
    "spesa_smart_http_requests_total",
    "HTTP requests",
    ["method", "path", "status"],
)

REQUEST_LATENCY = Histogram(
    "spesa_smart_http_request_duration_seconds",
    "HTTP request latency",
    ["method", "path"],
)

IMPORT_RUNS = Counter(
    "spesa_smart_import_runs_total",
    "Import runs",
    ["status"],
)

ACTIVE_OFFERS = Gauge(
    "spesa_smart_active_offers",
    "Number of active offers",
)

VERIFIED_OFFERS = Gauge(
    "spesa_smart_verified_offers",
    "Number of verified offers",
)

UNMATCHED_PRODUCTS = Gauge(
    "spesa_smart_unmatched_products",
    "Pending unmatched products",
)

def render_metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
