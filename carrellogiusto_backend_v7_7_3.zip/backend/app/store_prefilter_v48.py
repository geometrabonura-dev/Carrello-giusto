
def prefilter_store_ids(pricebook, product_keys, max_candidates=12):
    """
    Reduce the store universe before combinations up to 6 stores.

    Ranking favors:
    1) cart coverage,
    2) lower sum of known item costs,
    3) deterministic store id.
    """
    rows = []
    for sid, store in pricebook.items():
        covered = 0
        subtotal = 0.0
        for key in product_keys:
            entry = store.get("items", {}).get(key)
            if entry:
                covered += 1
                subtotal += float(entry["cost"])

        rows.append((
            -covered,
            subtotal if covered else float("inf"),
            str(sid),
        ))

    rows.sort()
    return [sid for _, _, sid in rows[:max_candidates]]
