
def product_external_ref(raw: dict) -> str:
    if raw.get("ean"):
        return f"ean:{raw['ean']}"
    if raw.get("product_key"):
        return f"product_key:{raw['product_key']}"
    name = (raw.get("product_name") or raw.get("name") or "").strip()
    brand = (raw.get("brand") or "").strip()
    return f"name:{brand}|{name}".lower()

def store_external_ref(raw: dict) -> str | None:
    ref = (
        raw.get("store_external_ref")
        or raw.get("store_id")
        or raw.get("store")
    )
    return str(ref) if ref not in (None, "") else None
