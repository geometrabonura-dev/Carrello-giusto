
import json
from .db import get_conn

class ImportRepositoryV51:
    def create_run(self, source_key: str):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO offer_import_runs
                        (source_key, status, started_at)
                    VALUES (%s, 'running', NOW())
                    RETURNING id::text
                    """,
                    (source_key,),
                )
                return cur.fetchone()[0]

    def finish_run(self, run_id: str, status: str, metrics: dict):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    UPDATE offer_import_runs
                    SET status=%s, finished_at=NOW(), metrics=%s
                    WHERE id::text=%s
                    """,
                    (status, json.dumps(metrics), run_id),
                )

    def store_raw_offer(self, run_id: str, source_key: str, payload: dict):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO offer_raw
                        (import_run_id, source_key, raw_payload, imported_at)
                    VALUES (%s, %s, %s, NOW())
                    RETURNING id::text
                    """,
                    (run_id, source_key, json.dumps(payload)),
                )
                return cur.fetchone()[0]
