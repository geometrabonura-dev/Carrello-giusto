
import json
from .db import get_conn

class ReviewRepositoryV53:
    def enqueue_store(
        self,
        *,
        source_key: str,
        external_ref: str,
        payload: dict,
        import_run_id: str | None = None,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO import_review_queue (
                        review_type,
                        source_key,
                        external_ref,
                        payload,
                        import_run_id,
                        status,
                        created_at
                    )
                    VALUES (
                        'store',
                        %s,%s,%s,%s,
                        'pending',
                        NOW()
                    )
                    ON CONFLICT (review_type, source_key, external_ref, status)
                    DO UPDATE SET
                        payload=EXCLUDED.payload,
                        import_run_id=EXCLUDED.import_run_id,
                        updated_at=NOW()
                    RETURNING id::text
                    """,
                    (
                        source_key,
                        external_ref,
                        json.dumps(payload),
                        import_run_id,
                    ),
                )
                return cur.fetchone()[0]

    def enqueue_product(
        self,
        *,
        source_key: str,
        external_ref: str,
        payload: dict,
        import_run_id: str | None = None,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO import_review_queue (
                        review_type,
                        source_key,
                        external_ref,
                        payload,
                        import_run_id,
                        status,
                        created_at
                    )
                    VALUES (
                        'product',
                        %s,%s,%s,%s,
                        'pending',
                        NOW()
                    )
                    ON CONFLICT (review_type, source_key, external_ref, status)
                    DO UPDATE SET
                        payload=EXCLUDED.payload,
                        import_run_id=EXCLUDED.import_run_id,
                        updated_at=NOW()
                    RETURNING id::text
                    """,
                    (
                        source_key,
                        external_ref,
                        json.dumps(payload),
                        import_run_id,
                    ),
                )
                return cur.fetchone()[0]

    def pending(self, review_type: str | None = None, limit: int = 100):
        with get_conn() as conn:
            with conn.cursor() as cur:
                if review_type:
                    cur.execute(
                        """
                        SELECT id::text, review_type, source_key,
                               external_ref, payload, import_run_id::text,
                               status, created_at, updated_at
                        FROM import_review_queue
                        WHERE status='pending'
                          AND review_type=%s
                        ORDER BY created_at ASC
                        LIMIT %s
                        """,
                        (review_type, limit),
                    )
                else:
                    cur.execute(
                        """
                        SELECT id::text, review_type, source_key,
                               external_ref, payload, import_run_id::text,
                               status, created_at, updated_at
                        FROM import_review_queue
                        WHERE status='pending'
                        ORDER BY created_at ASC
                        LIMIT %s
                        """,
                        (limit,),
                    )
                rows = cur.fetchall()

        return [
            {
                "id": r[0],
                "review_type": r[1],
                "source_key": r[2],
                "external_ref": r[3],
                "payload": r[4] or {},
                "import_run_id": r[5],
                "status": r[6],
                "created_at": r[7].isoformat() if r[7] else None,
                "updated_at": r[8].isoformat() if r[8] else None,
            }
            for r in rows
        ]

    def resolve_store_review(
        self,
        *,
        review_id: str,
        source_key: str,
        external_ref: str,
        store_id: str,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    SELECT id
                    FROM sources
                    WHERE source_key=%s
                    LIMIT 1
                    """,
                    (source_key,),
                )
                source = cur.fetchone()
                if not source:
                    raise ValueError("Fonte non registrata.")

                cur.execute(
                    """
                    INSERT INTO store_sources (
                        store_id, source_id, external_ref, created_at
                    )
                    VALUES (%s, %s, %s, NOW())
                    ON CONFLICT (source_id, external_ref)
                    DO UPDATE SET store_id=EXCLUDED.store_id
                    """,
                    (store_id, source[0], external_ref),
                )

                cur.execute(
                    """
                    UPDATE import_review_queue
                    SET status='resolved',
                        resolved_entity_id=%s,
                        resolved_at=NOW(),
                        updated_at=NOW()
                    WHERE id::text=%s
                      AND review_type='store'
                    """,
                    (store_id, review_id),
                )

    def resolve_product_review(
        self,
        *,
        review_id: str,
        source_key: str,
        external_ref: str,
        product_id: str,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    """
                    INSERT INTO source_product_mappings (
                        source_key,
                        external_ref,
                        product_id,
                        created_at,
                        updated_at
                    )
                    VALUES (%s,%s,%s,NOW(),NOW())
                    ON CONFLICT (source_key, external_ref)
                    DO UPDATE SET
                        product_id=EXCLUDED.product_id,
                        updated_at=NOW()
                    """,
                    (source_key, external_ref, product_id),
                )

                cur.execute(
                    """
                    UPDATE import_review_queue
                    SET status='resolved',
                        resolved_entity_id=%s,
                        resolved_at=NOW(),
                        updated_at=NOW()
                    WHERE id::text=%s
                      AND review_type='product'
                    """,
                    (product_id, review_id),
                )


def reject_review(self, *, review_id: str, reason: str):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE import_review_queue
                SET status='rejected',
                    updated_at=NOW(),
                    resolved_at=NOW(),
                    payload = COALESCE(payload, '{}'::jsonb)
                              || jsonb_build_object('reject_reason', %s)
                WHERE id::text=%s
                """,
                (reason, review_id),
            )


def reopen_review(self, *, review_id: str, reason: str):
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                """
                UPDATE import_review_queue
                SET status='pending',
                    resolved_at=NULL,
                    resolved_entity_id=NULL,
                    updated_at=NOW(),
                    payload = COALESCE(payload, '{}'::jsonb)
                              || jsonb_build_object('reopen_reason', %s)
                WHERE id::text=%s
                """,
                (reason, review_id),
            )
