
from dataclasses import dataclass
from .offer_repository_v46 import OfferRepositoryV46

@dataclass(frozen=True)
class CoveredCartItem:
    item: dict
    offers: list

@dataclass(frozen=True)
class CartCoverageResult:
    covered: list
    missing: list

def resolve_offer_coverage(
    optimizer_items: list[dict],
    repo: OfferRepositoryV46 | None = None,
) -> CartCoverageResult:
    repo = repo or OfferRepositoryV46()
    covered = []
    missing = []

    for item in optimizer_items:
        offers = repo.find_candidates(
            product_key=item["product_key"],
            preferred_brand=item.get("preferred_brand"),
            allow_equivalents=bool(item.get("allow_equivalents", True)),
            strict_brand=bool(item.get("strict_brand", False)),
        )

        if offers:
            covered.append(
                CoveredCartItem(
                    item=item,
                    offers=offers,
                )
            )
        else:
            missing.append({
                "product_key": item["product_key"],
                "name": item.get("name"),
                "preferred_brand": item.get("preferred_brand"),
                "allow_equivalents": bool(item.get("allow_equivalents", True)),
            })

    return CartCoverageResult(
        covered=covered,
        missing=missing,
    )
