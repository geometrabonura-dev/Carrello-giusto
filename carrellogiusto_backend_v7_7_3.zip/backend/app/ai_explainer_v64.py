from __future__ import annotations

def build_explanation_context(result: dict) -> dict:
    """
    Expose only already-computed facts to the AI explainer.
    The AI is not asked to recompute totals.
    """
    rec = result.get("recommendation") or {}
    closest = result.get("closest_plan") or {}
    rule = result.get("rule") or {}

    return {
        "recommended_plan_key": rec.get("plan_key"),
        "effective_total": rec.get("effective_total"),
        "product_total": rec.get("product_total"),
        "travel_cost": rec.get("travel_cost"),
        "time_cost": rec.get("time_cost"),
        "stores_count": rec.get("stores_count"),
        "distance_km": rec.get("distance_km"),
        "saving_vs_closest": rec.get("saving_vs_closest"),
        "closest_effective_total": closest.get("effective_total"),
        "threshold": rule.get("min_saving_to_travel"),
        "strategy": rule.get("strategy"),
    }

def explanation_system_prompt() -> str:
    return (
        "Spiega il risultato CarrelloGiusto usando soltanto i numeri forniti. "
        "Non ricalcolare, non modificare, non inventare prezzi o disponibilità. "
        "Se un dato manca, dillo."
    )
