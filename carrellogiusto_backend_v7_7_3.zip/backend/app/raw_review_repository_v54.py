
from .db import get_conn

class RawReviewRepositoryV54:
    def payloads_for_resolved_mapping(
        self,
        *,
        source_key: str,
        external_ref: str,
        review_type: str,
        limit: int = 100,
    ):
        with get_conn() as conn:
            with conn.cursor() as cur:
                if review_type == "store":
                    cur.execute(
                        """
                        SELECT raw_payload
                        FROM offer_raw
                        WHERE source_key=%s
                          AND (
                            raw_payload->>'store_external_ref'=%s
                            OR raw_payload->>'store_id'=%s
                            OR raw_payload->>'store'=%s
                          )
                        ORDER BY imported_at DESC
                        LIMIT %s
                        """,
                        (
                            source_key,
                            external_ref,
                            external_ref,
                            external_ref,
                            limit,
                        ),
                    )
                elif review_type == "product":
                    if external_ref.startswith("ean:"):
                        ean = external_ref.split(":", 1)[1]
                        cur.execute(
                            """
                            SELECT raw_payload
                            FROM offer_raw
                            WHERE source_key=%s
                              AND raw_payload->>'ean'=%s
                            ORDER BY imported_at DESC
                            LIMIT %s
                            """,
                            (source_key, ean, limit),
                        )
                    elif external_ref.startswith("product_key:"):
                        key = external_ref.split(":", 1)[1]
                        cur.execute(
                            """
                            SELECT raw_payload
                            FROM offer_raw
                            WHERE source_key=%s
                              AND raw_payload->>'product_key'=%s
                            ORDER BY imported_at DESC
                            LIMIT %s
                            """,
                            (source_key, key, limit),
                        )
                    else:
                        cur.execute(
                            """
                            SELECT raw_payload
                            FROM offer_raw
                            WHERE source_key=%s
                            ORDER BY imported_at DESC
                            LIMIT %s
                            """,
                            (source_key, limit),
                        )
                else:
                    raise ValueError("review_type non valido")

                rows = cur.fetchall()

        return [r[0] for r in rows]
