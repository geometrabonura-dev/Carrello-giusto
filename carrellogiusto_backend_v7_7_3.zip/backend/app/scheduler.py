
import os
from apscheduler.schedulers.background import BackgroundScheduler
from .maintenance import expire_old_offers, mark_stale_offers

scheduler = BackgroundScheduler(timezone="Europe/Rome")

def _run_expire():
    try:
        expire_old_offers()
    except Exception as exc:
        print(f"[scheduler] expire failed: {exc}")

def _run_stale():
    try:
        hours = int(os.getenv("STALE_AFTER_HOURS", "48"))
        mark_stale_offers(hours)
    except Exception as exc:
        print(f"[scheduler] stale failed: {exc}")

def start_scheduler():
    if scheduler.running:
        return

    scheduler.add_job(
        _run_expire,
        "interval",
        hours=6,
        id="expire_offers",
        replace_existing=True,
    )
    scheduler.add_job(
        _run_stale,
        "interval",
        hours=6,
        id="mark_stale",
        replace_existing=True,
    )
    scheduler.start()

def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown(wait=False)
