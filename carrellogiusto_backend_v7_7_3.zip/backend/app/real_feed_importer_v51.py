
from dataclasses import asdict
from .real_offer_models_v51 import RealOfferInput
from .verification_policy_v51 import decide_verification

class RealFeedImporterV51:
    """
    Pure decision/orchestration layer.

    It does NOT scrape HTML, bypass login/CAPTCHA, or claim that an official
    website page is an authorized machine-readable feed.
    """

    def evaluate_offer(
        self,
        offer: RealOfferInput,
        *,
        product_match_confidence: float,
        store_resolved: bool,
    ):
        decision = decide_verification(
            source_key=offer.source_key,
            product_match_confidence=product_match_confidence,
            store_resolved=store_resolved,
            has_valid_price=offer.price > 0,
        )

        return {
            "offer": asdict(offer),
            "decision": decision.to_dict(),
        }
