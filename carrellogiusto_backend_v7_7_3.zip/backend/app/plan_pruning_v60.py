
from itertools import combinations

def candidate_store_sets(store_ids, max_stores, *, max_candidates=10):
    """
    Generate store combinations conservatively.
    Caller should pre-sort stores by coverage and known subtotal.
    """
    ids = list(store_ids)[:max_candidates]

    for size in range(1, min(max_stores, len(ids)) + 1):
        for combo in combinations(ids, size):
            yield combo

def lower_bound_effective_cost(*, product_total_lb, travel_cost_lb=0.0, time_cost_lb=0.0):
    return float(product_total_lb) + float(travel_cost_lb) + float(time_cost_lb)

def should_prune(*, lower_bound, incumbent_effective_total, epsilon=1e-9):
    if incumbent_effective_total is None:
        return False
    return lower_bound >= incumbent_effective_total - epsilon
