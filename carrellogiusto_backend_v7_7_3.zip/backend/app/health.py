
from .db import get_conn
from .repository_factory import get_repository

def database_health():
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return {"ok": True}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}

def liveness():
    return {"status": "alive"}

def readiness():
    db = database_health()
    repo = get_repository()
    ready = db["ok"]
    return {
        "status": "ready" if ready else "not_ready",
        "ready": ready,
        "database": db,
        "repository": repo.__class__.__name__,
    }

def detailed_health():
    db = database_health()
    repo = get_repository()
    return {
        "status": "ok" if db["ok"] else "degraded",
        "database": db,
        "repository": repo.__class__.__name__,
        "components": {
            "import_pipeline": "enabled",
            "quality_policy": "enabled",
            "review_queue": "enabled",
            "scheduler": "enabled",
            "job_queue": "enabled",
            "rate_limit": "enabled",
            "audit_log": "enabled",
        },
    }
