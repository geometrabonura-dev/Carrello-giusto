
ALTER TABLE stores
    ADD COLUMN IF NOT EXISTS external_ref TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS uq_stores_external_ref
    ON stores(external_ref)
    WHERE external_ref IS NOT NULL;

ALTER TABLE offers
    ADD CONSTRAINT uq_offer_store_product_source
    UNIQUE (store_id, product_id, source_id);

CREATE INDEX IF NOT EXISTS idx_offers_checked_at
    ON offers(checked_at);

CREATE INDEX IF NOT EXISTS idx_raw_offers_external_refs
    ON raw_offers(external_store_ref, external_product_ref);
