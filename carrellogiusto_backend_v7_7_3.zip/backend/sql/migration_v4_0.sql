
CREATE TABLE IF NOT EXISTS schema_migrations (
    filename TEXT PRIMARY KEY,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_choice_history_user_strategy
ON choice_history(user_id, strategy);

CREATE INDEX IF NOT EXISTS idx_choice_feedback_user_type
ON choice_feedback(user_id, feedback_type);
