
ALTER TABLE sources
    ADD COLUMN IF NOT EXISTS completeness_score NUMERIC(5,4) NOT NULL DEFAULT 0.8000,
    ADD COLUMN IF NOT EXISTS historical_accuracy NUMERIC(5,4) NOT NULL DEFAULT 0.8000,
    ADD COLUMN IF NOT EXISTS last_success_at TIMESTAMPTZ;

ALTER TABLE offers
    ADD COLUMN IF NOT EXISTS quality_score NUMERIC(5,4),
    ADD COLUMN IF NOT EXISTS quality_reason TEXT;

CREATE INDEX IF NOT EXISTS idx_offers_quality_score
    ON offers(quality_score);

CREATE INDEX IF NOT EXISTS idx_sources_last_success
    ON sources(last_success_at);
