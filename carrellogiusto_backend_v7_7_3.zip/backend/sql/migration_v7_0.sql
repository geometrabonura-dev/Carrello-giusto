-- CarrelloGiusto v7.0
-- Curated/approved product substitution relationships.

CREATE TABLE IF NOT EXISTS product_substitutions (
    source_product_key TEXT NOT NULL,
    alternative_product_key TEXT NOT NULL,
    relation_type TEXT NOT NULL DEFAULT 'equivalent',
    approved BOOLEAN NOT NULL DEFAULT FALSE,
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (source_product_key, alternative_product_key)
);

CREATE INDEX IF NOT EXISTS ix_product_substitutions_source_approved
    ON product_substitutions(source_product_key, approved);
