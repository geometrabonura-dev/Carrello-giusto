
ALTER TABLE products
    ADD COLUMN IF NOT EXISTS product_key TEXT,
    ADD COLUMN IF NOT EXISTS default_quantity NUMERIC(10,3) NOT NULL DEFAULT 1.0,
    ADD COLUMN IF NOT EXISTS strict_brand BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS allow_fractional_quantity BOOLEAN NOT NULL DEFAULT FALSE;

CREATE UNIQUE INDEX IF NOT EXISTS idx_products_product_key
ON products(product_key)
WHERE product_key IS NOT NULL;

UPDATE products
SET product_key = CASE
    WHEN LOWER(name) LIKE '%pasta%' AND quantity = 1 AND LOWER(unit) IN ('kg','kilogram','kilograms')
        THEN 'pasta1kg'
    WHEN LOWER(name) LIKE '%olio%' AND LOWER(name) LIKE '%evo%'
        THEN 'olio_evo_1l'
    WHEN LOWER(COALESCE(brand,'')) = 'rio mare' AND LOWER(name) LIKE '%tonno%'
        THEN 'rio_mare_tonno'
    WHEN LOWER(name) LIKE '%uva%' AND LOWER(name) LIKE '%semi%'
        THEN 'uva_senza_semi'
    WHEN LOWER(name) LIKE '%fiorentina%'
        THEN 'fiorentina'
    ELSE product_key
END
WHERE product_key IS NULL;

UPDATE products
SET
    strict_brand = TRUE,
    allow_fractional_quantity = FALSE
WHERE product_key = 'rio_mare_tonno';

UPDATE products
SET allow_fractional_quantity = TRUE
WHERE LOWER(unit) IN ('kg','l','litro','liter');
