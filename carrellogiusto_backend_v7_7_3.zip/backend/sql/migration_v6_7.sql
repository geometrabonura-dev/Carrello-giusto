-- CarrelloGiusto v6.7
-- User-confirmed mappings for AI/free-text catalog resolution.

CREATE TABLE IF NOT EXISTS user_catalog_mappings (
    user_id TEXT NOT NULL,
    normalized_label TEXT NOT NULL,
    normalized_brand TEXT NOT NULL DEFAULT '',
    product_key TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (user_id, normalized_label, normalized_brand)
);

CREATE INDEX IF NOT EXISTS ix_user_catalog_mappings_product_key
    ON user_catalog_mappings(product_key);
