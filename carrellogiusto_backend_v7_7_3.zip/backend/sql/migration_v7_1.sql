-- CarrelloGiusto v7.1
ALTER TABLE product_substitutions
    ADD COLUMN IF NOT EXISTS review_status TEXT NOT NULL DEFAULT 'pending',
    ADD COLUMN IF NOT EXISTS proposed_by TEXT,
    ADD COLUMN IF NOT EXISTS reviewed_by TEXT;

UPDATE product_substitutions
SET review_status = CASE WHEN approved THEN 'approved' ELSE 'pending' END
WHERE review_status IS NULL OR review_status = '';

CREATE INDEX IF NOT EXISTS ix_product_substitutions_review_status
    ON product_substitutions(review_status);
