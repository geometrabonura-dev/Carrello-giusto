
ALTER TABLE offers
    ADD COLUMN IF NOT EXISTS match_method TEXT,
    ADD COLUMN IF NOT EXISTS match_confidence NUMERIC(5,4),
    ADD COLUMN IF NOT EXISTS source_quality_score NUMERIC(5,4);

CREATE TABLE IF NOT EXISTS unmatched_product_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    import_run_id UUID REFERENCES import_runs(id) ON DELETE SET NULL,
    source_id UUID REFERENCES sources(id) ON DELETE SET NULL,
    external_store_ref TEXT,
    external_product_ref TEXT NOT NULL,
    product_name TEXT NOT NULL,
    ean TEXT,
    brand TEXT,
    best_candidate_name TEXT,
    match_confidence NUMERIC(5,4) NOT NULL DEFAULT 0,
    resolved_product_id UUID REFERENCES products(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at TIMESTAMPTZ
);

CREATE UNIQUE INDEX IF NOT EXISTS uq_unmatched_source_product
    ON unmatched_product_queue(source_id, external_product_ref);

CREATE INDEX IF NOT EXISTS idx_unmatched_status
    ON unmatched_product_queue(status);

CREATE INDEX IF NOT EXISTS idx_offers_match_confidence
    ON offers(match_confidence);
