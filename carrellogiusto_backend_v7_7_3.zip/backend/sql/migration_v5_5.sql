
CREATE TABLE IF NOT EXISTS manual_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor TEXT NOT NULL,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id UUID NULL,
    source_key TEXT NULL,
    details JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_manual_audit_log_created
    ON manual_audit_log(created_at DESC);

CREATE INDEX IF NOT EXISTS ix_manual_audit_log_action
    ON manual_audit_log(action);
