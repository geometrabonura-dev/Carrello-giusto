
ALTER TABLE IF EXISTS offers
    ADD COLUMN IF NOT EXISTS freshness_status TEXT DEFAULT 'unknown';

CREATE INDEX IF NOT EXISTS ix_offers_source_status
    ON offers(source_status);

CREATE INDEX IF NOT EXISTS ix_offers_source_checked_at
    ON offers(source_checked_at);

CREATE INDEX IF NOT EXISTS ix_offer_raw_source_imported
    ON offer_raw(source_key, imported_at DESC);
