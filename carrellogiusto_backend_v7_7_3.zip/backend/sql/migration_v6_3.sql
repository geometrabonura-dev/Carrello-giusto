-- CarrelloGiusto v6.3
-- Product identity hardening.

ALTER TABLE products
    ADD COLUMN IF NOT EXISTS gtin TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS ux_products_gtin_not_null
    ON products(gtin)
    WHERE gtin IS NOT NULL AND gtin <> '';

ALTER TABLE source_product_mappings
    ADD COLUMN IF NOT EXISTS variant_key TEXT;

CREATE INDEX IF NOT EXISTS ix_source_product_mappings_variant
    ON source_product_mappings(source_key, variant_key);
