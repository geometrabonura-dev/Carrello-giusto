
CREATE TABLE IF NOT EXISTS choice_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    strategy TEXT NOT NULL,
    chosen_plan_key TEXT NOT NULL,
    recommended_plan_key TEXT,
    accepted_recommendation BOOLEAN NOT NULL DEFAULT FALSE,
    stores_count INTEGER NOT NULL,
    product_total NUMERIC(10,2) NOT NULL,
    travel_cost NUMERIC(10,2) NOT NULL DEFAULT 0,
    time_cost NUMERIC(10,2) NOT NULL DEFAULT 0,
    effective_total NUMERIC(10,2) NOT NULL,
    duration_minutes NUMERIC(10,2),
    distance_km NUMERIC(10,3),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_choice_history_user_created
ON choice_history(user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS choice_feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id TEXT NOT NULL,
    choice_id UUID REFERENCES choice_history(id) ON DELETE SET NULL,
    feedback_type TEXT NOT NULL,
    value NUMERIC(10,4),
    note TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_choice_feedback_user_created
ON choice_feedback(user_id, created_at DESC);
