
ALTER TABLE IF EXISTS sources
    ADD COLUMN IF NOT EXISTS source_key TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS ux_sources_source_key
    ON sources(source_key)
    WHERE source_key IS NOT NULL;

ALTER TABLE IF EXISTS offers
    ADD COLUMN IF NOT EXISTS verification_status TEXT
        DEFAULT 'accepted_unverified';

ALTER TABLE IF EXISTS offers
    ADD COLUMN IF NOT EXISTS source_key TEXT;

ALTER TABLE IF EXISTS offers
    ADD COLUMN IF NOT EXISTS source_checked_at TIMESTAMPTZ;

ALTER TABLE IF EXISTS offers
    ADD COLUMN IF NOT EXISTS store_external_ref TEXT;

ALTER TABLE IF EXISTS offer_raw
    ADD COLUMN IF NOT EXISTS source_key TEXT;

ALTER TABLE IF EXISTS offer_raw
    ADD COLUMN IF NOT EXISTS imported_at TIMESTAMPTZ DEFAULT NOW();

ALTER TABLE IF EXISTS offer_import_runs
    ADD COLUMN IF NOT EXISTS source_key TEXT;

ALTER TABLE IF EXISTS offer_import_runs
    ADD COLUMN IF NOT EXISTS metrics JSONB DEFAULT '{}'::jsonb;

INSERT INTO sources (name, source_type, source_key, quality_score, enabled)
SELECT 'Esselunga official', 'official', 'esselunga_official', 0.95, TRUE
WHERE NOT EXISTS (
    SELECT 1 FROM sources WHERE source_key='esselunga_official'
);

INSERT INTO sources (name, source_type, source_key, quality_score, enabled)
SELECT 'Conad official', 'official', 'conad_official', 0.95, TRUE
WHERE NOT EXISTS (
    SELECT 1 FROM sources WHERE source_key='conad_official'
);
