-- CarrelloGiusto v6.2
-- Supports direct freshness filtering on live offer reads.

ALTER TABLE offers
    ADD COLUMN IF NOT EXISTS freshness_status TEXT DEFAULT 'unknown';

CREATE INDEX IF NOT EXISTS ix_offers_freshness_live
    ON offers(freshness_status, source_checked_at, valid_to);

-- Existing rows are intentionally NOT mass-marked fresh.
-- They must be refreshed/reimported by maintenance/import logic.
