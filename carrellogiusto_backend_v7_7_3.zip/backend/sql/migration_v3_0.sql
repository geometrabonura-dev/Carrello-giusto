
CREATE INDEX IF NOT EXISTS idx_stores_lat_lon ON stores(latitude, longitude);
ALTER TABLE stores ADD COLUMN IF NOT EXISTS location_checked_at TIMESTAMPTZ;
