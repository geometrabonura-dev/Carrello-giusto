
CREATE TABLE IF NOT EXISTS store_sources (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    store_id UUID NOT NULL REFERENCES stores(id) ON DELETE CASCADE,
    source_id UUID NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
    external_ref TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(source_id, external_ref)
);

CREATE INDEX IF NOT EXISTS ix_store_sources_store_id
    ON store_sources(store_id);

CREATE INDEX IF NOT EXISTS ix_offer_import_runs_source_started
    ON offer_import_runs(source_key, started_at DESC);

CREATE INDEX IF NOT EXISTS ix_offer_raw_run
    ON offer_raw(import_run_id);

CREATE INDEX IF NOT EXISTS ix_offers_source_key
    ON offers(source_key);

CREATE INDEX IF NOT EXISTS ix_offers_verification_status
    ON offers(verification_status);
