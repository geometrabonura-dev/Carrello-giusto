
CREATE TABLE IF NOT EXISTS import_review_queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    review_type TEXT NOT NULL CHECK (review_type IN ('store','product')),
    source_key TEXT NOT NULL,
    external_ref TEXT NOT NULL,
    payload JSONB NOT NULL DEFAULT '{}'::jsonb,
    import_run_id UUID NULL REFERENCES offer_import_runs(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','resolved','rejected')),
    resolved_entity_id UUID NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NULL,
    resolved_at TIMESTAMPTZ NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS ux_review_queue_pending
    ON import_review_queue(review_type, source_key, external_ref, status)
    WHERE status='pending';

CREATE INDEX IF NOT EXISTS ix_review_queue_status_type
    ON import_review_queue(status, review_type, created_at);

CREATE TABLE IF NOT EXISTS source_product_mappings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_key TEXT NOT NULL,
    external_ref TEXT NOT NULL,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(source_key, external_ref)
);

CREATE INDEX IF NOT EXISTS ix_source_product_mappings_product
    ON source_product_mappings(product_id);
