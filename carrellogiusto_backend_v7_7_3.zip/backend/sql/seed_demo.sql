
INSERT INTO products (canonical_name, brand, category, quantity_value, quantity_unit, equivalent_group, strict_brand)
VALUES
('Pasta 1 kg', NULL, 'pasta', 1, 'kg', 'pasta-secca', FALSE),
('Olio 1 L', NULL, 'olio', 1, 'L', 'olio-evo', FALSE),
('Rio Mare all''olio', 'Rio Mare', 'tonno', 240, 'g', 'tonno-olio-rio-mare', TRUE),
('Uva senza semi 1 kg', NULL, 'frutta', 1, 'kg', 'uva-senza-semi', FALSE),
('Fiorentina', NULL, 'carne', 1, 'kg', 'fiorentina', FALSE)
ON CONFLICT DO NOTHING;
