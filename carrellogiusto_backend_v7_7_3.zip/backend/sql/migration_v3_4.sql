
CREATE TABLE IF NOT EXISTS user_preferences (
    user_id TEXT PRIMARY KEY,
    radius_km NUMERIC(6,2) NOT NULL DEFAULT 10.0,
    travel_profile TEXT NOT NULL DEFAULT 'car',
    min_saving_to_travel NUMERIC(8,2) NOT NULL DEFAULT 3.0,
    max_travel_minutes NUMERIC(8,2),
    max_stores INTEGER NOT NULL DEFAULT 3,
    vehicle_cost_per_km NUMERIC(8,4),
    time_value_per_hour NUMERIC(8,2),
    weight_saving NUMERIC(6,4) NOT NULL DEFAULT 0.50,
    weight_time NUMERIC(6,4) NOT NULL DEFAULT 0.25,
    weight_simplicity NUMERIC(6,4) NOT NULL DEFAULT 0.25,
    store_penalty_eur NUMERIC(8,2) NOT NULL DEFAULT 0.75,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
