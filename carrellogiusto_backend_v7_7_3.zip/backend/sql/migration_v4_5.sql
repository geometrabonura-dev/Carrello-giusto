
ALTER TABLE products
    ADD COLUMN IF NOT EXISTS canonical_unit TEXT;

UPDATE products
SET canonical_unit = CASE
    WHEN LOWER(unit) IN ('kg', 'kilogram', 'kilograms') THEN 'kg'
    WHEN LOWER(unit) IN ('l', 'litro', 'liter', 'liters') THEN 'l'
    WHEN LOWER(unit) IN ('confezione', 'package', 'pack') THEN 'pack'
    WHEN LOWER(unit) IN ('pezzo', 'piece') THEN 'piece'
    ELSE LOWER(unit)
END
WHERE canonical_unit IS NULL;

CREATE INDEX IF NOT EXISTS idx_products_product_key_unit
ON products(product_key, canonical_unit);
