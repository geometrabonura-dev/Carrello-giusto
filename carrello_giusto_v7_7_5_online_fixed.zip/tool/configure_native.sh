#!/usr/bin/env bash
set -euo pipefail

if [ -f android/app/src/main/AndroidManifest.xml ]; then
python - <<'PY'
from pathlib import Path
p = Path("android/app/src/main/AndroidManifest.xml")
s = p.read_text()
end = s.find(">", s.find("<manifest"))
permissions = []
if "android.permission.INTERNET" not in s:
    permissions.append('\n    <uses-permission android:name="android.permission.INTERNET" />')
if "android.permission.ACCESS_FINE_LOCATION" not in s:
    permissions.append('\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />')
    permissions.append('\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />')
if permissions:
    s = s[:end+1] + "".join(permissions) + s[end+1:]
s = s.replace('android:label="spesa_smart"', 'android:label="CarrelloGiusto"')
p.write_text(s)
PY
fi

if [ -f ios/Runner/Info.plist ]; then
python - <<'PY'
from pathlib import Path
p = Path("ios/Runner/Info.plist")
s = p.read_text()
if "NSLocationWhenInUseUsageDescription" not in s:
    insert = (
        "<key>NSLocationWhenInUseUsageDescription</key>\\n"
        "<string>CarrelloGiusto usa la posizione per trovare i supermercati vicini e calcolare i tragitti.</string>\\n"
    )
    s = s.replace("</dict>", insert + "</dict>", 1)
s = s.replace("<string>spesa_smart</string>", "<string>CarrelloGiusto</string>")
p.write_text(s)
PY
fi


# Applica il logo CarrelloGiusto anche come icona launcher Android.
if [ -f assets/brand/carrellogiusto_app_icon.png ] && [ -d android/app/src/main/res ]; then
  for folder in mipmap-mdpi mipmap-hdpi mipmap-xhdpi mipmap-xxhdpi mipmap-xxxhdpi; do
    mkdir -p "android/app/src/main/res/$folder"
    cp assets/brand/carrellogiusto_app_icon.png "android/app/src/main/res/$folder/ic_launcher.png"
  done
fi

echo "Configurazione nativa CarrelloGiusto applicata."
