import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/optimization_result.dart';
import '../models/shopping_item.dart';
import 'api_error_policy_v60.dart';
import 'retry_policy.dart';

class ApiServiceV49 {
  final String baseUrl;
  final http.Client client;
  final RetryPolicy retryPolicy;

  ApiServiceV49({
    this.baseUrl = 'https://carrello-giusto.onrender.com',
    http.Client? client,
    this.retryPolicy = const RetryPolicy(),
  }) : client = client ?? http.Client();

  Future<OptimizationResult> optimize({
    required List<ShoppingItem> items,
    required Map<String, double> origin,
    required String userId,
    required String strategy,
    required double radiusKm,
    required String travelProfile,
    required double minSavingToTravel,
    required int maxStores,
    double? budgetCap,
  }) async {
    late http.Response response;

    try {
      response = await retryPolicy.run(() {
        return client
            .post(
              Uri.parse('$baseUrl/v4/cart/optimize-v48'),
              headers: {'Content-Type': 'application/json'},
              body: jsonEncode({
                'items': items.map((e) => e.toApiJson()).toList(),
                'origin': origin,
                'user_id': userId,
                'strategy': strategy,
                'radius_km': radiusKm,
                'travel_profile': travelProfile,
                'min_saving_to_travel': minSavingToTravel,
                'max_stores': maxStores,
                if (budgetCap != null && budgetCap > 0)
                  'budget_cap': budgetCap,
              }),
            )
            .timeout(const Duration(seconds: 12));
      });
    } on TimeoutException {
      throw const ApiException(
        code: 'timeout',
        message: 'Timeout durante l’ottimizzazione.',
        statusCode: 408,
      );
    } on http.ClientException catch (e) {
      throw ApiException(
        code: 'network_error',
        message: e.message,
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw _parseApiError(response);
    }

    try {
      return OptimizationResult.fromApi(
        Map<String, dynamic>.from(jsonDecode(response.body)),
      );
    } on FormatException catch (e) {
      throw ApiException(
        code: 'invalid_response',
        message: e.message,
        statusCode: response.statusCode,
      );
    } catch (e) {
      throw ApiException(
        code: 'invalid_response',
        message: 'Risposta API non interpretabile: $e',
        statusCode: response.statusCode,
      );
    }
  }

  ApiException _parseApiError(http.Response response) {
    dynamic decoded;
    try {
      decoded = jsonDecode(response.body);
    } catch (_) {
      decoded = null;
    }

    Map<String, dynamic> detail = {};
    if (decoded is Map) {
      final rawDetail = decoded['detail'];
      if (rawDetail is Map) {
        detail = Map<String, dynamic>.from(rawDetail);
      } else if (rawDetail != null) {
        detail = {'message': rawDetail.toString()};
      }
    }

    var code = detail['code']?.toString();
    var message = detail['message']?.toString();

    if (response.statusCode == 422) {
      code ??= 'validation_error';
      message ??= 'Dati non validi.';
    } else if (response.statusCode == 429) {
      code ??= 'temporary_unavailable';
      message ??= 'Troppe richieste.';
    } else if (response.statusCode >= 500) {
      code ??= 'server_error';
      message ??= 'Errore del server.';
    }

    code ??= 'api_error';
    message ??= 'Ottimizzazione fallita (${response.statusCode}).';

    return ApiException(
      statusCode: response.statusCode,
      code: code,
      message: message,
      details: detail,
    );
  }
}
