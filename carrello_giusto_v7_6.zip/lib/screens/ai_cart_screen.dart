import 'package:flutter/material.dart';

import '../models/ai_cart_assistant_result.dart';
import '../models/ai_cart_conversation.dart';
import '../models/ai_cart_draft.dart';
import '../models/shopping_item.dart';
import '../services/ai_cart_chat_service_v68.dart';
import '../services/ai_cart_service_v65.dart';
import '../models/catalog_product.dart';
import 'catalog_search_screen.dart';

class AiCartScreen extends StatefulWidget {
  final String userId;

  const AiCartScreen({
    super.key,
    required this.userId,
  });

  @override
  State<AiCartScreen> createState() => _AiCartScreenState();
}

class _ChatLine {
  final bool fromUser;
  final String text;

  const _ChatLine({
    required this.fromUser,
    required this.text,
  });
}

class _AiCartScreenState extends State<AiCartScreen> {
  final _controller = TextEditingController();
  final _chatService = AiCartChatServiceV68();
  final _mappingService = AiCartServiceV65();

  AiCartConversationState _state = const AiCartConversationState();
  final List<_ChatLine> _messages = const [
    _ChatLine(
      fromUser: false,
      text:
          'Dimmi cosa ti serve. Puoi anche modificare la lista dopo, per esempio: '
          '“aggiungi il latte”, “togli l’uva” o “preferisco un solo supermercato”.',
    ),
  ].toList();

  bool _loading = false;
  String? _error;

  Future<void> _send() async {
    final message = _controller.text.trim();
    if (message.isEmpty || _loading) return;

    setState(() {
      _messages.add(_ChatLine(fromUser: true, text: message));
      _controller.clear();
      _loading = true;
      _error = null;
    });

    try {
      final result = await _chatService.send(
        userId: widget.userId,
        message: message,
        state: _state,
      );

      if (!mounted) return;
      setState(() {
        _state = result.state;
        _messages.add(
          _ChatLine(
            fromUser: false,
            text: result.reply,
          ),
        );
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'Non riesco ad aggiornare la conversazione in questo momento.';
      });
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  Future<void> _chooseCandidate(
    AiCartDraftItem item,
    int index,
  ) async {
    if (item.catalogCandidates.isEmpty) return;

    final selected = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      showDragHandle: true,
      builder: (context) {
        return SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: [
              const ListTile(
                title: Text(
                  'Quale prodotto intendevi?',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  'La scelta verrà ricordata per richieste simili.',
                ),
              ),
              ...item.catalogCandidates.map(
                (candidate) => ListTile(
                  title: Text((candidate['label'] ?? '').toString()),
                  subtitle: Text(
                    [
                      if (candidate['brand'] != null)
                        candidate['brand'].toString(),
                      if (candidate['unit'] != null)
                        candidate['unit'].toString(),
                      if (candidate['confidence'] != null)
                        '${(((candidate['confidence'] as num).toDouble()) * 100).toStringAsFixed(0)}%',
                    ].join(' · '),
                  ),
                  onTap: () => Navigator.of(context).pop(candidate),
                ),
              ),
            ],
          ),
        );
      },
    );

    if (selected == null) return;
    final productKey = (selected['product_key'] ?? '').toString();
    if (productKey.isEmpty) return;

    try {
      await _mappingService.confirmMapping(
        userId: widget.userId,
        label: item.label,
        preferredBrand: item.preferredBrand,
        productKey: productKey,
      );

      if (!mounted) return;

      final items = [..._state.items];
      items[index] = item.copyWith(
        productKey: productKey,
        matchStatus: 'user_confirmed',
        matchConfidence: 1.0,
      );

      setState(() {
        _state = AiCartConversationState(
          items: items,
          preferences: _state.preferences,
          notes: _state.notes,
        );
        _error = null;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'Non riesco a salvare la correzione del prodotto.';
      });
    }
  }


  Future<void> _searchFullCatalog(
    AiCartDraftItem item,
    int index,
  ) async {
    final product = await Navigator.of(context).push<CatalogProduct>(
      MaterialPageRoute(
        builder: (_) => CatalogSearchScreen(
          initialQuery: item.label,
        ),
      ),
    );
    if (product == null || !mounted) return;

    try {
      await _mappingService.confirmMapping(
        userId: widget.userId,
        label: item.label,
        preferredBrand: item.preferredBrand,
        productKey: product.productKey,
      );

      if (!mounted) return;
      final items = [..._state.items];
      items[index] = item.copyWith(
        productKey: product.productKey,
        label: product.name,
        unit: product.unit,
        preferredBrand: product.brand,
        clearPreferredBrand: product.brand == null,
        matchStatus: 'user_confirmed',
        matchConfidence: 1.0,
        catalogCandidates: const [],
      );

      setState(() {
        _state = AiCartConversationState(
          items: items,
          preferences: _state.preferences,
          notes: _state.notes,
        );
        _error = null;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _error = 'Non riesco a salvare la scelta dal catalogo.';
      });
    }
  }

  Future<void> _editItem(
    AiCartDraftItem item,
    int index,
  ) async {
    final quantityController = TextEditingController(
      text: item.quantity.toString(),
    );
    final brandController = TextEditingController(
      text: item.preferredBrand ?? '',
    );
    var unit = item.unit;
    var allowEquivalents = item.allowEquivalents;

    const units = <String>[
      'piece',
      'pack',
      'kg',
      'g',
      'l',
      'ml',
    ];
    if (!units.contains(unit)) {
      unit = 'piece';
    }

    final updated = await showDialog<AiCartDraftItem>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: Text('Modifica ${item.label}'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: quantityController,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: const InputDecoration(
                        labelText: 'Quantità',
                      ),
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      value: unit,
                      decoration: const InputDecoration(
                        labelText: 'Unità',
                      ),
                      items: units
                          .map(
                            (u) => DropdownMenuItem(
                              value: u,
                              child: Text(u),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setDialogState(() => unit = value);
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: brandController,
                      decoration: const InputDecoration(
                        labelText: 'Marca preferita (facoltativa)',
                      ),
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      value: allowEquivalents,
                      title: const Text('Accetta equivalenti'),
                      onChanged: (value) {
                        setDialogState(() => allowEquivalents = value);
                      },
                    ),
                    const Text(
                      'Se cambi marca o unità, il collegamento al catalogo '
                      'verrà ricontrollato prima dell’ottimizzazione.',
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Annulla'),
                ),
                FilledButton(
                  onPressed: () {
                    final normalized = quantityController.text
                        .trim()
                        .replaceAll(',', '.');
                    final quantity = double.tryParse(normalized);
                    if (quantity == null || quantity <= 0 || quantity > 999) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text(
                            'Inserisci una quantità valida maggiore di zero.',
                          ),
                        ),
                      );
                      return;
                    }

                    final brand = brandController.text.trim();
                    final identityChanged =
                        unit != item.unit ||
                        brand != (item.preferredBrand ?? '');

                    Navigator.of(context).pop(
                      item.copyWith(
                        quantity: quantity,
                        unit: unit,
                        preferredBrand: brand.isEmpty ? null : brand,
                        clearPreferredBrand: brand.isEmpty,
                        allowEquivalents: allowEquivalents,
                        clearProductKey: identityChanged,
                        matchStatus:
                            identityChanged ? 'needs_confirmation' : item.matchStatus,
                        matchConfidence:
                            identityChanged ? 0.0 : item.matchConfidence,
                        catalogCandidates:
                            identityChanged ? const [] : item.catalogCandidates,
                      ),
                    );
                  },
                  child: const Text('Salva'),
                ),
              ],
            );
          },
        );
      },
    );

    quantityController.dispose();
    brandController.dispose();

    if (updated == null || !mounted) return;

    final items = [..._state.items];
    items[index] = updated;
    setState(() {
      _state = AiCartConversationState(
        items: items,
        preferences: _state.preferences,
        notes: _state.notes,
      );
      _error = null;
    });
  }

  void _finish() {
    final unresolved = _state.items
        .where((e) => e.productKey == null || e.productKey!.isEmpty)
        .toList();

    if (unresolved.isNotEmpty) {
      setState(() {
        _error =
            'Ci sono ancora ${unresolved.length} articoli da confermare nel catalogo.';
      });
      return;
    }

    final items = _state.items
        .map(
          (e) => ShoppingItem(
            productKey: e.productKey!,
            label: e.label,
            quantity: e.quantity,
            unit: e.unit,
            preferredBrand: e.preferredBrand,
            allowEquivalents: e.allowEquivalents,
          ),
        )
        .toList();

    Navigator.of(context).pop(
      AiCartAssistantResult(
        items: items,
        strategy: _state.preferences.strategy,
        maxStores: _state.preferences.maxStores,
        minSavingToTravel: _state.preferences.minSavingToTravel,
        budgetCap: _state.preferences.budgetCap,
      ),
    );
  }

  Widget _preferenceSummary() {
    final p = _state.preferences;
    final budget = p.budgetCap == null
        ? 'nessun budget impostato'
        : 'budget obiettivo €${p.budgetCap!.toStringAsFixed(0)}';

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Text(
          'Strategia: ${p.strategy} · massimo ${p.maxStores} supermercati · '
          'soglia €${p.minSavingToTravel.toStringAsFixed(0)} · $budget',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Assistente CarrelloGiusto'),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                ..._messages.map(
                  (message) => Align(
                    alignment: message.fromUser
                        ? Alignment.centerRight
                        : Alignment.centerLeft,
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Text(message.text),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                _preferenceSummary(),
                if (_state.items.isNotEmpty) ...[
                  const Padding(
                    padding: EdgeInsets.only(top: 12, bottom: 4),
                    child: Text(
                      'Lista attuale',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  ...List.generate(
                    _state.items.length,
                    (index) {
                      final item = _state.items[index];
                      return Card(
                        child: ListTile(
                          title: Text(item.label),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('${item.quantity} ${item.unit}'),
                              if (item.matchStatus == 'learned_mapping')
                                const Text(
                                  'Riconosciuto da una scelta precedente',
                                )
                              else if (item.matchStatus == 'user_confirmed')
                                const Text('Confermato da te')
                              else if (item.matchStatus == 'auto_resolved')
                                Text(
                                  'Riconosciuto automaticamente '
                                  '(${(item.matchConfidence * 100).toStringAsFixed(0)}%)',
                                )
                              else if (item.catalogCandidates.isNotEmpty)
                                Text(
                                  'Da confermare · suggerimento: '
                                  '${item.catalogCandidates.first['label']}',
                                )
                              else if (item.productKey == null)
                                const Text(
                                  'Non riconosciuto: usa “Cerca nel catalogo”.',
                                ),
                            ],
                          ),
                          trailing: PopupMenuButton<String>(
                            onSelected: (action) {
                              if (action == 'edit') {
                                _editItem(item, index);
                              } else if (action == 'choose') {
                                _chooseCandidate(item, index);
                              } else if (action == 'catalog') {
                                _searchFullCatalog(item, index);
                              }
                            },
                            itemBuilder: (context) => [
                              const PopupMenuItem(
                                value: 'edit',
                                child: Text('Modifica dettagli'),
                              ),
                              if (item.productKey == null &&
                                  item.catalogCandidates.isNotEmpty)
                                const PopupMenuItem(
                                  value: 'choose',
                                  child: Text('Scegli suggerimento'),
                                ),
                              if (item.productKey == null)
                                PopupMenuItem(
                                  value: 'catalog',
                                  child: Text(
                                    item.catalogCandidates.isEmpty
                                        ? 'Cerca nel catalogo'
                                        : 'Vedi altri risultati',
                                  ),
                                ),
                            ],
                            icon: item.productKey != null
                                ? const Icon(Icons.check_circle_outline)
                                : const Icon(Icons.more_vert),
                          ),
                        ),
                      );
                    },
                  ),
                ],
                if (_state.notes.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  ..._state.notes.map(
                    (note) => Text(
                      note,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ],
                if (_error != null) ...[
                  const SizedBox(height: 12),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(_error!),
                    ),
                  ),
                ],
                if (_state.items.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: _loading ? null : _finish,
                    icon: const Icon(Icons.check),
                    label: const Text('Usa questa lista'),
                  ),
                ],
              ],
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      minLines: 1,
                      maxLines: 4,
                      onSubmitted: (_) => _send(),
                      decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        hintText: 'Scrivi una modifica…',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: _loading ? null : _send,
                    icon: _loading
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                            ),
                          )
                        : const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
