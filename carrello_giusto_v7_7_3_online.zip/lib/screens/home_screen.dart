import 'package:flutter/material.dart';
import '../controllers/home_controller.dart';
import '../models/shopping_item.dart';
import '../models/app_preferences.dart';
import '../widgets/shopping_item_editor.dart';
import 'results_screen.dart';
import 'catalog_search_screen.dart';
import 'ai_cart_screen.dart';
import '../models/ai_cart_assistant_result.dart';
import '../models/catalog_product.dart';
import '../services/api_error_policy_v60.dart';
import '../services/product_usage_service.dart';

class HomeScreen extends StatefulWidget {
  final String userId;
  const HomeScreen({super.key, required this.userId});
  @override State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final HomeController _controller = HomeController();
  final ProductUsageService _usage = ProductUsageService();
  final List<ShoppingItem> _items = [];
  List<CatalogProduct> _frequent = const [];
  bool _loading=false; double _radiusKm=10,_minSaving=3; int _maxStores=3;
  String _strategy='balanced',_travelProfile='car'; String? _error; double? _budgetCap;

  @override void initState(){super.initState();_load();}
  Future<void> _load() async { final p=await _controller.preferences(); final f=await _usage.frequent(); if(!mounted)return; setState((){_radiusKm=p.radiusKm;_minSaving=p.minSavingToTravel;_maxStores=p.maxStores;_travelProfile=p.travelProfile;_strategy=p.strategy;_frequent=f;}); }
  ShoppingItem _toItem(CatalogProduct p)=>ShoppingItem(productKey:p.productKey,label:p.name,quantity:p.defaultQuantity,unit:p.unit,preferredBrand:p.strictBrand?p.brand:null,allowEquivalents:!p.strictBrand);
  Future<void> _addCatalogProduct(CatalogProduct p) async { setState(()=>_items.add(_toItem(p))); await _usage.record(p); final f=await _usage.frequent(); if(mounted)setState(()=>_frequent=f); }
  Future<void> _addProduct() async { final p=await Navigator.of(context).push<CatalogProduct>(MaterialPageRoute(builder:(_)=>const CatalogSearchScreen())); if(p!=null&&mounted)await _addCatalogProduct(p); }
  Future<void> _openAiAssistant() async { final r=await Navigator.of(context).push<AiCartAssistantResult>(MaterialPageRoute(builder:(_)=>AiCartScreen(userId:widget.userId))); if(r==null||!mounted)return; setState((){_items..clear()..addAll(r.items);_strategy=r.strategy;_maxStores=r.maxStores;_minSaving=r.minSavingToTravel;_budgetCap=r.budgetCap;}); }
  Future<void> _restore() async { final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Ripristinare la lista?'),content:const Text('La lista verrà riportata allo stato iniziale vuoto.'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Annulla')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Ripristina'))]))??false; if(ok&&mounted)setState((){_items.clear();_error=null;_budgetCap=null;}); }
  Future<void> _optimize() async { if(_loading||_items.isEmpty)return;setState((){_loading=true;_error=null;});try{final r=await _controller.optimize(items:_items,userId:widget.userId,preferences:AppPreferences(strategy:_strategy,radiusKm:_radiusKm,travelProfile:_travelProfile,minSavingToTravel:_minSaving,maxStores:_maxStores),budgetCap:_budgetCap);if(!mounted)return;await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>ResultsScreen(result:r,userId:widget.userId,budgetCap:_budgetCap)));}on ApiException catch(e){if(mounted)setState(()=>_error=e.userMessage());}catch(_){if(mounted)setState(()=>_error='Non riesco a completare la ricerca. Controlla posizione e connessione e riprova.');}finally{if(mounted)setState(()=>_loading=false);}}

  @override Widget build(BuildContext context){final cs=Theme.of(context).colorScheme;return Scaffold(
    appBar:AppBar(title:Row(children:[Container(width:42,height:42,alignment:Alignment.center,decoration:BoxDecoration(borderRadius:BorderRadius.circular(14),gradient:LinearGradient(colors:[Colors.green.shade600,Colors.orange.shade500])),child:const Text('CG',style:TextStyle(color:Colors.white,fontWeight:FontWeight.w900,fontSize:18))),const SizedBox(width:10),const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('CarrelloGiusto',style:TextStyle(fontWeight:FontWeight.w800)),Text('La spesa che conviene davvero',style:TextStyle(fontSize:11,fontWeight:FontWeight.w400))])])),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(borderRadius:BorderRadius.circular(20),gradient:LinearGradient(colors:[Colors.green.shade50,Colors.lightBlue.shade50])),child:const Row(children:[Icon(Icons.eco_outlined,size:34),SizedBox(width:12),Expanded(child:Text('Spesa più intelligente.\nTempo ben speso. Più valore per te.',style:TextStyle(fontSize:17,fontWeight:FontWeight.w800)))])),
      const SizedBox(height:18),Row(children:[const Expanded(child:Text('Il tuo carrello',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold))),TextButton.icon(onPressed:_restore,icon:const Icon(Icons.restart_alt),label:const Text('Ripristina'))]),
      if(_items.isEmpty) Card(child:Padding(padding:const EdgeInsets.all(22),child:Column(children:[Icon(Icons.shopping_cart_outlined,size:48,color:cs.primary),const SizedBox(height:8),const Text('Il tuo carrello è vuoto',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:4),const Text('Aggiungi i prodotti che ti servono e trova il piano migliore.',textAlign:TextAlign.center),const SizedBox(height:14),FilledButton.icon(onPressed:_addProduct,icon:const Icon(Icons.add),label:const Text('Aggiungi il primo prodotto'))]))) else ...[
        FilledButton.icon(onPressed:_addProduct,icon:const Icon(Icons.add),label:const Text('Aggiungi prodotto')),
        const SizedBox(height:8),...List.generate(_items.length,(i)=>ShoppingItemEditor(item:_items[i],onChanged:(v)=>setState(()=>_items[i]=v),onDelete:()=>setState(()=>_items.removeAt(i))))
      ],
      const SizedBox(height:8),FilledButton.tonalIcon(onPressed:_openAiAssistant,icon:const Icon(Icons.auto_awesome),label:const Text('Assistente AI')),
      const SizedBox(height:20),Row(children:[const Icon(Icons.star,color:Colors.orange),const SizedBox(width:8),const Expanded(child:Text('Per te',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold))),TextButton(onPressed:_addProduct,child:const Text('Cerca'))]),
      if(_frequent.isEmpty) const Card(child:Padding(padding:EdgeInsets.all(14),child:Text('Qui compariranno i prodotti che aggiungi più spesso. Le offerte saranno mostrate solo quando avremo un prezzo e una fonte verificati.'))) else SizedBox(height:142,child:ListView(scrollDirection:Axis.horizontal,children:_frequent.map((p)=>Container(width:190,margin:const EdgeInsets.only(right:10),child:Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Expanded(child:Text(p.name,style:const TextStyle(fontWeight:FontWeight.bold))),const Text('Usato di frequente',style:TextStyle(fontSize:12)),const SizedBox(height:6),SizedBox(width:double.infinity,child:FilledButton.tonal(onPressed:()=>_addCatalogProduct(p),child:const Text('+ Aggiungi')))]))))).toList()),
      const SizedBox(height:18),ExpansionTile(title:const Text('Impostazioni ricerca',style:TextStyle(fontWeight:FontWeight.bold)),children:[Text('Raggio: ${_radiusKm.toStringAsFixed(0)} km'),Slider(value:_radiusKm,min:2,max:30,divisions:28,onChanged:(v)=>setState(()=>_radiusKm=v)),Text('Massimo supermercati: $_maxStores'),Slider(value:_maxStores.toDouble(),min:1,max:6,divisions:5,onChanged:(v)=>setState(()=>_maxStores=v.round())),Text('Risparmio minimo: €${_minSaving.toStringAsFixed(0)}'),Slider(value:_minSaving,min:0,max:10,divisions:10,onChanged:(v)=>setState(()=>_minSaving=v)),DropdownButtonFormField<String>(initialValue:_travelProfile,decoration:const InputDecoration(labelText:'Come ti sposti?'),items:const [DropdownMenuItem(value:'car',child:Text('Auto')),DropdownMenuItem(value:'motorbike',child:Text('Moto')),DropdownMenuItem(value:'bike',child:Text('Bici')),DropdownMenuItem(value:'walking',child:Text('A piedi'))],onChanged:(v){if(v!=null)setState(()=>_travelProfile=v);})]),
      if(_error!=null)Card(child:Padding(padding:const EdgeInsets.all(12),child:Text(_error!))),const SizedBox(height:16),FilledButton.icon(onPressed:_items.isEmpty||_loading?null:_optimize,icon:_loading?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.search),label:Text(_loading?'Sto cercando…':'Trova la spesa migliore')),const SizedBox(height:18)
    ])
  );}
}
