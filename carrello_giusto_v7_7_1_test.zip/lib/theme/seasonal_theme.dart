import 'package:flutter/material.dart';

enum AppSeason { spring, summer, autumn, winter }

class SeasonalTheme {
  static AppSeason seasonFor(DateTime date) {
    final m = date.month;
    if (m >= 3 && m <= 5) return AppSeason.spring;
    if (m >= 6 && m <= 8) return AppSeason.summer;
    if (m >= 9 && m <= 11) return AppSeason.autumn;
    return AppSeason.winter;
  }

  static ThemeData current() => forSeason(seasonFor(DateTime.now()));

  static ThemeData forSeason(AppSeason season) {
    final (seed, surface) = switch (season) {
      AppSeason.spring => (const Color(0xFF6D7F52), const Color(0xFFFFF9F4)),
      AppSeason.summer => (const Color(0xFF237A72), const Color(0xFFFFFBED)),
      AppSeason.autumn => (const Color(0xFF65733D), const Color(0xFFFFF8EE)),
      AppSeason.winter => (const Color(0xFF315B57), const Color(0xFFF4F8F7)),
    };
    final scheme = ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light).copyWith(surface: surface);
    return ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: surface,
      appBarTheme: AppBarTheme(backgroundColor: surface, surfaceTintColor: Colors.transparent),
      cardTheme: const CardThemeData(margin: EdgeInsets.symmetric(vertical: 5), elevation: 1),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: scheme.surfaceContainerLowest, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
    );
  }
}
