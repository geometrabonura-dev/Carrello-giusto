import 'package:flutter/material.dart';

import '../models/catalog_product.dart';
import '../services/catalog_service.dart';

class CatalogSearchScreen extends StatefulWidget {
  final String? initialQuery;
  const CatalogSearchScreen({super.key, this.initialQuery});
  @override
  State<CatalogSearchScreen> createState() => _CatalogSearchScreenState();
}

class _CatalogSearchScreenState extends State<CatalogSearchScreen> {
  final _controller = TextEditingController();
  final _service = CatalogService();
  bool _loading = false;
  String? _error;
  List<CatalogProduct> _results = const [];

  static const _local = <CatalogProduct>[
    CatalogProduct(productKey:'pasta1kg', name:'Pasta', unit:'kg', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:true),
    CatalogProduct(productKey:'olio_evo_1l', name:'Olio EVO', unit:'L', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:true),
    CatalogProduct(productKey:'rio_mare_tonno', name:'Tonno Rio Mare all’olio', brand:'Rio Mare', unit:'confezione', defaultQuantity:1, strictBrand:true, allowFractionalQuantity:false),
    CatalogProduct(productKey:'uva_senza_semi', name:'Uva senza semi', unit:'kg', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:true),
    CatalogProduct(productKey:'fiorentina', name:'Fiorentina', unit:'pezzo', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:false),
    CatalogProduct(productKey:'latte', name:'Latte', unit:'L', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:true),
    CatalogProduct(productKey:'pane', name:'Pane', unit:'kg', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:true),
    CatalogProduct(productKey:'uova', name:'Uova', unit:'confezione', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:false),
    CatalogProduct(productKey:'pomodori', name:'Pomodori', unit:'kg', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:true),
    CatalogProduct(productKey:'mele', name:'Mele', unit:'kg', defaultQuantity:1, strictBrand:false, allowFractionalQuantity:true),
  ];

  @override
  void initState() { super.initState(); _controller.text = widget.initialQuery?.trim() ?? ''; _suggest(_controller.text); }
  void _suggest(String q) { final t=q.trim().toLowerCase(); setState(()=>_results=t.isEmpty ? _local.take(6).toList() : _local.where((p)=>p.name.toLowerCase().contains(t) || (p.brand?.toLowerCase().contains(t)??false)).take(8).toList()); }
  CatalogProduct _typedProduct(String q) => CatalogProduct(
    productKey: 'custom_${q.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '_')}',
    name: q, unit: 'pezzo', defaultQuantity: 1, strictBrand: false, allowFractionalQuantity: false,
  );
  void _addTyped() {
    final q = _controller.text.trim();
    if (q.isNotEmpty) Navigator.of(context).pop(_typedProduct(q));
  }
  Future<void> _search() async {
    final q=_controller.text.trim(); if(q.isEmpty) return;
    _suggest(q);
    setState(() { _loading=true; _error=null; });
    try { final items=await _service.search(q); if(!mounted)return; if(items.isNotEmpty)setState(()=>_results=items); }
    catch (_) { if(!mounted)return; setState(()=>_error='Ricerca online non disponibile. Puoi comunque aggiungere “$q” al carrello.'); }
    finally { if(mounted)setState(()=>_loading=false); }
  }
  @override void dispose(){_controller.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Aggiungi prodotto')),
    body:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
      TextField(controller:_controller, autofocus:true, textInputAction:TextInputAction.search, onChanged:_suggest, onSubmitted:(_)=>_addTyped(), decoration:InputDecoration(hintText:'Cerca pasta, olio, tonno…', prefixIcon:const Icon(Icons.search), suffixIcon:IconButton(onPressed:_search,icon:const Icon(Icons.arrow_forward)))),
      const SizedBox(height:8),
      Align(alignment:Alignment.centerLeft,child:Text(_controller.text.trim().isEmpty?'Suggerimenti':'Suggerimenti per “${_controller.text.trim()}”',style:Theme.of(context).textTheme.labelLarge)),
      if(_loading) const LinearProgressIndicator(),
      if(_controller.text.trim().isNotEmpty) ListTile(leading:const Icon(Icons.add_circle),title:Text('Aggiungi “${_controller.text.trim()}”'),subtitle:const Text('Aggiungi anche senza attendere la ricerca online'),onTap:_addTyped),
      if(_error!=null) Padding(padding:const EdgeInsets.symmetric(vertical:8),child:Text(_error!)),
      Expanded(child:ListView.builder(itemCount:_results.length,itemBuilder:(context,index){final p=_results[index];return ListTile(leading:const Icon(Icons.shopping_basket_outlined),title:Text(p.name),subtitle:Text([if(p.brand!=null)p.brand!,'${p.defaultQuantity} ${p.unit}'].join(' • ').replaceAll(':g','')),trailing:const Icon(Icons.add_circle_outline),onTap:()=>Navigator.of(context).pop(p));}))
    ])),
  );
}
