
import 'package:flutter/material.dart';

import '../controllers/home_controller.dart';
import '../models/product_catalog.dart';
import '../models/shopping_item.dart';
import '../models/app_preferences.dart';
import '../widgets/shopping_item_editor.dart';
import 'results_screen.dart';
import 'catalog_search_screen.dart';
import 'ai_cart_screen.dart';
import '../models/ai_cart_assistant_result.dart';
import '../models/catalog_product.dart';
import '../services/api_error_policy_v60.dart';

class HomeScreen extends StatefulWidget {
  final String userId;

  const HomeScreen({
    super.key,
    required this.userId,
  });

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final HomeController _controller = HomeController();

  final List<ShoppingItem> _items =
      ProductCatalog.defaults.map((e) => e.copyWith()).toList();

  bool _loading = false;
  double _radiusKm = 10;
  double _minSaving = 3;
  int _maxStores = 3;
  String _strategy = 'balanced';
  String _travelProfile = 'car';
  String? _error;
  double? _budgetCap;



  @override
  void initState() {
    super.initState();
    _loadPreferences();
  }

  Future<void> _loadPreferences() async {
    final p = await _controller.preferences();
    if (!mounted) return;
    setState(() {
      _radiusKm = p.radiusKm;
      _minSaving = p.minSavingToTravel;
      _maxStores = p.maxStores;
      _travelProfile = p.travelProfile;
      _strategy = p.strategy;
    });
  }


Future<void> _openAiAssistant() async {
  final result = await Navigator.of(context).push<AiCartAssistantResult>(
    MaterialPageRoute(
      builder: (_) => AiCartScreen(userId: widget.userId),
    ),
  );
  if (result == null || !mounted) return;

  setState(() {
    _items
      ..clear()
      ..addAll(result.items);
    _strategy = result.strategy;
    _maxStores = result.maxStores;
    _minSaving = result.minSavingToTravel;

    _budgetCap = result.budgetCap;
    if (result.budgetCap != null) {
      _error =
          'Budget obiettivo: €${result.budgetCap!.toStringAsFixed(0)}. '
          'Lo confronterò con il risultato reale.';
    }
  });
}

  Future<void> _addProduct() async {
    final product = await Navigator.of(context).push<CatalogProduct>(
      MaterialPageRoute(builder: (_) => const CatalogSearchScreen()),
    );
    if (product == null || !mounted) return;

    setState(() {
      _items.add(
        ShoppingItem(
          productKey: product.productKey,
          label: product.name,
          quantity: product.defaultQuantity,
          unit: product.unit,
          preferredBrand: product.strictBrand ? product.brand : null,
          allowEquivalents: !product.strictBrand,
        ),
      );
    });
  }

  Future<void> _optimize() async {
    if (_loading || _items.isEmpty) return;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final result = await _controller.optimize(
        items: _items,
        userId: widget.userId,
        preferences: AppPreferences(
          strategy: _strategy,
          radiusKm: _radiusKm,
          travelProfile: _travelProfile,
          minSavingToTravel: _minSaving,
          maxStores: _maxStores,
        ),
        budgetCap: _budgetCap,
      );

      if (!mounted) return;

      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ResultsScreen(
            result: result,
            userId: widget.userId,
            budgetCap: _budgetCap,
          ),
        ),
      );
    } on ApiException catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error.userMessage();
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        final text = error.toString();
        _error = text.contains('posizione') || text.contains('Permesso')
            ? 'Non riesco a usare la posizione. Controlla i permessi e riprova.'
            : 'Si è verificato un errore imprevisto durante la ricerca.';
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _updateItem(int index, ShoppingItem item) {
    setState(() => _items[index] = item);
  }

  void _removeItem(int index) {
    setState(() => _items.removeAt(index));
  }

  void _restoreDefaults() {
    setState(() {
      _items
        ..clear()
        ..addAll(ProductCatalog.defaults.map((e) => e.copyWith()));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CarrelloGiusto')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'La tua lista',
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
              TextButton(
                onPressed: _restoreDefaults,
                child: const Text('Ripristina'),
              ),
            ],
          ),
          OutlinedButton.icon(
            onPressed: _addProduct,
            icon: const Icon(Icons.add),
            label: const Text('Aggiungi prodotto'),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: _openAiAssistant,
            icon: const Icon(Icons.auto_awesome),
            label: const Text('Assistente AI'),
          ),
          const SizedBox(height: 8),
          if (_items.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Text('La lista è vuota. Ripristina i prodotti di prova.'),
              ),
            )
          else
            ...List.generate(
              _items.length,
              (index) => ShoppingItemEditor(
                item: _items[index],
                onChanged: (value) => _updateItem(index, value),
                onDelete: () => _removeItem(index),
              ),
            ),
          const SizedBox(height: 20),
          Text(
            'Raggio: ${_radiusKm.toStringAsFixed(0)} km',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          Slider(
            value: _radiusKm,
            min: 2,
            max: 30,
            divisions: 28,
            label: '${_radiusKm.toStringAsFixed(0)} km',
            onChanged: (v) => setState(() => _radiusKm = v),
          ),
          Text(
            'Numero massimo di supermercati: $_maxStores',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          Slider(
            value: _maxStores.toDouble(),
            min: 1,
            max: 6,
            divisions: 5,
            label: '$_maxStores',
            onChanged: (v) => setState(() => _maxStores = v.round()),
          ),
          const Text(
            'Più supermercati possono ridurre il prezzo dei prodotti, '
            'ma aumentano tempo e spostamenti.',
          ),
          const SizedBox(height: 16),
          Text(
            'Risparmio minimo per spostarmi: €${_minSaving.toStringAsFixed(0)}',
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          Slider(
            value: _minSaving,
            min: 0,
            max: 10,
            divisions: 10,
            label: '€${_minSaving.toStringAsFixed(0)}',
            onChanged: (v) => setState(() => _minSaving = v),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: _travelProfile,
            decoration: const InputDecoration(
              labelText: 'Come ti sposti?',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'car', child: Text('Auto')),
              DropdownMenuItem(value: 'motorbike', child: Text('Moto')),
              DropdownMenuItem(value: 'bike', child: Text('Bici')),
              DropdownMenuItem(value: 'walking', child: Text('A piedi')),
            ],
            onChanged: (v) {
              if (v != null) setState(() => _travelProfile = v);
            },
          ),
          if (_error != null) ...[
            const SizedBox(height: 12),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(_error!),
              ),
            ),
          ],
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: _items.isEmpty || _loading ? null : _optimize,
            icon: _loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.search),
            label: Text(
              _loading ? 'Sto cercando…' : 'Trova la spesa migliore',
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'La posizione viene usata solo per trovare i supermercati e calcolare i tragitti. '
            'Non viene salvata nello storico.',
          ),
        ],
      ),
    );
  }
}
