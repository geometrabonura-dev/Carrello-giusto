
import 'package:flutter/material.dart';
import '../models/app_preferences.dart';
import '../services/app_preferences_service.dart';

class SettingsScreen extends StatefulWidget {
  final String userId;
  const SettingsScreen({super.key, required this.userId});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _service = AppPreferencesService();
  AppPreferences? _prefs;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final value = await _service.loadLocal();
    if (mounted) setState(() => _prefs = value);
  }

  Future<void> _save() async {
    final value = _prefs;
    if (value == null || _saving) return;
    setState(() => _saving = true);
    await _service.save(widget.userId, value);
    if (!mounted) return;
    setState(() => _saving = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Preferenze salvate')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = _prefs;
    if (p == null) return const Center(child: CircularProgressIndicator());

    return Scaffold(
      appBar: AppBar(title: const Text('Preferenze')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<String>(
            value: p.strategy,
            decoration: const InputDecoration(
              labelText: 'Strategia',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'max_saving', child: Text('Massimo risparmio')),
              DropdownMenuItem(value: 'balanced', child: Text('Bilanciato')),
              DropdownMenuItem(value: 'max_comfort', child: Text('Massima comodità')),
            ],
            onChanged: (v) => v == null
                ? null
                : setState(() => _prefs = p.copyWith(strategy: v)),
          ),
          const SizedBox(height: 24),
          Text('Raggio massimo: ${p.radiusKm.toStringAsFixed(0)} km'),
          Slider(
            value: p.radiusKm,
            min: 2,
            max: 30,
            divisions: 28,
            label: '${p.radiusKm.toStringAsFixed(0)} km',
            onChanged: (v) => setState(() => _prefs = p.copyWith(radiusKm: v)),
          ),
          Text('Massimo supermercati: ${p.maxStores}'),
          Slider(
            value: p.maxStores.toDouble(),
            min: 1,
            max: 6,
            divisions: 5,
            label: '${p.maxStores}',
            onChanged: (v) =>
                setState(() => _prefs = p.copyWith(maxStores: v.round())),
          ),
          Text(
            'Risparmio minimo per spostarti: '
            '€${p.minSavingToTravel.toStringAsFixed(0)}',
          ),
          Slider(
            value: p.minSavingToTravel,
            min: 0,
            max: 10,
            divisions: 10,
            label: '€${p.minSavingToTravel.toStringAsFixed(0)}',
            onChanged: (v) =>
                setState(() => _prefs = p.copyWith(minSavingToTravel: v)),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: p.travelProfile,
            decoration: const InputDecoration(
              labelText: 'Come ti sposti?',
              border: OutlineInputBorder(),
            ),
            items: const [
              DropdownMenuItem(value: 'car', child: Text('Auto')),
              DropdownMenuItem(value: 'motorbike', child: Text('Moto')),
              DropdownMenuItem(value: 'bike', child: Text('Bici')),
              DropdownMenuItem(value: 'walking', child: Text('A piedi')),
            ],
            onChanged: (v) => v == null
                ? null
                : setState(() => _prefs = p.copyWith(travelProfile: v)),
          ),
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
            label: Text(_saving ? 'Salvataggio…' : 'Salva preferenze'),
          ),
        ],
      ),
    );
  }
}
