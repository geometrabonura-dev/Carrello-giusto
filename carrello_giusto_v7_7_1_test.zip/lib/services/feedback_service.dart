
import 'dart:convert';
import 'package:http/http.dart' as http;

class FeedbackService {
  final String baseUrl;
  FeedbackService({this.baseUrl = 'http://10.0.2.2:8000'});

  Future<void> sendFeedback({
    required String userId,
    required String feedbackType,
    String? choiceId,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/v3/history/feedback'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'user_id': userId,
        'choice_id': choiceId,
        'feedback_type': feedbackType,
        'apply_learning': true,
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Impossibile salvare il feedback');
    }
  }
}
