
import 'dart:convert';
import 'package:http/http.dart' as http;

class PreferencesSyncService {
  final String baseUrl;
  PreferencesSyncService({this.baseUrl = 'http://10.0.2.2:8000'});

  Future<void> syncInitialStrategy({
    required String userId,
    required String strategy,
  }) async {
    final presets = {
      'max_saving': {
        'weight_saving': 0.75,
        'weight_time': 0.15,
        'weight_simplicity': 0.10,
        'store_penalty_eur': 0.25,
      },
      'balanced': {
        'weight_saving': 0.50,
        'weight_time': 0.25,
        'weight_simplicity': 0.25,
        'store_penalty_eur': 0.75,
      },
      'max_comfort': {
        'weight_saving': 0.25,
        'weight_time': 0.35,
        'weight_simplicity': 0.40,
        'store_penalty_eur': 1.50,
      },
    };

    final selected = presets[strategy] ?? presets['balanced']!;

    final response = await http.put(
      Uri.parse('$baseUrl/v3/preferences/$userId'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'radius_km': 10.0,
        'travel_profile': 'car',
        'min_saving_to_travel': 3.0,
        'max_travel_minutes': null,
        'max_stores': 3,
        'vehicle_cost_per_km': null,
        'time_value_per_hour': null,
        ...selected,
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Impossibile sincronizzare le preferenze iniziali');
    }
  }
}
