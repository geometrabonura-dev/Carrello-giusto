import 'location_service.dart';

import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/plan.dart';

class ApiResult {
  final List<Plan> plans;
  final String dataStatus;
  final bool fromFallback;
  final String? message;

  ApiResult({
    required this.plans,
    required this.dataStatus,
    required this.fromFallback,
    this.message,
  });
}

class ApiService {
  final String baseUrl;

  ApiService({this.baseUrl = 'http://10.0.2.2:8000'});

  Future<ApiResult> optimizeCart({
    required List<String> items,
    required double minSaving,
    required double vehicleCostPerKm,
    required double radiusKm,
    required String travelProfile,
  }) async {
    final uri = Uri.parse('$baseUrl/v3/cart/optimize');

    final position = await LocationService().currentPosition();
    final payload = {
      'items': items,
      'vehicle_cost_per_km': vehicleCostPerKm,
      'min_saving_to_travel': minSaving,
      'radius_km': radiusKm,
      'travel_profile': travelProfile,
        'strategy': 'balanced',
      // Precise location will be added when user enables/provides it.
      'origin': {
          'latitude': position.latitude,
          'longitude': position.longitude,
        },
    };

    final response = await http
        .post(
          uri,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode(payload),
        )
        .timeout(const Duration(seconds: 8));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Backend HTTP ${response.statusCode}');
    }

    final json = jsonDecode(response.body) as Map<String, dynamic>;
    final List<Plan> plans = [];

    void addPlan(String label, dynamic value) {
      if (value is Map<String, dynamic>) {
        plans.add(Plan.fromJson(label, value));
      }
    }

    addPlan('Miglior compromesso', json['recommendation']);
    addPlan('Più vicino', json['closest_plan']);
    addPlan('Massimo risparmio', json['max_saving_plan']);
    addPlan('Un solo supermercato', json['best_single_store']);

    return ApiResult(
      plans: plans,
      dataStatus: (json['data_status'] ?? 'unknown').toString(),
      fromFallback: false,
      message: json['message']?.toString(),
    );
  }
}
