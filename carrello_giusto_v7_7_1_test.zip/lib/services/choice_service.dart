
import 'dart:convert';
import 'package:http/http.dart' as http;

class ChoiceService {
  final String baseUrl;
  ChoiceService({this.baseUrl = 'http://10.0.2.2:8000'});

  Future<String?> recordChoice({
    required String userId,
    required String strategy,
    required String chosenPlanKey,
    String? recommendedPlanKey,
    required bool acceptedRecommendation,
    required int storesCount,
    required double productTotal,
    required double travelCost,
    required double timeCost,
    required double effectiveTotal,
    double? durationMinutes,
    double? distanceKm,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/v3/history/choices'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'user_id': userId,
        'strategy': strategy,
        'chosen_plan_key': chosenPlanKey,
        'recommended_plan_key': recommendedPlanKey,
        'accepted_recommendation': acceptedRecommendation,
        'stores_count': storesCount,
        'product_total': productTotal,
        'travel_cost': travelCost,
        'time_cost': timeCost,
        'effective_total': effectiveTotal,
        'duration_minutes': durationMinutes,
        'distance_km': distanceKm,
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Impossibile registrare la scelta');
    }

    final body = jsonDecode(response.body);
    return body['id'] as String?;
  }
}
