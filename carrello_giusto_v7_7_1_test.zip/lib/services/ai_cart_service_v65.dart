import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/ai_cart_draft.dart';

class AiCartServiceV65 {
  final String baseUrl;
  final http.Client client;

  AiCartServiceV65({
    this.baseUrl = 'http://10.0.2.2:8000',
    http.Client? client,
  }) : client = client ?? http.Client();

  Future<AiCartDraft> parse(String text, {String? userId}) async {
    final response = await client
        .post(
          Uri.parse('$baseUrl/v6/ai-cart/parse'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'text': text,
            'user_id': userId,
          }),
        )
        .timeout(const Duration(seconds: 15));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Interpretazione AI fallita (${response.statusCode})');
    }

    return AiCartDraft.fromJson(
      Map<String, dynamic>.from(jsonDecode(response.body)),
    );
  }

  Future<void> confirmMapping({
    required String userId,
    required String label,
    required String productKey,
    String? preferredBrand,
  }) async {
    final response = await client
        .post(
          Uri.parse('$baseUrl/v6/ai-cart/confirm-mapping'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'user_id': userId,
            'label': label,
            'preferred_brand': preferredBrand,
            'product_key': productKey,
          }),
        )
        .timeout(const Duration(seconds: 12));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(
        'Salvataggio correzione fallito (${response.statusCode})',
      );
    }
  }
}
