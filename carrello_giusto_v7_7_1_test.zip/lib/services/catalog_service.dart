
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/catalog_product.dart';

class CatalogService {
  final String baseUrl;
  final http.Client client;

  CatalogService({
    this.baseUrl = 'http://10.0.2.2:8000',
    http.Client? client,
  }) : client = client ?? http.Client();

  Future<List<CatalogProduct>> search(String query) async {
    final uri = Uri.parse('$baseUrl/v4/catalog/search').replace(
      queryParameters: {'q': query},
    );

    final response = await client.get(uri).timeout(
          const Duration(seconds: 8),
        );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Ricerca catalogo fallita');
    }

    final body = jsonDecode(response.body);
    final rows = (body['items'] as List?) ?? const [];

    return rows
        .map((e) => CatalogProduct.fromJson(e as Map<String, dynamic>))
        .toList();
  }
}
