
import 'dart:convert';
import 'package:http/http.dart' as http;

class HistoryService {
  final String baseUrl;
  HistoryService({this.baseUrl = 'http://10.0.2.2:8000'});

  Future<List<dynamic>> getChoices(String userId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/v3/history/choices/$userId'),
    );
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Impossibile caricare lo storico');
    }
    return jsonDecode(response.body)['choices'] ?? [];
  }

  Future<Map<String, dynamic>> getLearning(String userId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/v3/history/learning/$userId'),
    );
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Impossibile caricare le preferenze apprese');
    }
    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> resetLearning(String userId) async {
    final response = await http.post(
      Uri.parse('$baseUrl/v3/history/reset/$userId'),
    );
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Impossibile resettare le preferenze');
    }
    return jsonDecode(response.body);
  }
}
