import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/ai_cart_conversation.dart';

class AiCartChatServiceV68 {
  final String baseUrl;
  final http.Client client;

  AiCartChatServiceV68({
    this.baseUrl = 'http://10.0.2.2:8000',
    http.Client? client,
  }) : client = client ?? http.Client();

  Future<AiCartChatResult> send({
    required String userId,
    required String message,
    required AiCartConversationState state,
  }) async {
    final response = await client
        .post(
          Uri.parse('$baseUrl/v6/ai-cart/chat'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'user_id': userId,
            'message': message,
            'state': state.toJson(),
          }),
        )
        .timeout(const Duration(seconds: 20));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(
        'Conversazione AI fallita (${response.statusCode})',
      );
    }

    return AiCartChatResult.fromJson(
      Map<String, dynamic>.from(jsonDecode(response.body)),
    );
  }
}
