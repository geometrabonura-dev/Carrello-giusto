#!/usr/bin/env bash
set -euo pipefail

if [ -f android/app/src/main/AndroidManifest.xml ]; then
python - <<'PY'
from pathlib import Path
p = Path("android/app/src/main/AndroidManifest.xml")
s = p.read_text()
if "android.permission.ACCESS_FINE_LOCATION" not in s:
    end = s.find(">", s.find("<manifest"))
    permissions = (
        '\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />'
        '\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />'
    )
    s = s[:end+1] + permissions + s[end+1:]
s = s.replace('android:label="spesa_smart"', 'android:label="CarrelloGiusto"')
p.write_text(s)
PY
fi

if [ -f ios/Runner/Info.plist ]; then
python - <<'PY'
from pathlib import Path
p = Path("ios/Runner/Info.plist")
s = p.read_text()
if "NSLocationWhenInUseUsageDescription" not in s:
    insert = (
        "<key>NSLocationWhenInUseUsageDescription</key>\\n"
        "<string>CarrelloGiusto usa la posizione per trovare i supermercati vicini e calcolare i tragitti.</string>\\n"
    )
    s = s.replace("</dict>", insert + "</dict>", 1)
s = s.replace("<string>spesa_smart</string>", "<string>CarrelloGiusto</string>")
p.write_text(s)
PY
fi

echo "Configurazione nativa CarrelloGiusto applicata."
