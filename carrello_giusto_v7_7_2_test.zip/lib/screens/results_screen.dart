
import 'package:flutter/material.dart';

import '../models/optimization_result.dart';
import '../services/plan_selection_service.dart';
import '../widgets/result_plan_card.dart';
import '../widgets/plan_tradeoff_card.dart';
import '../services/budget_evaluator_v69.dart';
import 'selected_plan_screen.dart';

class ResultsScreen extends StatefulWidget {
  final OptimizationResult result;
  final String userId;
  final double? budgetCap;

  const ResultsScreen({
    super.key,
    required this.result,
    required this.userId,
    this.budgetCap,
  });

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  final _selection = PlanSelectionService();
  final _budgetEvaluator = const BudgetEvaluatorV69();
  String? _selectedKey;

  Future<void> _select(OptimizationPlan plan) async {
    // La scelta deve funzionare anche offline: salviamo subito lo stato UI.
    if (!mounted) return;
    setState(() => _selectedKey = plan.key);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => SelectedPlanScreen(
          title: plan.recommended ? 'Piano consigliato' : 'Piano scelto',
          plan: plan,
        ),
      ),
    );
    try {
      await _selection.selectPlan(
        userId: widget.userId,
        planKey: plan.key,
        recommendedPlanKey: widget.result.recommendation.key,
        storesCount: plan.storesCount,
        productTotal: plan.productTotal,
        travelCost: plan.travelCost,
        timeCost: plan.timeCost,
        effectiveTotal: plan.effectiveTotal,
        durationMinutes: plan.durationMinutes,
        distanceKm: plan.distanceKm,
      ).timeout(const Duration(seconds: 3));
    } catch (_) {
      // La telemetria remota non deve impedire all'utente di scegliere il piano.
    }
  }

  List<MapEntry<String, OptimizationPlan?>> get _cards => [
        MapEntry('Piano consigliato', widget.result.recommendation),
        MapEntry('Più vicino', widget.result.closestPlan),
        MapEntry('Massimo risparmio', widget.result.maxSavingPlan),
        MapEntry('Un solo supermercato', widget.result.bestSingleStore),
      ];

  @override
  Widget build(BuildContext context) {
    final r = widget.result;

    return Scaffold(
      appBar: AppBar(title: const Text('Risultati')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            r.strategyLabel,
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 6),
          Text(
            'Fino a ${r.maxStores} supermercati • soglia minima €${r.minSavingToTravel.toStringAsFixed(0)}',
          ),
          if (widget.budgetCap != null) ...[
            const SizedBox(height: 12),
            Builder(
              builder: (context) {
                final budget = _budgetEvaluator.evaluate(
                  result: r,
                  budgetCap: widget.budgetCap!,
                );
                final recommended = r.recommendation;

                if (budget.recommendationWithinBudget) {
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Text(
                        'Budget €${budget.budgetCap.toStringAsFixed(2)}: '
                        'il piano consigliato costa '
                        '€${recommended.effectiveTotal.toStringAsFixed(2)}, '
                        'quindi restano '
                        '€${budget.difference.toStringAsFixed(2)}.',
                      ),
                    ),
                  );
                }

                final alternative = budget.bestPlanWithinBudget;
                final cheapest = budget.cheapestEligiblePlan;

                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Budget €${budget.budgetCap.toStringAsFixed(2)}: '
                          'il piano consigliato supera il limite di '
                          '€${budget.difference.toStringAsFixed(2)}.',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        if (alternative != null)
                          Text(
                            'Esiste però un piano ammesso che rientra nel budget: '
                            '€${alternative.effectiveTotal.toStringAsFixed(2)} '
                            'con ${alternative.storesCount} supermercato/i.',
                          )
                        else if (cheapest != null)
                          Text(
                            'Nessun piano ammesso rientra nel budget. '
                            'Il più economico costa '
                            '€${cheapest.effectiveTotal.toStringAsFixed(2)}, '
                            'cioè €${(cheapest.effectiveTotal - budget.budgetCap).toStringAsFixed(2)} '
                            'oltre il limite.',
                          )
                        else
                          const Text(
                            'Non risultano piani ammessi da confrontare con il budget.',
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],

if (r.budgetAnalysis != null &&
    !r.budgetAnalysis!.withinBudget) ...[
  const SizedBox(height: 12),
  Card(
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Come provare a rientrare nel budget',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          if (r.budgetAnalysis!.substitutions.isEmpty)
            const Text(
              'Non ci sono sostituzioni approvate e prezzate '
              'che possa suggerire senza inventare alternative.',
            )
          else ...[
            ...r.budgetAnalysis!.substitutions.map(
              (suggestion) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Text(
                  '• ${suggestion.sourceLabel} → '
                  '${suggestion.alternativeLabel}'
                  '${suggestion.alternativeBrand == null ? '' : ' (${suggestion.alternativeBrand})'}: '
                  'risparmio €${suggestion.saving.toStringAsFixed(2)} '
                  'da ${suggestion.storeName}'
                  '${suggestion.loyaltyRequired ? ' · carta fedeltà richiesta' : ''}'
                  '${suggestion.alternativeVerified ? ' · prezzo verificato' : ' · prezzo non verificato'}',
                ),
              ),
            ),
            Text(
              r.budgetAnalysis!.canCloseGap
                  ? 'Queste sostituzioni possono coprire lo sforamento '
                    'stimato di €${r.budgetAnalysis!.difference.toStringAsFixed(2)} '
                    'senza cambiare i supermercati del piano.'
                  : 'Risparmio disponibile: '
                    '€${r.budgetAnalysis!.suggestedSaving.toStringAsFixed(2)}. '
                    'Non basta ancora a coprire tutto lo sforamento.',
            ),
          ],
        ],
      ),
    ),
  ),
],
          if (r.explanationHeadline != null) ...[
            const SizedBox(height: 12),
            Text(
              r.explanationHeadline!,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
          ],
          if (r.explanationReasons.isNotEmpty) ...[
            const SizedBox(height: 8),
            ...r.explanationReasons.map(
              (reason) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text('• $reason'),
              ),
            ),
          ],
          const SizedBox(height: 16),
          PlanTradeoffCard(
            plan: r.recommendation,
            maxSavingPlan: r.maxSavingPlan,
            closestPlan: r.closestPlan,
          ),
          const SizedBox(height: 12),
          ..._cards.where((e) => e.value != null).map((entry) {
            final plan = entry.value!;
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ResultPlanCard(
                title: entry.key,
                reason: plan.eligibleByThreshold
                    ? 'Piano ammesso dalla soglia di risparmio.'
                    : 'Piano scartato dalla soglia di risparmio.',
                productTotal: plan.productTotal,
                travelCost: plan.travelCost,
                timeCost: plan.timeCost,
                effectiveTotal: plan.effectiveTotal,
                distanceKm: plan.distanceKm,
                durationMinutes: plan.durationMinutes,
                storesCount: plan.storesCount,
                isRecommended: plan.recommended,
                isSelected: _selectedKey == plan.key,
                onSelect: () => _select(plan),
              ),
            );
          }),
          const SizedBox(height: 8),
          Text(
            r.dataStatus == 'verified'
                ? 'Prezzi del piano consigliato verificati.'
                : 'Alcuni prezzi non sono ancora verificati.',
          ),
        ],
      ),
    );
  }
}
