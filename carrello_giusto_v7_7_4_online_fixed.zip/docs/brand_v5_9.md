# CarrelloGiusto — Brand v5.9

## Nome
**CarrelloGiusto**

## Payoff
**La spesa che conviene davvero.**

## Idea del marchio
Il simbolo combina:
- un carrello della spesa;
- una spunta;
- l'idea di scelta corretta e conveniente.

## Uso
Il marchio va mostrato con il nome **CarrelloGiusto** tutto attaccato.

## Nota
L'asset SVG incluso è una base tecnica interna per prototipi e build di sviluppo.
Prima della pubblicazione sugli store è consigliata una rifinitura grafica professionale
e una verifica finale del marchio.
