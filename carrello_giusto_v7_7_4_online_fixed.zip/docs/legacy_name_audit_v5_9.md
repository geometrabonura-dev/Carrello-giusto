# Audit riferimenti legacy v5.9

Riferimenti residui trovati:
- `pubspec.yaml` → `spesa_smart`
- `docs/v5.8.md` → `Spesa Smart`
- `tests/test_metrics.py` → `spesa_smart`
- `backend/docker-compose.yml` → `spesa_smart`
- `test/product_catalog_test.dart` → `spesa_smart`
- `test/app_preferences_test.dart` → `spesa_smart`
- `test/catalog_product_test.dart` → `spesa_smart`
- `test/shopping_item_test.dart` → `spesa_smart`
- `test/optimization_result_v49_test.dart` → `spesa_smart`
- `test/demo_result_service_test.dart` → `spesa_smart`
- `test/optimization_result_test.dart` → `spesa_smart`
- `test/home_controller_contract_test.dart` → `spesa_smart`
- `backend/app/db.py` → `spesa_smart`
- `backend/app/metrics.py` → `spesa_smart`
