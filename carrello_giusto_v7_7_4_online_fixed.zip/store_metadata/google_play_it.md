# Google Play — bozza metadata IT

## Nome app
CarrelloGiusto

## Breve descrizione
Confronta la spesa considerando prezzi, distanza, tempo e costo del viaggio.

## Descrizione estesa
CarrelloGiusto ti aiuta a capire dove conviene davvero fare la spesa.

Non confronta soltanto il prezzo dei singoli prodotti: considera il costo totale
del carrello, la distanza dai supermercati, il costo del viaggio, il tempo necessario
e il numero di negozi da visitare.

Puoi scegliere tra strategie diverse:
- Massimo risparmio
- Bilanciato
- Massima comodità

Puoi inoltre impostare il raggio massimo di ricerca, il numero massimo di supermercati
e la soglia minima di risparmio necessaria per giustificare uno spostamento più lungo.

CarrelloGiusto punta a rispondere a una domanda semplice:
“Mi conviene davvero andare più lontano per risparmiare?”

## Categoria suggerita
Shopping / Lifestyle

## Parole chiave concettuali
spesa, supermercati, offerte, risparmio, confronto prezzi, carrello, promozioni
