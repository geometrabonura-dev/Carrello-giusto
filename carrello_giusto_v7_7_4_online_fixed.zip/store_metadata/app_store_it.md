# App Store — bozza metadata IT

## Nome
CarrelloGiusto

## Sottotitolo
La spesa che conviene davvero

## Testo promozionale
Confronta il costo reale della spesa tra più supermercati considerando anche distanza,
tempo e costo del viaggio.

## Descrizione
CarrelloGiusto confronta il costo complessivo della tua spesa e ti aiuta a scegliere
l'opzione più conveniente.

Oltre ai prezzi dei prodotti, considera:
- distanza;
- costo del viaggio;
- tempo;
- numero di supermercati;
- soglia minima di risparmio.

Scegli la strategia più adatta:
Massimo risparmio, Bilanciato o Massima comodità.

L'obiettivo è evitare falsi risparmi: spendere qualche euro in meno non conviene
se per ottenerlo devi percorrere molti chilometri o perdere troppo tempo.

## Keyword draft
spesa, supermercati, offerte, risparmio, prezzi, carrello, promozioni
