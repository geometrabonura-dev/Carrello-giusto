# Checklist privacy / store

Prima della pubblicazione:
- dichiarare l'uso della posizione;
- descrivere se e come viene salvato l'ID anonimo;
- indicare eventuali dati di preferenza salvati;
- documentare eventuali analytics/telemetria;
- preparare privacy policy pubblica;
- compilare Data Safety (Google Play);
- compilare App Privacy (App Store);
- verificare permessi Android/iOS effettivamente richiesti;
- evitare dichiarazioni di “prezzo verificato” se la fonte non è autorizzata.
