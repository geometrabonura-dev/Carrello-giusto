#!/usr/bin/env bash
set -euo pipefail

echo "== Flutter bootstrap =="
./tool/bootstrap_flutter.sh

echo
echo "== Flutter validation =="
flutter --version
flutter analyze
flutter test
flutter build apk --debug

echo
echo "== Backend =="
python -m compileall -q backend/app
python -m pytest -q

echo
echo "Validation completed."
