#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter non trovato nel PATH." >&2
  exit 1
fi

if [ ! -d android ] || [ ! -d ios ]; then
  flutter create \
    --platforms=android,ios \
    --project-name spesa_smart \
    --org it.carrellogiusto \
    .
fi

./tool/configure_native.sh
flutter pub get

echo "Scaffold Flutter pronto."
