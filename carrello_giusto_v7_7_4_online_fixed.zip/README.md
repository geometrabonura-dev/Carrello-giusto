# CarrelloGiusto v2.0

Prima UI Flutter completa collegata al modello di ranking di CarrelloGiusto.

## Novità
- Home con lista della spesa
- Raggio di ricerca 2–30 km
- Soglia minima di risparmio
- Profilo di viaggio
- Risultati a schede:
  - Miglior compromesso
  - Più vicino
  - Massimo risparmio
  - Un solo supermercato
- Dettaglio articoli assegnati a ciascun supermercato
- Spiegazione testuale del perché della raccomandazione

I dati inclusi sono DEMO. Nessun prezzo demo deve essere mostrato come reale o verificato.


## v2.1
UI Flutter collegata al backend tramite HTTP, con fallback demo esplicito e stato della sorgente dati.


## v2.2
Il client invia solo lista e preferenze; supermercati e offerte vengono risolti dal backend tramite repository.


## v2.3
Backend PostgreSQL reale con repository selezionabile, schema dati, fonti, offerte verificate e audit delle importazioni.


## v2.4
Pipeline di import con staging raw, matching EAN/alias, deduplicazione, upsert e manutenzione offerte scadute/stale.


## v2.5
Matching EAN/alias/fuzzy, coda di revisione unmatched e punteggi di confidenza/qualità.


## v2.6
Quality policy automatica, source quality durante import e dashboard qualità dati.


## v2.7
Test PostgreSQL end-to-end, scheduler manutenzione, health check avanzato e dashboard admin HTML.


## v2.8
Autenticazione admin, logging JSON, metriche Prometheus e deployment Docker completo.


## v2.9
Coda job PostgreSQL, retry/backoff, audit log, rate limiting e health probes live/ready.


## v3.0
Geolocalizzazione client, ricerca store per coordinate e raggio Haversine, senza persistenza della posizione utente.


## v3.1
Routing stradale provider-configurabile, matrice origin→store, giro multi-store e costo viaggio su km effettivi; fallback Haversine esplicito.


## v3.2
Ordine tappe ottimizzato, matrice pairwise, limite tempo viaggio e preferenze percorso predisposte.


## v3.3
Profili auto/moto/bici/piedi, cache routing e costo del tempo incluso nel totale effettivo.


## v3.4
Preferenze persistenti, penalità multi-store e scoring personalizzato risparmio/tempo/semplicità.


## v3.5
Tre strategie semplici (Massimo risparmio, Bilanciato, Massima comodità) e spiegazione leggibile della raccomandazione.


## v3.6
Storico delle scelte, feedback esplicito e apprendimento leggero delle preferenze. Nessun apprendimento nascosto e nessuna persistenza della posizione.


## v3.7
UI Flutter per storico/feedback, strategia suggerita automaticamente e reset delle preferenze apprese.


## v3.8
Navigazione principale Flutter, onboarding iniziale delle priorità e servizio client per registrare le scelte dei piani.


## v3.9
ID anonimo persistente, sincronizzazione onboarding e flusso client 'Scegli questo piano' con registrazione automatica della scelta.


## v4.0
Consolidamento MVP: risultati selezionabili, registrazione scelta, retry/offline espliciti e runner migrazioni backend.


## v4.1
Modello risultati unificato, retry reale sulla chiamata API, fallback demo esplicito, schermata risultati selezionabile e test Flutter di parsing/fallback.


## v4.2
Home collegata al nuovo OptimizationController, geolocalizzazione reale come origine, strategia onboarding applicata e flusso Home -> Results unificato.


## v4.3
Lista strutturata con quantità, marca preferita, equivalenti e chiavi prodotto canoniche inviate al backend.


## v4.4
Catalogo prodotti ricercabile, aggiunta prodotto dalla Home, quantità frazionarie e product_key persistenti nel catalogo PostgreSQL.


## v4.5
Risoluzione reale delle product_key dal catalogo DB, validazione quantità/unità/marca ed adapter canonico prima dell'optimizer.


## v4.6
Offerte PostgreSQL reali collegate al carrello canonico, controllo copertura completa e primo optimizer DB con stato verified/unverified.


## v4.7
Optimizer completo su offerte PostgreSQL con routing, costo viaggio, costo tempo, soglia minima €3 e plan_key stabile.


## v4.8
Supporto fino a 6 supermercati, pre-filtro candidati e strategie applicate solo dopo la soglia minima di risparmio.


## v4.9
Selettore Flutter 1–6 supermercati, nuovo client v4.9 e spiegazione visuale del compromesso fra prezzo, distanza, tempo e numero di tappe.


## v5.0
MVP consolidato: preferenze persistenti, raggio 2–30 km applicato realmente al pricebook DB e navigazione Spesa/Preferenze/Storico.


## v5.1
Fondazione dati reali con registro fonti ufficiali, policy di verifica rigorosa e provenance per ogni offerta importata.


## v5.2
Import JSON/CSV autorizzati, mapping store esterni, product matching, persistenza raw/offers e dashboard import runs.


## v5.3
Review queue per store/prodotti non riconosciuti, risoluzione manuale e riuso automatico dei mapping negli import successivi.


## v5.4
Freshness/scadenze, dashboard review HTML e reprocessing delle righe raw dopo la risoluzione dei mapping.


## v5.5
Admin dashboard protette, auto-reprocess dopo risoluzione review e audit trail delle operazioni manuali.


## v5.6
Console admin browser per ricerca target, risoluzione, reject e retry selettivo delle review.


## v5.7
Console review avanzata con paginazione, filtri, payload raw, reopen e metriche sui tempi di risoluzione.


## v5.8
Rebranding del progetto in **CarrelloGiusto** — *La spesa che conviene davvero.*


## v5.9
Brand base, schermata About, metadata store e audit riferimenti legacy.


## v6.0
Pre-release hardening: errori tipizzati, routing scalabile, pruning combinatorio e readiness audit.


## v6.1
Routing matrix, deduplica piani e ordinamento scalabile integrati nel motore reale.


## v6.2
Parsing robusto CSV/JSON, decimali/date italiane e freshness applicata direttamente alle offerte live.


## v6.3
Identità GTIN/EAN, varianti quantità/formato e corretta semantica €/kg per prodotti a peso.


## v6.4
AI orchestratrice advisory-only: comprensione richieste, spiegazioni e review assistita, senza override dei calcoli deterministici.


## v6.5
Assistente AI collegato alla UI: richiesta libera → bozza strutturata → conferma utente → ottimizzatore deterministico.


## v6.6
Provider OpenAI server-side configurabile e catalog resolver deterministico con auto-match conservativo e conferma dei casi ambigui.


## v6.7
Selezione interattiva dei candidati catalogo e memoria per utente delle correzioni confermate.


## v6.8
Assistente conversazionale con stato strutturato: aggiunte/rimozioni e preferenze applicate deterministicamente.


## v6.9
Budget confrontato deterministicamente con i piani reali già ammessi, con scostamento e alternative compatibili con la soglia di risparmio.


## v7.0
Recupero budget con sostituzioni approvate e realmente prezzate, limitate ai supermercati già presenti nel piano per non inventare costi di viaggio.


## v7.1
Console admin delle equivalenze, workflow pending/approved/rejected, suggerimenti AI advisory-only e compatibilità deterministica di formati/peso.


## v7.2
Console visuale per cercare prodotti, vedere marca/formato/GTIN e confrontare offerte fresche normalizzate prima di approvare equivalenze.


## v7.3
Typed API errors integrati nel vero flusso Flutter: demo fallback solo per rete/timeout, errori 409/422 mostrati correttamente e posizione separata dagli errori backend.


## v7.4
Assistente AI senza vicoli ciechi: ricerca completa nel catalogo per articoli non risolti e modifica quantità/unità/marca/equivalenti prima della conferma.


## v7.5
CI automatica: Flutter stable con pub get/analyze/test e backend Python con compileall/pytest ad ogni push o pull request.


## v7.6
Repository Flutter pronto per CI: dipendenza geolocator corretta, bootstrap automatico android/ios, permessi posizione e build APK debug in pipeline.
