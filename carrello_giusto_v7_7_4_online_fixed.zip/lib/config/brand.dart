class Brand {
  static const appName = 'CarrelloGiusto';
  static const payoff = 'La spesa che conviene davvero.';
}
