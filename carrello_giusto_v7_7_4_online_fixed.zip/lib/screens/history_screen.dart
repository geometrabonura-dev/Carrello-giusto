
import 'package:flutter/material.dart';
import '../services/history_service.dart';
import '../services/feedback_service.dart';

class HistoryScreen extends StatefulWidget {
  final String userId;
  const HistoryScreen({super.key, required this.userId});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  final _history = HistoryService();
  final _feedback = FeedbackService();

  bool _loading = true;
  List<dynamic> _choices = [];
  Map<String, dynamic>? _learning;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final choices = await _history.getChoices(widget.userId);
      final learning = await _history.getLearning(widget.userId);
      if (!mounted) return;
      setState(() {
        _choices = choices;
        _learning = learning;
      });
    } catch (_) {
      if (mounted) setState(() { _choices = []; _learning = null; });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _send(String type) async {
    await _feedback.sendFeedback(
      userId: widget.userId,
      feedbackType: type,
    );
    await _load();
  }

  Future<void> _reset() async {
    await _history.resetLearning(widget.userId);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    final suggestion = _learning?['suggested_strategy'];
    final label = suggestion?['strategy'] ?? 'balanced';
    final reason = suggestion?['reason'] ?? '';

    return Scaffold(
      appBar: AppBar(title: const Text('Storico')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Strategia suggerita',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(label),
                  const SizedBox(height: 4),
                  Text(reason),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Cosa preferisci?',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ActionChip(
                label: const Text('Prezzo più basso'),
                onPressed: () => _send('prefer_cheaper'),
              ),
              ActionChip(
                label: const Text('Meno tempo'),
                onPressed: () => _send('prefer_faster'),
              ),
              ActionChip(
                label: const Text('Meno negozi'),
                onPressed: () => _send('prefer_fewer_stores'),
              ),
              ActionChip(
                label: const Text('Troppo lontano'),
                onPressed: () => _send('too_far'),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Storico scelte',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              TextButton(
                onPressed: _reset,
                child: const Text('Reset preferenze'),
              ),
            ],
          ),
          if (_choices.isEmpty)
            const Text('Nessuna scelta registrata.')
          else
            ..._choices.take(20).map((c) {
              final stores = c['stores_count'] ?? 0;
              final total = c['effective_total'];
              final strategy = c['strategy'] ?? '';
              return Card(
                child: ListTile(
                  title: Text('€${total?.toStringAsFixed(2) ?? '--'}'),
                  subtitle: Text('$strategy • $stores supermercato/i'),
                  trailing: c['accepted_recommendation'] == true
                      ? const Icon(Icons.check_circle_outline)
                      : null,
                ),
              );
            }),
        ],
      ),
    );
  }
}
