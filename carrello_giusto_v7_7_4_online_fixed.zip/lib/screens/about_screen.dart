import 'package:flutter/material.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('CarrelloGiusto')),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: const [
          Text(
            'CarrelloGiusto',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Text(
            'La spesa che conviene davvero.',
            style: TextStyle(fontSize: 18),
          ),
          SizedBox(height: 24),
          Text(
            'CarrelloGiusto confronta il costo complessivo della spesa considerando '
            'prezzi, distanza, costo del viaggio, tempo e numero di supermercati.',
          ),
          SizedBox(height: 16),
          Text(
            'L’obiettivo non è trovare semplicemente il prezzo più basso, ma la scelta '
            'che conviene davvero nel complesso.',
          ),
          SizedBox(height: 16),
          Text(
            'Le offerte possono avere livelli di verifica differenti. Le fonti vengono '
            'gestite con provenienza, validità e stato di verifica espliciti.',
          ),
        ],
      ),
    );
  }
}
