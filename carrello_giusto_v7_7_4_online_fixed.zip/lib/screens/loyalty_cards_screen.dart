import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LoyaltyCardsScreen extends StatefulWidget {
  const LoyaltyCardsScreen({super.key});
  @override State<LoyaltyCardsScreen> createState() => _LoyaltyCardsScreenState();
}

class _LoyaltyCardsScreenState extends State<LoyaltyCardsScreen> {
  static const stores = ['Conad','Coop','Esselunga','Carrefour','Lidl','Eurospin','Pam Panorama','Alì'];
  Set<String> enabled = {};
  @override void initState(){ super.initState(); _load(); }
  Future<void> _load() async { final p=await SharedPreferences.getInstance(); if(mounted)setState(()=>enabled=(p.getStringList('loyalty_cards')??[]).toSet()); }
  Future<void> _toggle(String s,bool v) async { setState(()=>v?enabled.add(s):enabled.remove(s)); final p=await SharedPreferences.getInstance(); await p.setStringList('loyalty_cards',enabled.toList()); }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Le mie tessere')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(color:Theme.of(context).colorScheme.primaryContainer.withValues(alpha:.55),child:const Padding(padding:EdgeInsets.all(16),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(Icons.loyalty_outlined),SizedBox(width:12),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Più offerte, più risparmio',style:TextStyle(fontWeight:FontWeight.bold,fontSize:17)),SizedBox(height:4),Text('Attiva le tessere che possiedi: CarrelloGiusto potrà considerare anche le promozioni riservate ai soci.')]))]))),
      const SizedBox(height:12),
      Card(child:Column(children:stores.map((s)=>SwitchListTile(title:Text(s,style:const TextStyle(fontWeight:FontWeight.w600)),secondary:const Icon(Icons.storefront_outlined),value:enabled.contains(s),onChanged:(v)=>_toggle(s,v))).toList())),
      const SizedBox(height:12),
      const Card(child:Padding(padding:EdgeInsets.all(14),child:Row(children:[Icon(Icons.lock_outline),SizedBox(width:10),Expanded(child:Text('Non salviamo numero, barcode o credenziali della tessera. Ci serve solo sapere quali tessere possiedi.'))]))),
    ]),
  );
}
