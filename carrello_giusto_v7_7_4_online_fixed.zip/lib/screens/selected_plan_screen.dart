import 'package:flutter/material.dart';
import '../models/optimization_result.dart';

class SelectedPlanScreen extends StatelessWidget {
  final String title;
  final OptimizationPlan plan;
  const SelectedPlanScreen({super.key, required this.title, required this.plan});

  Map<String, dynamic> _map(dynamic value) => value is Map ? Map<String, dynamic>.from(value) : <String, dynamic>{};

  @override
  Widget build(BuildContext context) {
    final stores = plan.stores.map(_map).toList();
    final assignments = plan.assignments.map(_map).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Il tuo piano')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Text('${plan.storesCount} supermercato/i • ${plan.distanceKm.toStringAsFixed(1)} km • ${(plan.durationMinutes ?? 0).toStringAsFixed(0)} min'),
        const SizedBox(height: 14),
        if (stores.isEmpty)
          Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Row(children: [Icon(Icons.info_outline_rounded), SizedBox(width: 8), Expanded(child: Text('Dettaglio negozi non disponibile nei dati demo', style: TextStyle(fontWeight: FontWeight.bold)))]),
            const SizedBox(height: 8),
            Text('Il piano è stato scelto correttamente. Quando i dati reali del servizio saranno raggiungibili, qui vedrai supermercati, prodotti e prezzi assegnati.'),
          ])))
        else
          ...stores.asMap().entries.map((entry) {
            final store = entry.value;
            final id = (store['id'] ?? store['store_id'] ?? '').toString();
            final name = (store['name'] ?? store['store_name'] ?? 'Supermercato ${entry.key + 1}').toString();
            final items = assignments.where((a) => (a['store_id'] ?? '').toString() == id || (a['store_name'] ?? '').toString() == name).toList();
            final subtotal = items.fold<double>(0, (sum, a) => sum + ((a['cost'] as num?)?.toDouble() ?? 0));
            return Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [CircleAvatar(child: Text('${entry.key + 1}')), const SizedBox(width: 10), Expanded(child: Text(name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)))]),
              const Divider(),
              if (items.isEmpty) const Text('Prodotti assegnati non disponibili.') else ...items.map((a) => ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.shopping_basket_outlined),
                title: Text((a['product_name'] ?? a['label'] ?? a['product_key'] ?? 'Prodotto').toString()),
                subtitle: a['brand'] == null ? null : Text(a['brand'].toString()),
                trailing: Text('€${((a['cost'] as num?)?.toDouble() ?? 0).toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.bold)),
              )),
              if (items.isNotEmpty) Align(alignment: Alignment.centerRight, child: Text('Subtotale €${subtotal.toStringAsFixed(2)}', style: const TextStyle(fontWeight: FontWeight.w800))),
            ])));
          }),
        const SizedBox(height: 12),
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
          _row('Prodotti', plan.productTotal), _row('Viaggio', plan.travelCost), _row('Tempo', plan.timeCost), const Divider(),
          Row(children: [const Expanded(child: Text('Totale effettivo', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))), Text('€${plan.effectiveTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: Color(0xFF079447)))])
        ]))),
      ]),
    );
  }

  Widget _row(String label, double value) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [Expanded(child: Text(label)), Text('€${value.toStringAsFixed(2)}')]));
}
