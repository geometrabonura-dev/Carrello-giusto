import 'package:flutter/material.dart';
import '../models/app_preferences.dart';
import '../services/app_preferences_service.dart';
import 'loyalty_cards_screen.dart';

class SettingsScreen extends StatefulWidget { final String userId; const SettingsScreen({super.key,required this.userId}); @override State<SettingsScreen> createState()=>_SettingsScreenState(); }
class _SettingsScreenState extends State<SettingsScreen>{
 final _service=AppPreferencesService(); AppPreferences? _prefs; bool _saving=false;
 @override void initState(){super.initState();_load();}
 Future<void> _load()async{final p=await _service.loadLocal();if(mounted)setState(()=>_prefs=p);}
 Future<void> _apply(AppPreferences p)async{setState(()=>_prefs=p);await _service.saveLocal(p);}
 Future<void> _save()async{final p=_prefs;if(p==null||_saving)return;setState(()=>_saving=true);await _service.save(widget.userId,p);if(!mounted)return;setState(()=>_saving=false);ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Preferenze salvate sul telefono')));}
 @override Widget build(BuildContext context){final p=_prefs;if(p==null)return const Scaffold(body:Center(child:CircularProgressIndicator()));final label=switch(p.strategy){'max_saving'=>'Massimo risparmio','max_comfort'=>'Massima comodità',_=>'Bilanciata'};return Scaffold(appBar:AppBar(title:const Text('Le mie preferenze')),body:ListView(padding:const EdgeInsets.all(16),children:[
  Card(color:Colors.green.shade50,child:ListTile(leading:const CircleAvatar(child:Icon(Icons.balance)),title:const Text('Strategia suggerita',style:TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('$label\nLe modifiche vengono salvate subito sul telefono.'))),
  const SizedBox(height:14),const Text('Cosa preferisci?',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:[
   ChoiceChip(label:const Text('Prezzo più basso'),selected:p.strategy=='max_saving',onSelected:(_)=>_apply(p.copyWith(strategy:'max_saving'))),
   ChoiceChip(label:const Text('Meno tempo'),selected:p.strategy=='max_comfort'&&p.maxStores!=1,onSelected:(_)=>_apply(p.copyWith(strategy:'max_comfort'))),
   ChoiceChip(label:const Text('Meno negozi'),selected:p.maxStores==1,onSelected:(_)=>_apply(p.copyWith(strategy:'max_comfort',maxStores:1))),
   ChoiceChip(label:const Text('Bilanciato'),selected:p.strategy=='balanced',onSelected:(_)=>_apply(p.copyWith(strategy:'balanced'))),
  ]),
  const SizedBox(height:18),Card(child:ListTile(leading:const Icon(Icons.loyalty_outlined,color:Colors.deepPurple),title:const Text('Le mie tessere',style:TextStyle(fontWeight:FontWeight.bold)),subtitle:const Text('Attiva le carte fedeltà che possiedi per considerare le offerte riservate.'),trailing:const Icon(Icons.chevron_right),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const LoyaltyCardsScreen())))),
  const SizedBox(height:18),Text('Distanza massima: ${p.radiusKm.toStringAsFixed(0)} km',style:const TextStyle(fontWeight:FontWeight.w600)),Slider(value:p.radiusKm,min:2,max:30,divisions:28,onChanged:(v)=>_apply(p.copyWith(radiusKm:v))),
  Text('Massimo supermercati: ${p.maxStores}',style:const TextStyle(fontWeight:FontWeight.w600)),Slider(value:p.maxStores.toDouble(),min:1,max:6,divisions:5,onChanged:(v)=>_apply(p.copyWith(maxStores:v.round()))),
  Text('Risparmio minimo per spostarti: €${p.minSavingToTravel.toStringAsFixed(0)}',style:const TextStyle(fontWeight:FontWeight.w600)),Slider(value:p.minSavingToTravel,min:0,max:10,divisions:10,onChanged:(v)=>_apply(p.copyWith(minSavingToTravel:v))),
  DropdownButtonFormField<String>(initialValue:p.travelProfile,decoration:const InputDecoration(labelText:'Come ti sposti?',border:OutlineInputBorder()),items:const [DropdownMenuItem(value:'car',child:Text('Auto')),DropdownMenuItem(value:'motorbike',child:Text('Moto')),DropdownMenuItem(value:'bike',child:Text('Bici')),DropdownMenuItem(value:'walking',child:Text('A piedi'))],onChanged:(v){if(v!=null)_apply(p.copyWith(travelProfile:v));}),
  const SizedBox(height:22),FilledButton.icon(onPressed:_saving?null:_save,icon:const Icon(Icons.cloud_sync_outlined),label:Text(_saving?'Sincronizzazione…':'Salva e sincronizza')),
 ]));}
}
