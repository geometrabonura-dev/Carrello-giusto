
import 'package:flutter/material.dart';
import '../services/onboarding_service.dart';
import '../services/preferences_sync_service.dart';

class OnboardingScreen extends StatefulWidget {
  final String userId;
  final VoidCallback onCompleted;
  const OnboardingScreen({
    super.key,
    required this.userId,
    required this.onCompleted,
  });

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  String _strategy = 'balanced';
  bool _saving = false;
  String? _warning;

  Future<void> _finish() async {
    setState(() {
      _saving = true;
      _warning = null;
    });

    await OnboardingService().complete(_strategy);

    try {
      await PreferencesSyncService().syncInitialStrategy(
        userId: widget.userId,
        strategy: _strategy,
      );
    } catch (_) {
      _warning = 'Preferenza salvata sul telefono. La sincronizzazione col backend avverrà più avanti.';
    }

    if (!mounted) return;
    widget.onCompleted();
  }

  Widget _option({
    required String value,
    required IconData icon,
    required String title,
    required String subtitle,
  }) {
    return Card(
      child: RadioListTile<String>(
        value: value,
        groupValue: _strategy,
        onChanged: (v) => setState(() => _strategy = v ?? 'balanced'),
        secondary: Icon(icon),
        title: Text(title),
        subtitle: Text(subtitle),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Benvenuto in CarrelloGiusto')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Cosa conta di più per te?',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Puoi cambiare questa scelta in qualsiasi momento.',
          ),
          const SizedBox(height: 20),
          _option(
            value: 'max_saving',
            icon: Icons.savings_outlined,
            title: 'Risparmiare il più possibile',
            subtitle: 'Accetto qualche minuto o negozio in più se il risparmio vale la pena.',
          ),
          _option(
            value: 'balanced',
            icon: Icons.balance_outlined,
            title: 'Un buon equilibrio',
            subtitle: 'Voglio bilanciare prezzo, tempo e semplicità.',
          ),
          _option(
            value: 'max_comfort',
            icon: Icons.home_outlined,
            title: 'Fare prima e con meno tappe',
            subtitle: 'Preferisco comodità, meno strada e meno supermercati.',
          ),
          if (_warning != null) ...[
            const SizedBox(height: 12),
            Text(_warning!),
          ],
          const SizedBox(height: 24),
          FilledButton(
            onPressed: _saving ? null : _finish,
            child: Text(_saving ? 'Salvataggio…' : 'Inizia'),
          ),
        ],
      ),
    );
  }
}
