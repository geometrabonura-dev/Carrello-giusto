
class CatalogProduct {
  final String productKey;
  final String name;
  final String? brand;
  final String unit;
  final double defaultQuantity;
  final bool strictBrand;
  final bool allowFractionalQuantity;

  const CatalogProduct({
    required this.productKey,
    required this.name,
    required this.unit,
    required this.defaultQuantity,
    required this.strictBrand,
    required this.allowFractionalQuantity,
    this.brand,
  });

  factory CatalogProduct.fromJson(Map<String, dynamic> json) {
    return CatalogProduct(
      productKey: (json['product_key'] ?? '').toString(),
      name: (json['name'] ?? '').toString(),
      brand: json['brand']?.toString(),
      unit: (json['unit'] ?? 'pezzo').toString(),
      defaultQuantity:
          (json['default_quantity'] as num?)?.toDouble() ?? 1.0,
      strictBrand: json['strict_brand'] == true,
      allowFractionalQuantity:
          json['allow_fractional_quantity'] == true,
    );
  }
}
