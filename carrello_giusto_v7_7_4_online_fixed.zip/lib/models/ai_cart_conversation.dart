import 'ai_cart_draft.dart';

class AiCartConversationPreferences {
  final String strategy;
  final int maxStores;
  final double minSavingToTravel;
  final double? budgetCap;

  const AiCartConversationPreferences({
    this.strategy = 'balanced',
    this.maxStores = 3,
    this.minSavingToTravel = 3,
    this.budgetCap,
  });

  factory AiCartConversationPreferences.fromJson(
    Map<String, dynamic> json,
  ) {
    return AiCartConversationPreferences(
      strategy: (json['strategy'] ?? 'balanced').toString(),
      maxStores: (json['max_stores'] as num?)?.toInt() ?? 3,
      minSavingToTravel:
          (json['min_saving_to_travel'] as num?)?.toDouble() ?? 3,
      budgetCap: (json['budget_cap'] as num?)?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() => {
        'strategy': strategy,
        'max_stores': maxStores,
        'min_saving_to_travel': minSavingToTravel,
        'budget_cap': budgetCap,
      };
}

class AiCartConversationState {
  final List<AiCartDraftItem> items;
  final AiCartConversationPreferences preferences;
  final List<String> notes;

  const AiCartConversationState({
    this.items = const [],
    this.preferences = const AiCartConversationPreferences(),
    this.notes = const [],
  });

  factory AiCartConversationState.fromJson(Map<String, dynamic> json) {
    return AiCartConversationState(
      items: (json['items'] as List<dynamic>? ?? const [])
          .map((e) => AiCartDraftItem.fromJson(
                Map<String, dynamic>.from(e as Map),
              ))
          .toList(),
      preferences: AiCartConversationPreferences.fromJson(
        Map<String, dynamic>.from(
          json['preferences'] as Map? ?? const {},
        ),
      ),
      notes: (json['notes'] as List<dynamic>? ?? const [])
          .map((e) => e.toString())
          .toList(),
    );
  }

  Map<String, dynamic> toJson() => {
        'items': items
            .map((e) => {
                  'product_key': e.productKey,
                  'label': e.label,
                  'quantity': e.quantity,
                  'unit': e.unit,
                  'preferred_brand': e.preferredBrand,
                  'allow_equivalents': e.allowEquivalents,
                  'constraints': e.constraints,
                  'match_status': e.matchStatus,
                  'match_confidence': e.matchConfidence,
                  'catalog_candidates': e.catalogCandidates,
                })
            .toList(),
        'preferences': preferences.toJson(),
        'notes': notes,
      };
}

class AiCartChatResult {
  final String reply;
  final AiCartConversationState state;
  final bool usedAi;

  const AiCartChatResult({
    required this.reply,
    required this.state,
    required this.usedAi,
  });

  factory AiCartChatResult.fromJson(Map<String, dynamic> json) {
    return AiCartChatResult(
      reply: (json['reply'] ?? '').toString(),
      state: AiCartConversationState.fromJson(
        Map<String, dynamic>.from(json['state'] as Map? ?? const {}),
      ),
      usedAi: json['used_ai'] as bool? ?? false,
    );
  }
}
