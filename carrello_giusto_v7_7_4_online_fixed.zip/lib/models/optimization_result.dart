
class BudgetSubstitutionSuggestion {
  final String sourceProductKey;
  final String sourceLabel;
  final String alternativeProductKey;
  final String alternativeLabel;
  final String storeName;
  final double currentCost;
  final double alternativeCost;
  final double saving;
  final String? currentBrand;
  final String? alternativeBrand;
  final bool alternativeVerified;
  final bool loyaltyRequired;

  const BudgetSubstitutionSuggestion({
    required this.sourceProductKey,
    required this.sourceLabel,
    required this.alternativeProductKey,
    required this.alternativeLabel,
    required this.storeName,
    required this.currentCost,
    required this.alternativeCost,
    required this.saving,
    required this.currentBrand,
    required this.alternativeBrand,
    required this.alternativeVerified,
    required this.loyaltyRequired,
  });

  factory BudgetSubstitutionSuggestion.fromJson(Map<String, dynamic> json) {
    return BudgetSubstitutionSuggestion(
      sourceProductKey: (json['source_product_key'] ?? '').toString(),
      sourceLabel: (json['source_label'] ?? '').toString(),
      alternativeProductKey:
          (json['alternative_product_key'] ?? '').toString(),
      alternativeLabel: (json['alternative_label'] ?? '').toString(),
      storeName: (json['store_name'] ?? '').toString(),
      currentCost: (json['current_cost'] as num?)?.toDouble() ?? 0,
      alternativeCost:
          (json['alternative_cost'] as num?)?.toDouble() ?? 0,
      saving: (json['saving'] as num?)?.toDouble() ?? 0,
      currentBrand: json['current_brand']?.toString(),
      alternativeBrand: json['alternative_brand']?.toString(),
      alternativeVerified: json['alternative_verified'] == true,
      loyaltyRequired: json['loyalty_required'] == true,
    );
  }
}

class BudgetAnalysis {
  final double budgetCap;
  final double recommendedTotal;
  final bool withinBudget;
  final double difference;
  final double suggestedSaving;
  final bool canCloseGap;
  final List<BudgetSubstitutionSuggestion> substitutions;

  const BudgetAnalysis({
    required this.budgetCap,
    required this.recommendedTotal,
    required this.withinBudget,
    required this.difference,
    required this.suggestedSaving,
    required this.canCloseGap,
    required this.substitutions,
  });

  factory BudgetAnalysis.fromJson(Map<String, dynamic> json) {
    final recovery = json['recovery'] is Map
        ? Map<String, dynamic>.from(json['recovery'] as Map)
        : <String, dynamic>{};

    return BudgetAnalysis(
      budgetCap: (json['budget_cap'] as num?)?.toDouble() ?? 0,
      recommendedTotal:
          (json['recommended_total'] as num?)?.toDouble() ?? 0,
      withinBudget: json['within_budget'] == true,
      difference: (json['difference'] as num?)?.toDouble() ?? 0,
      suggestedSaving:
          (recovery['suggested_saving'] as num?)?.toDouble() ?? 0,
      canCloseGap: recovery['can_close_gap'] == true,
      substitutions:
          ((recovery['substitutions'] as List?) ?? const [])
              .whereType<Map>()
              .map((e) => BudgetSubstitutionSuggestion.fromJson(
                    Map<String, dynamic>.from(e),
                  ))
              .toList(),
    );
  }
}


class OptimizationPlan {
  final String key;
  final double productTotal;
  final double travelCost;
  final double timeCost;
  final double effectiveTotal;
  final double distanceKm;
  final double? durationMinutes;
  final int storesCount;
  final bool recommended;
  final bool eligibleByThreshold;
  final double savingVsClosest;
  final double storePenalty;
  final double? strategyScore;
  final List<dynamic> stores;
  final List<dynamic> assignments;

  const OptimizationPlan({
    required this.key,
    required this.productTotal,
    required this.travelCost,
    required this.timeCost,
    required this.effectiveTotal,
    required this.distanceKm,
    required this.durationMinutes,
    required this.storesCount,
    required this.recommended,
    required this.eligibleByThreshold,
    required this.savingVsClosest,
    required this.storePenalty,
    required this.strategyScore,
    required this.stores,
    required this.assignments,
  });

  factory OptimizationPlan.fromJson(Map<String, dynamic> json) {
    return OptimizationPlan(
      key: (json['plan_key'] ?? '').toString(),
      productTotal: (json['product_total'] as num?)?.toDouble() ?? 0,
      travelCost: (json['travel_cost'] as num?)?.toDouble() ?? 0,
      timeCost: (json['time_cost'] as num?)?.toDouble() ?? 0,
      effectiveTotal: (json['effective_total'] as num?)?.toDouble() ?? 0,
      distanceKm: (json['distance_km'] as num?)?.toDouble() ?? 0,
      durationMinutes: (json['duration_minutes'] as num?)?.toDouble(),
      storesCount: (json['stores_count'] as num?)?.toInt() ??
          ((json['stores'] as List?)?.length ?? 0),
      recommended: json['recommended'] == true,
      eligibleByThreshold: json['eligible_by_threshold'] != false,
      savingVsClosest:
          (json['saving_vs_closest'] as num?)?.toDouble() ?? 0,
      storePenalty: (json['store_penalty'] as num?)?.toDouble() ?? 0,
      strategyScore: (json['strategy_score'] as num?)?.toDouble(),
      stores: (json['stores'] as List?) ?? const [],
      assignments: (json['assignments'] as List?) ?? const [],
    );
  }
}

class OptimizationResult {
  final OptimizationPlan recommendation;
  final OptimizationPlan? closestPlan;
  final OptimizationPlan? maxSavingPlan;
  final OptimizationPlan? bestSingleStore;
  final List<OptimizationPlan> plans;
  final String dataStatus;
  final String strategyLabel;
  final String? explanationHeadline;
  final List<String> explanationReasons;
  final int maxStores;
  final double minSavingToTravel;
  final BudgetAnalysis? budgetAnalysis;

  const OptimizationResult({
    required this.recommendation,
    required this.closestPlan,
    required this.maxSavingPlan,
    required this.bestSingleStore,
    required this.plans,
    required this.dataStatus,
    required this.strategyLabel,
    required this.explanationHeadline,
    required this.explanationReasons,
    required this.maxStores,
    required this.minSavingToTravel,
    required this.budgetAnalysis,
  });

  factory OptimizationResult.fromApi(Map<String, dynamic> root) {
    OptimizationPlan? plan(String key) {
      final raw = root[key];
      return raw is Map<String, dynamic>
          ? OptimizationPlan.fromJson(raw)
          : raw is Map
              ? OptimizationPlan.fromJson(
                  Map<String, dynamic>.from(raw),
                )
              : null;
    }

    final recommendation = plan('recommendation');
    if (recommendation == null) {
      throw const FormatException('recommendation mancante');
    }

    final explanation = root['explanation'];
    final rule = root['rule'];
    final strategy = root['strategy'];
    final budgetAnalysisRaw = root['budget_analysis'];

    return OptimizationResult(
      recommendation: recommendation,
      closestPlan: plan('closest_plan'),
      maxSavingPlan: plan('max_saving_plan'),
      bestSingleStore: plan('best_single_store'),
      plans: ((root['plans'] as List?) ?? const [])
          .whereType<Map>()
          .map((e) => OptimizationPlan.fromJson(
                Map<String, dynamic>.from(e),
              ))
          .toList(),
      dataStatus: (root['data_status'] ?? 'unverified').toString(),
      strategyLabel: strategy is Map
          ? (strategy['label'] ?? strategy['key'] ?? 'Bilanciato').toString()
          : 'Bilanciato',
      explanationHeadline: explanation is Map
          ? explanation['headline']?.toString()
          : null,
      explanationReasons: explanation is Map
          ? ((explanation['reasons'] as List?) ?? const [])
              .map((e) => e.toString())
              .toList()
          : const [],
      maxStores: rule is Map
          ? (rule['max_stores'] as num?)?.toInt() ?? 3
          : 3,
      minSavingToTravel: rule is Map
          ? (rule['min_saving_to_travel'] as num?)?.toDouble() ?? 3
          : 3,
      budgetAnalysis: budgetAnalysisRaw is Map
          ? BudgetAnalysis.fromJson(
              Map<String, dynamic>.from(budgetAnalysisRaw),
            )
          : null,
    );
  }
}
