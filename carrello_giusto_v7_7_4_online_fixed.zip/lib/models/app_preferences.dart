
class AppPreferences {
  final String strategy;
  final double radiusKm;
  final String travelProfile;
  final double minSavingToTravel;
  final int maxStores;

  const AppPreferences({
    this.strategy = 'balanced',
    this.radiusKm = 10,
    this.travelProfile = 'car',
    this.minSavingToTravel = 3,
    this.maxStores = 3,
  });

  AppPreferences copyWith({
    String? strategy,
    double? radiusKm,
    String? travelProfile,
    double? minSavingToTravel,
    int? maxStores,
  }) => AppPreferences(
        strategy: strategy ?? this.strategy,
        radiusKm: radiusKm ?? this.radiusKm,
        travelProfile: travelProfile ?? this.travelProfile,
        minSavingToTravel: minSavingToTravel ?? this.minSavingToTravel,
        maxStores: maxStores ?? this.maxStores,
      );
}
