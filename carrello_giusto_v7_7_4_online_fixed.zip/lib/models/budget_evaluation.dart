import 'optimization_result.dart';

class BudgetEvaluation {
  final double budgetCap;
  final bool recommendationWithinBudget;
  final double difference;
  final OptimizationPlan? bestPlanWithinBudget;
  final OptimizationPlan? cheapestEligiblePlan;

  const BudgetEvaluation({
    required this.budgetCap,
    required this.recommendationWithinBudget,
    required this.difference,
    required this.bestPlanWithinBudget,
    required this.cheapestEligiblePlan,
  });
}
