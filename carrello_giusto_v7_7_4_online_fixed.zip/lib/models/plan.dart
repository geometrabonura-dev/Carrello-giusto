class Plan {
  final String label;
  final List<String> stores;
  final int storeCount;
  final double productTotal;
  final double travelCost;
  final double effectiveTotal;
  final double distanceKm;
  final double savingVsClosest;
  final String reason;
  final Map<String, Map<String, dynamic>> assignment;

  Plan({
    required this.label,
    required this.stores,
    required this.storeCount,
    required this.productTotal,
    required this.travelCost,
    required this.effectiveTotal,
    required this.distanceKm,
    required this.savingVsClosest,
    required this.reason,
    required this.assignment,
  });

  factory Plan.fromJson(String label, Map<String, dynamic> json) {
    return Plan(
      label: label,
      stores: List<String>.from(json['stores'] ?? const []),
      storeCount: json['store_count'] ?? 0,
      productTotal: (json['product_total'] ?? 0).toDouble(),
      travelCost: (json['travel_cost'] ?? 0).toDouble(),
      effectiveTotal: (json['effective_total'] ?? 0).toDouble(),
      distanceKm: (json['distance_km'] ?? 0).toDouble(),
      savingVsClosest: (json['saving_vs_closest'] ?? 0).toDouble(),
      reason: json['reason'] ?? '',
      assignment: Map<String, Map<String, dynamic>>.from(
        (json['assignment'] ?? const {}).map(
          (key, value) => MapEntry(
            key.toString(),
            Map<String, dynamic>.from(value),
          ),
        ),
      ),
    );
  }
}
