
class ShoppingItem {
  final String productKey;
  final String label;
  final double quantity;
  final String unit;
  final String? preferredBrand;
  final bool allowEquivalents;

  const ShoppingItem({
    required this.productKey,
    required this.label,
    required this.quantity,
    required this.unit,
    this.preferredBrand,
    this.allowEquivalents = true,
  });

  ShoppingItem copyWith({
    String? productKey,
    String? label,
    double? quantity,
    String? unit,
    String? preferredBrand,
    bool? allowEquivalents,
  }) {
    return ShoppingItem(
      productKey: productKey ?? this.productKey,
      label: label ?? this.label,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      preferredBrand: preferredBrand ?? this.preferredBrand,
      allowEquivalents: allowEquivalents ?? this.allowEquivalents,
    );
  }

  Map<String, dynamic> toApiJson() => {
        'product_key': productKey,
        'quantity': quantity,
        'unit': unit,
        'preferred_brand': preferredBrand,
        'allow_equivalents': allowEquivalents,
      };
}
