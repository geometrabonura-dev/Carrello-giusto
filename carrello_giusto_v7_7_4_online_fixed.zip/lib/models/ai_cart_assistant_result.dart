import 'shopping_item.dart';

class AiCartAssistantResult {
  final List<ShoppingItem> items;
  final String strategy;
  final int maxStores;
  final double minSavingToTravel;
  final double? budgetCap;

  const AiCartAssistantResult({
    required this.items,
    required this.strategy,
    required this.maxStores,
    required this.minSavingToTravel,
    this.budgetCap,
  });
}
