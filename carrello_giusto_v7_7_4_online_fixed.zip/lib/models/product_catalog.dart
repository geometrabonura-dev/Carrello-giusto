
import 'shopping_item.dart';

class ProductCatalog {
  static const defaults = <ShoppingItem>[
    ShoppingItem(
      productKey: 'pasta1kg',
      label: 'Pasta',
      quantity: 1,
      unit: 'kg',
      allowEquivalents: true,
    ),
    ShoppingItem(
      productKey: 'olio_evo_1l',
      label: 'Olio EVO',
      quantity: 1,
      unit: 'L',
      allowEquivalents: true,
    ),
    ShoppingItem(
      productKey: 'rio_mare_tonno',
      label: 'Tonno Rio Mare all’olio',
      quantity: 1,
      unit: 'confezione',
      preferredBrand: 'Rio Mare',
      allowEquivalents: false,
    ),
    ShoppingItem(
      productKey: 'uva_senza_semi',
      label: 'Uva senza semi',
      quantity: 1,
      unit: 'kg',
      allowEquivalents: true,
    ),
    ShoppingItem(
      productKey: 'fiorentina',
      label: 'Fiorentina',
      quantity: 1,
      unit: 'pezzo',
      allowEquivalents: true,
    ),
  ];
}
