class AiAssistanceStatus {
  final bool enabled;
  final bool advisoryOnly;

  const AiAssistanceStatus({
    required this.enabled,
    this.advisoryOnly = true,
  });

  static const disabled = AiAssistanceStatus(enabled: false);
}
