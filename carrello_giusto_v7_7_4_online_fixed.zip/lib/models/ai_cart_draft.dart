class AiCartDraftItem {
  final String? productKey;
  final String label;
  final double quantity;
  final String unit;
  final String? preferredBrand;
  final bool allowEquivalents;
  final List<String> constraints;
  final String matchStatus;
  final double matchConfidence;
  final List<Map<String, dynamic>> catalogCandidates;

  const AiCartDraftItem({
    this.productKey,
    required this.label,
    required this.quantity,
    required this.unit,
    this.preferredBrand,
    this.allowEquivalents = true,
    this.constraints = const [],
    this.matchStatus = 'unmatched',
    this.matchConfidence = 0,
    this.catalogCandidates = const [],
  });


  AiCartDraftItem copyWith({
    String? productKey,
    bool clearProductKey = false,
    String? label,
    double? quantity,
    String? unit,
    String? preferredBrand,
    bool clearPreferredBrand = false,
    bool? allowEquivalents,
    List<String>? constraints,
    String? matchStatus,
    double? matchConfidence,
    List<Map<String, dynamic>>? catalogCandidates,
  }) {
    return AiCartDraftItem(
      productKey: clearProductKey ? null : (productKey ?? this.productKey),
      label: label ?? this.label,
      quantity: quantity ?? this.quantity,
      unit: unit ?? this.unit,
      preferredBrand:
          clearPreferredBrand ? null : (preferredBrand ?? this.preferredBrand),
      allowEquivalents: allowEquivalents ?? this.allowEquivalents,
      constraints: constraints ?? this.constraints,
      matchStatus: matchStatus ?? this.matchStatus,
      matchConfidence: matchConfidence ?? this.matchConfidence,
      catalogCandidates: catalogCandidates ?? this.catalogCandidates,
    );
  }

  factory AiCartDraftItem.fromJson(Map<String, dynamic> json) {
    return AiCartDraftItem(
      productKey: json['product_key'] as String?,
      label: (json['label'] ?? '').toString(),
      quantity: (json['quantity'] as num?)?.toDouble() ?? 1,
      unit: (json['unit'] ?? 'piece').toString(),
      preferredBrand: json['preferred_brand'] as String?,
      allowEquivalents: json['allow_equivalents'] as bool? ?? true,
      constraints: (json['constraints'] as List<dynamic>? ?? const [])
          .map((e) => e.toString())
          .toList(),
      matchStatus: (json['match_status'] ?? 'unmatched').toString(),
      matchConfidence:
          (json['match_confidence'] as num?)?.toDouble() ?? 0,
      catalogCandidates:
          (json['catalog_candidates'] as List<dynamic>? ?? const [])
              .map((e) => Map<String, dynamic>.from(e as Map))
              .toList(),
    );
  }
}

class AiCartDraft {
  final String rawText;
  final List<AiCartDraftItem> items;
  final List<String> ambiguities;
  final List<String> notes;
  final bool requiresConfirmation;
  final bool usedAi;

  const AiCartDraft({
    required this.rawText,
    required this.items,
    required this.ambiguities,
    required this.notes,
    required this.requiresConfirmation,
    required this.usedAi,
  });


  AiCartDraft copyWith({
    List<AiCartDraftItem>? items,
    List<String>? ambiguities,
    List<String>? notes,
    bool? requiresConfirmation,
    bool? usedAi,
  }) {
    return AiCartDraft(
      rawText: rawText,
      items: items ?? this.items,
      ambiguities: ambiguities ?? this.ambiguities,
      notes: notes ?? this.notes,
      requiresConfirmation:
          requiresConfirmation ?? this.requiresConfirmation,
      usedAi: usedAi ?? this.usedAi,
    );
  }

  factory AiCartDraft.fromJson(Map<String, dynamic> json) {
    return AiCartDraft(
      rawText: (json['raw_text'] ?? '').toString(),
      items: (json['items'] as List<dynamic>? ?? const [])
          .map((e) => AiCartDraftItem.fromJson(
                Map<String, dynamic>.from(e as Map),
              ))
          .toList(),
      ambiguities: (json['ambiguities'] as List<dynamic>? ?? const [])
          .map((e) => e.toString())
          .toList(),
      notes: (json['notes'] as List<dynamic>? ?? const [])
          .map((e) => e.toString())
          .toList(),
      requiresConfirmation: json['requires_confirmation'] as bool? ?? true,
      usedAi: json['used_ai'] as bool? ?? false,
    );
  }
}
