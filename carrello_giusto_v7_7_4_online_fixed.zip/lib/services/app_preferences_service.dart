
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_preferences.dart';

class AppPreferencesService {
  static const _strategyKey = 'preferred_strategy';
  static const _radiusKey = 'preferred_radius_km';
  static const _travelProfileKey = 'preferred_travel_profile';
  static const _minSavingKey = 'preferred_min_saving';
  static const _maxStoresKey = 'preferred_max_stores';

  final String baseUrl;
  final http.Client client;

  AppPreferencesService({
    this.baseUrl = 'https://carrello-giusto.onrender.com',
    http.Client? client,
  }) : client = client ?? http.Client();

  Future<AppPreferences> loadLocal() async {
    final p = await SharedPreferences.getInstance();
    return AppPreferences(
      strategy: p.getString(_strategyKey) ?? 'balanced',
      radiusKm: (p.getDouble(_radiusKey) ?? 10).clamp(2, 30),
      travelProfile: p.getString(_travelProfileKey) ?? 'car',
      minSavingToTravel: (p.getDouble(_minSavingKey) ?? 3).clamp(0, 10),
      maxStores: (p.getInt(_maxStoresKey) ?? 3).clamp(1, 6),
    );
  }

  Future<void> saveLocal(AppPreferences value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_strategyKey, value.strategy);
    await p.setDouble(_radiusKey, value.radiusKm.clamp(2, 30));
    await p.setString(_travelProfileKey, value.travelProfile);
    await p.setDouble(_minSavingKey, value.minSavingToTravel.clamp(0, 10));
    await p.setInt(_maxStoresKey, value.maxStores.clamp(1, 6));
  }

  Future<void> syncBackend(String userId, AppPreferences value) async {
    final weights = switch (value.strategy) {
      'max_saving' => (0.75, 0.15, 0.10, 0.25),
      'max_comfort' => (0.25, 0.35, 0.40, 1.50),
      _ => (0.50, 0.25, 0.25, 0.75),
    };

    final response = await client.put(
      Uri.parse('$baseUrl/v3/preferences/$userId'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'radius_km': value.radiusKm.clamp(2, 30),
        'travel_profile': value.travelProfile,
        'min_saving_to_travel': value.minSavingToTravel.clamp(0, 10),
        'max_travel_minutes': null,
        'max_stores': value.maxStores.clamp(1, 6),
        'vehicle_cost_per_km': null,
        'time_value_per_hour': null,
        'weight_saving': weights.$1,
        'weight_time': weights.$2,
        'weight_simplicity': weights.$3,
        'store_penalty_eur': weights.$4,
      }),
    ).timeout(const Duration(seconds: 8));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Sincronizzazione preferenze fallita');
    }
  }

  Future<void> save(String userId, AppPreferences value) async {
    await saveLocal(value);
    try {
      await syncBackend(userId, value);
    } catch (_) {}
  }
}
