
import 'choice_service.dart';

class PlanSelectionService {
  final ChoiceService service;

  PlanSelectionService({ChoiceService? service})
      : service = service ?? ChoiceService();

  Future<void> selectPlan({
    required String userId,
    required String planKey,
    required String recommendedPlanKey,
    required int storesCount,
    required double productTotal,
    required double travelCost,
    required double timeCost,
    required double effectiveTotal,
    required double? durationMinutes,
    required double distanceKm,
  }) {
    return service.recordChoice(
      userId: userId,
      strategy: 'selected',
      chosenPlanKey: planKey,
      recommendedPlanKey: recommendedPlanKey,
      acceptedRecommendation: planKey == recommendedPlanKey,
      storesCount: storesCount,
      productTotal: productTotal,
      travelCost: travelCost,
      timeCost: timeCost,
      effectiveTotal: effectiveTotal,
      durationMinutes: durationMinutes,
      distanceKm: distanceKm,
    );
  }
}
