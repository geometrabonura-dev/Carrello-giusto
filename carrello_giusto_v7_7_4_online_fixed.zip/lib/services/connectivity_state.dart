
class ConnectivityState {
  final bool online;
  final String message;

  const ConnectivityState({
    required this.online,
    required this.message,
  });

  factory ConnectivityState.online() => const ConnectivityState(
        online: true,
        message: 'Connesso',
      );

  factory ConnectivityState.offline() => const ConnectivityState(
        online: false,
        message: 'Offline: verranno usati dati demo o cache locale quando disponibili.',
      );
}
