
import '../models/optimization_result.dart';

class DemoResultService {
  OptimizationResult build({String? fallbackReason}) {
    const recommended = OptimizationPlan(
      key: 'demo-recommended',
      productTotal: 46.00,
      travelCost: 1.20,
      timeCost: 1.50,
      effectiveTotal: 48.70,
      distanceKm: 6.0,
      durationMinutes: 12.0,
      storesCount: 2,
      recommended: true,
      eligibleByThreshold: true,
      savingVsClosest: 3.30,
      storePenalty: 0.75,
      strategyScore: 0.72,
      stores: [],
      assignments: [],
    );

    const closest = OptimizationPlan(
      key: 'demo-closest',
      productTotal: 50.00,
      travelCost: 0.60,
      timeCost: 1.40,
      effectiveTotal: 52.00,
      distanceKm: 3.0,
      durationMinutes: 10.0,
      storesCount: 1,
      recommended: false,
      eligibleByThreshold: true,
      savingVsClosest: 0.0,
      storePenalty: 0.0,
      strategyScore: 0.65,
      stores: [],
      assignments: [],
    );

    return const OptimizationResult(
      recommendation: recommended,
      closestPlan: closest,
      maxSavingPlan: recommended,
      bestSingleStore: closest,
      plans: [recommended, closest],
      dataStatus: 'demo',
      strategyLabel: 'Bilanciato',
      explanationHeadline: 'Risultato dimostrativo',
      explanationReasons: [
        'Dati demo usati solo come fallback temporaneo.',
        if (fallbackReason != null) 'Motivo fallback: $fallbackReason.',
      ],
      maxStores: 3,
      minSavingToTravel: 3.0,
      budgetAnalysis: null,
    );
  }
}
