import '../models/budget_evaluation.dart';
import '../models/optimization_result.dart';

class BudgetEvaluatorV69 {
  const BudgetEvaluatorV69();

  BudgetEvaluation evaluate({
    required OptimizationResult result,
    required double budgetCap,
  }) {
    final budget = budgetCap < 0.01 ? 0.01 : budgetCap;
    final recommendation = result.recommendation;

    final eligible = result.plans
        .where((plan) => plan.eligibleByThreshold)
        .toList()
      ..sort((a, b) {
        final byTotal = a.effectiveTotal.compareTo(b.effectiveTotal);
        if (byTotal != 0) return byTotal;
        final byStores = a.storesCount.compareTo(b.storesCount);
        if (byStores != 0) return byStores;
        return a.key.compareTo(b.key);
      });

    OptimizationPlan? bestWithin;
    for (final plan in eligible) {
      if (plan.effectiveTotal <= budget) {
        bestWithin = plan;
        break;
      }
    }

    final cheapest = eligible.isEmpty ? null : eligible.first;

    return BudgetEvaluation(
      budgetCap: budget,
      recommendationWithinBudget:
          recommendation.effectiveTotal <= budget,
      difference: (recommendation.effectiveTotal - budget).abs(),
      bestPlanWithinBudget: bestWithin,
      cheapestEligiblePlan: cheapest,
    );
  }
}
