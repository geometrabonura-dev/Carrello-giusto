
import 'choice_service.dart';

class SelectionController {
  final ChoiceService choiceService;
  SelectionController({ChoiceService? choiceService})
      : choiceService = choiceService ?? ChoiceService();

  Future<String?> selectPlan({
    required String userId,
    required String strategy,
    required String chosenPlanKey,
    required String recommendedPlanKey,
    required int storesCount,
    required double productTotal,
    required double travelCost,
    required double timeCost,
    required double effectiveTotal,
    double? durationMinutes,
    double? distanceKm,
  }) {
    return choiceService.recordChoice(
      userId: userId,
      strategy: strategy,
      chosenPlanKey: chosenPlanKey,
      recommendedPlanKey: recommendedPlanKey,
      acceptedRecommendation: chosenPlanKey == recommendedPlanKey,
      storesCount: storesCount,
      productTotal: productTotal,
      travelCost: travelCost,
      timeCost: timeCost,
      effectiveTotal: effectiveTotal,
      durationMinutes: durationMinutes,
      distanceKm: distanceKm,
    );
  }
}
