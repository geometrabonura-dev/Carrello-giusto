class ApiException implements Exception {
  final int? statusCode;
  final String code;
  final String message;
  final Map<String, dynamic> details;

  const ApiException({
    required this.code,
    required this.message,
    this.statusCode,
    this.details = const {},
  });

  String userMessage() {
    switch (code) {
      case 'cart_incomplete':
        final missing = details['missing_items'];
        if (missing is List && missing.isNotEmpty) {
          return 'Non trovo offerte utilizzabili per: '
              '${missing.map((e) => e.toString()).join(', ')}.';
        }
        return 'Non ci sono offerte utilizzabili per tutti i prodotti della lista.';
      case 'no_complete_plan':
        return 'Non riesco a costruire una spesa completa con i supermercati disponibili.';
      case 'no_stores_in_radius':
        return 'Non risultano supermercati con offerte nel raggio scelto. Prova ad aumentarlo.';
      case 'validation_error':
        return 'Alcuni dati della lista non sono validi. Controlla quantità e preferenze.';
      case 'server_error':
        return 'Il servizio non è disponibile correttamente in questo momento.';
      case 'timeout':
        return 'La ricerca sta impiegando troppo tempo.';
      case 'network_error':
        return 'Non riesco a collegarmi al servizio.';
      case 'temporary_unavailable':
        return 'Il servizio è temporaneamente non disponibile.';
      default:
        return message.isNotEmpty
            ? message
            : 'Si è verificato un errore durante l’ottimizzazione.';
    }
  }

  @override
  String toString() => 'ApiException($code, $statusCode): $message';
}

class ApiErrorPolicyV60 {
  static bool shouldFallbackToDemo({
    required int? statusCode,
    required String? code,
  }) {
    if (statusCode == 408 || statusCode == 429) return true;
    return const {
      'network_error',
      'timeout',
      'temporary_unavailable',
    }.contains(code);
  }

  static bool isFunctionalError({
    required int? statusCode,
    required String? code,
  }) {
    if (statusCode == 422) return true;
    if (statusCode == 409) {
      return const {
        'cart_incomplete',
        'no_complete_plan',
        'no_stores_in_radius',
      }.contains(code);
    }
    return false;
  }
}
