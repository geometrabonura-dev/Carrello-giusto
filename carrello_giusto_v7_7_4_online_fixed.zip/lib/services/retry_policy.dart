
import 'dart:async';

class RetryPolicy {
  final int maxAttempts;
  final Duration initialDelay;

  const RetryPolicy({
    this.maxAttempts = 3,
    this.initialDelay = const Duration(milliseconds: 500),
  });

  Future<T> run<T>(Future<T> Function() operation) async {
    Object? lastError;
    for (var attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await operation();
      } catch (e) {
        lastError = e;
        if (attempt >= maxAttempts) break;
        final delay = initialDelay * attempt;
        await Future.delayed(delay);
      }
    }
    throw lastError ?? Exception('Operazione fallita');
  }
}
