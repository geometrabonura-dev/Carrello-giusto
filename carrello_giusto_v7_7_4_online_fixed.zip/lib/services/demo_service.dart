import '../models/plan.dart';

class DemoService {
  Future<List<Plan>> loadPlans({
    required double minSaving,
    required double costPerKm,
  }) async {
    await Future.delayed(const Duration(milliseconds: 350));

    final closest = Plan(
      label: 'Più vicino',
      stores: const ['Supermercato vicino'],
      storeCount: 1,
      productTotal: 50.00,
      travelCost: 0.80,
      effectiveTotal: 50.80,
      distanceKm: 2.0,
      savingVsClosest: 0.0,
      reason: 'È la soluzione di riferimento più vicina.',
      assignment: const {
        'Pasta 1 kg': {'store_name': 'Supermercato vicino', 'price': 2.40},
        'Olio 1 L': {'store_name': 'Supermercato vicino', 'price': 6.90},
        'Rio Mare all\'olio': {'store_name': 'Supermercato vicino', 'price': 4.20},
        'Uva senza semi 1 kg': {'store_name': 'Supermercato vicino', 'price': 3.80},
        'Fiorentina': {'store_name': 'Supermercato vicino', 'price': 32.70},
      },
    );

    final compromise = Plan(
      label: 'Miglior compromesso',
      stores: const ['Supermercato A'],
      storeCount: 1,
      productTotal: 47.90,
      travelCost: 1.60,
      effectiveTotal: 49.50,
      distanceKm: 4.0,
      savingVsClosest: 1.30,
      reason: minSaving <= 1.30
          ? 'Risparmia 1,30 € rispetto alla soluzione vicina e supera la soglia impostata.'
          : 'Costa meno, ma il vantaggio non supera la soglia minima impostata.',
      assignment: const {
        'Pasta 1 kg': {'store_name': 'Supermercato A', 'price': 1.90},
        'Olio 1 L': {'store_name': 'Supermercato A', 'price': 5.90},
        'Rio Mare all\'olio': {'store_name': 'Supermercato A', 'price': 3.99},
        'Uva senza semi 1 kg': {'store_name': 'Supermercato A', 'price': 3.10},
        'Fiorentina': {'store_name': 'Supermercato A', 'price': 33.01},
      },
    );

    final maxSaving = Plan(
      label: 'Massimo risparmio',
      stores: const ['Supermercato B', 'Supermercato C'],
      storeCount: 2,
      productTotal: 44.20,
      travelCost: 6.40,
      effectiveTotal: 50.60,
      distanceKm: 16.0,
      savingVsClosest: 0.20,
      reason: 'Il prezzo dei prodotti è il più basso, ma il costo del viaggio riduce quasi tutto il vantaggio.',
      assignment: const {
        'Pasta 1 kg': {'store_name': 'Supermercato B', 'price': 1.60},
        'Olio 1 L': {'store_name': 'Supermercato B', 'price': 5.20},
        'Rio Mare all\'olio': {'store_name': 'Supermercato C', 'price': 3.59},
        'Uva senza semi 1 kg': {'store_name': 'Supermercato C', 'price': 2.98},
        'Fiorentina': {'store_name': 'Supermercato B', 'price': 30.83},
      },
    );

    final single = Plan(
      label: 'Un solo supermercato',
      stores: const ['Supermercato D'],
      storeCount: 1,
      productTotal: 48.70,
      travelCost: 1.20,
      effectiveTotal: 49.90,
      distanceKm: 3.0,
      savingVsClosest: 0.90,
      reason: 'Buon equilibrio: fai tutta la spesa in un solo punto vendita.',
      assignment: const {
        'Pasta 1 kg': {'store_name': 'Supermercato D', 'price': 2.10},
        'Olio 1 L': {'store_name': 'Supermercato D', 'price': 6.10},
        'Rio Mare all\'olio': {'store_name': 'Supermercato D', 'price': 4.00},
        'Uva senza semi 1 kg': {'store_name': 'Supermercato D', 'price': 3.40},
        'Fiorentina': {'store_name': 'Supermercato D', 'price': 33.10},
      },
    );

    return [compromise, closest, maxSaving, single];
  }
}
