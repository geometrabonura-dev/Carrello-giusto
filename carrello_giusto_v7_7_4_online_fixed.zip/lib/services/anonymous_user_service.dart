
import 'dart:math';
import 'package:shared_preferences/shared_preferences.dart';

class AnonymousUserService {
  static const _key = 'anonymous_user_id';

  Future<String> getOrCreate() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_key);
    if (existing != null && existing.isNotEmpty) {
      return existing;
    }

    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    final id = 'anon_${bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join()}';

    await prefs.setString(_key, id);
    return id;
  }
}
