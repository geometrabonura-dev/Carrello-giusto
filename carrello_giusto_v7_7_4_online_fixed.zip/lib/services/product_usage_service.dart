import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/catalog_product.dart';

class ProductUsageService {
  static const _key = 'frequent_products_v1';

  Future<void> record(CatalogProduct product) async {
    final prefs = await SharedPreferences.getInstance();
    final data = _decode(prefs.getString(_key));
    final id = product.productKey;
    final old = Map<String, dynamic>.from(data[id] ?? const {});
    data[id] = {
      'productKey': product.productKey,
      'name': product.name,
      'brand': product.brand,
      'unit': product.unit,
      'defaultQuantity': product.defaultQuantity,
      'strictBrand': product.strictBrand,
      'allowFractionalQuantity': product.allowFractionalQuantity,
      'count': (old['count'] as int? ?? 0) + 1,
    };
    await prefs.setString(_key, jsonEncode(data));
  }

  Future<List<CatalogProduct>> frequent({int limit = 3}) async {
    final prefs = await SharedPreferences.getInstance();
    final data = _decode(prefs.getString(_key));
    final rows = data.values.map((e) => Map<String, dynamic>.from(e)).toList()
      ..sort((a, b) => (b['count'] as int? ?? 0).compareTo(a['count'] as int? ?? 0));
    return rows.take(limit).map((m) => CatalogProduct(
      productKey: m['productKey'] as String,
      name: m['name'] as String,
      brand: m['brand'] as String?,
      unit: m['unit'] as String? ?? 'pezzo',
      defaultQuantity: (m['defaultQuantity'] as num?)?.toDouble() ?? 1,
      strictBrand: m['strictBrand'] == true,
      allowFractionalQuantity: m['allowFractionalQuantity'] == true,
    )).toList();
  }

  Map<String, dynamic> _decode(String? raw) {
    if (raw == null || raw.isEmpty) return {};
    try { return Map<String, dynamic>.from(jsonDecode(raw)); } catch (_) { return {}; }
  }
}
