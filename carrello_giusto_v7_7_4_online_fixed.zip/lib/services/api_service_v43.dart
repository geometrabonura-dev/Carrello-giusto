
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../models/optimization_result.dart';
import '../models/shopping_item.dart';
import 'retry_policy.dart';

class ApiServiceV43 {
  final String baseUrl;
  final http.Client client;
  final RetryPolicy retryPolicy;

  ApiServiceV43({
    this.baseUrl = 'https://carrello-giusto.onrender.com',
    http.Client? client,
    this.retryPolicy = const RetryPolicy(),
  }) : client = client ?? http.Client();

  Future<OptimizationResult> optimize({
    required List<ShoppingItem> items,
    required Map<String, double> origin,
    required String userId,
    required String strategy,
    required double radiusKm,
    required String travelProfile,
    required double minSavingToTravel,
  }) async {
    final response = await retryPolicy.run(() {
      return client
          .post(
            Uri.parse('$baseUrl/v3/cart/optimize'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'items': items.map((e) => e.toApiJson()).toList(),
              'origin': origin,
              'user_id': userId,
              'strategy': strategy,
              'radius_km': radiusKm,
              'travel_profile': travelProfile,
              'min_saving_to_travel': minSavingToTravel,
            }),
          )
          .timeout(const Duration(seconds: 8));
    });

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Ottimizzazione fallita (${response.statusCode})');
    }

    return OptimizationResult.fromApi(jsonDecode(response.body));
  }
}
