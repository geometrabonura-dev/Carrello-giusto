
import 'package:shared_preferences/shared_preferences.dart';

class OnboardingService {
  static const _completedKey = 'onboarding_completed';
  static const _strategyKey = 'preferred_strategy';

  Future<bool> isCompleted() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_completedKey) ?? false;
  }

  Future<String?> preferredStrategy() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_strategyKey);
  }

  Future<void> complete(String strategy) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_completedKey, true);
    await prefs.setString(_strategyKey, strategy);
  }

  Future<void> reset() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_completedKey);
    await prefs.remove(_strategyKey);
  }
}
