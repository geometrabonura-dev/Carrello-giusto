
import '../controllers/optimization_controller.dart';
import '../models/app_preferences.dart';
import '../models/optimization_result.dart';
import '../models/shopping_item.dart';
import '../services/app_preferences_service.dart';
import '../services/location_service.dart';

class HomeController {
  final OptimizationController optimizationController;
  final LocationService locationService;
  final AppPreferencesService preferencesService;

  HomeController({
    OptimizationController? optimizationController,
    LocationService? locationService,
    AppPreferencesService? preferencesService,
  })  : optimizationController = optimizationController ?? OptimizationController(),
        locationService = locationService ?? LocationService(),
        preferencesService = preferencesService ?? AppPreferencesService();

  Future<AppPreferences> preferences() => preferencesService.loadLocal();

  Future<OptimizationResult> optimize({
    required List<ShoppingItem> items,
    required String userId,
    required AppPreferences preferences,
    double? budgetCap,
  }) async {
    final position = await locationService.getCurrentPosition();
    return optimizationController.run(
      items: items,
      origin: {
        'latitude': position.latitude,
        'longitude': position.longitude,
      },
      userId: userId,
      strategy: preferences.strategy,
      radiusKm: preferences.radiusKm,
      travelProfile: preferences.travelProfile,
      minSavingToTravel: preferences.minSavingToTravel,
      maxStores: preferences.maxStores,
      budgetCap: budgetCap,
    );
  }
}
