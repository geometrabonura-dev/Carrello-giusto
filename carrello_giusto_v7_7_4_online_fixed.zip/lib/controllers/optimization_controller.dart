
import '../models/optimization_result.dart';
import '../models/shopping_item.dart';
import '../services/api_service_v49.dart';
import '../services/demo_result_service.dart';
import '../services/api_error_policy_v60.dart';

class OptimizationController {
  final ApiServiceV49 api;
  final DemoResultService demo;

  OptimizationController({
    ApiServiceV49? api,
    DemoResultService? demo,
  })  : api = api ?? ApiServiceV49(),
        demo = demo ?? DemoResultService();

  Future<OptimizationResult> run({
    required List<ShoppingItem> items,
    required Map<String, double> origin,
    required String userId,
    required String strategy,
    required double radiusKm,
    required String travelProfile,
    required double minSavingToTravel,
    required int maxStores,
    double? budgetCap,
  }) async {
    try {
      return await api.optimize(
        items: items,
        origin: origin,
        userId: userId,
        strategy: strategy,
        radiusKm: radiusKm,
        travelProfile: travelProfile,
        minSavingToTravel: minSavingToTravel,
        maxStores: maxStores,
        budgetCap: budgetCap,
      );
    } on ApiException catch (error) {
      if (ApiErrorPolicyV60.shouldFallbackToDemo(
        statusCode: error.statusCode,
        code: error.code,
      )) {
        return demo.build(
          fallbackReason: error.code,
        );
      }
      rethrow;
    } catch (error) {
      throw ApiException(
        code: 'unexpected_error',
        message: error.toString(),
      );
    }
  }
}
