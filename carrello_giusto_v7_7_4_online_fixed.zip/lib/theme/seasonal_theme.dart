import 'package:flutter/material.dart';

enum AppSeason { spring, summer, autumn, winter }

class SeasonalTheme {
  static AppSeason seasonFor(DateTime date) {
    final m = date.month;
    if (m >= 3 && m <= 5) return AppSeason.spring;
    if (m >= 6 && m <= 8) return AppSeason.summer;
    if (m >= 9 && m <= 11) return AppSeason.autumn;
    return AppSeason.winter;
  }

  static ThemeData current() => forSeason(seasonFor(DateTime.now()));

  static ThemeData forSeason(AppSeason season) {
    final (seed, surface) = switch (season) {
      AppSeason.spring => (const Color(0xFF16A05D), const Color(0xFFFFF8F5)),
      AppSeason.summer => (const Color(0xFF008C95), const Color(0xFFFFFBEF)),
      AppSeason.autumn => (const Color(0xFF178B4C), const Color(0xFFFFF8EF)),
      AppSeason.winter => (const Color(0xFF176B78), const Color(0xFFF5FAFB)),
    };
    final scheme = ColorScheme.fromSeed(seedColor: seed, brightness: Brightness.light).copyWith(surface: surface);
    return ThemeData(
      useMaterial3: true,
      colorScheme: scheme,
      scaffoldBackgroundColor: surface,
      appBarTheme: AppBarTheme(backgroundColor: surface, surfaceTintColor: Colors.transparent, titleTextStyle: const TextStyle(color: Color(0xFF10233D), fontSize: 24, fontWeight: FontWeight.w900)),
      cardTheme: CardThemeData(margin: const EdgeInsets.symmetric(vertical: 5), elevation: 1.5, surfaceTintColor: Colors.transparent, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
      inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: scheme.surfaceContainerLowest, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),
      filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)), textStyle: const TextStyle(fontWeight: FontWeight.w800))),
    );
  }
}
