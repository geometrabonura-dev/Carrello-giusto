
import 'package:flutter/material.dart';
import '../models/optimization_result.dart';

class PlanTradeoffCard extends StatelessWidget {
  final OptimizationPlan plan;
  final OptimizationPlan? maxSavingPlan;
  final OptimizationPlan? closestPlan;

  const PlanTradeoffCard({
    super.key,
    required this.plan,
    required this.maxSavingPlan,
    required this.closestPlan,
  });

  String _money(double value) => '€${value.toStringAsFixed(2)}';

  @override
  Widget build(BuildContext context) {
    final vsCheapest = maxSavingPlan == null
        ? null
        : plan.productTotal - maxSavingPlan!.productTotal;
    final vsClosestDistance = closestPlan == null
        ? null
        : plan.distanceKm - closestPlan!.distanceKm;

    final messages = <String>[
      '${plan.storesCount} supermercato${plan.storesCount == 1 ? '' : 'i'}',
      'Totale effettivo ${_money(plan.effectiveTotal)}',
    ];

    if (vsCheapest != null && vsCheapest > 0.01) {
      messages.add(
        '${_money(vsCheapest)} in più rispetto al prezzo prodotti minimo',
      );
    }
    if (plan.savingVsClosest > 0.01) {
      messages.add(
        'Risparmi ${_money(plan.savingVsClosest)} rispetto al piano più vicino',
      );
    }
    if (vsClosestDistance != null && vsClosestDistance > 0.1) {
      messages.add(
        '${vsClosestDistance.toStringAsFixed(1)} km in più rispetto al piano più vicino',
      );
    }
    if (plan.storePenalty > 0.01) {
      messages.add(
        'Penalità comodità ${_money(plan.storePenalty)}',
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Perché conviene',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ...messages.map(
              (m) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('• '),
                    Expanded(child: Text(m)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
