import 'package:flutter/material.dart';
import '../models/plan.dart';

class PlanCard extends StatelessWidget {
  final Plan plan;
  final bool highlighted;

  const PlanCard({
    super.key,
    required this.plan,
    this.highlighted = false,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: highlighted ? 4 : 1,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    plan.label,
                    style: Theme.of(context).textTheme.titleLarge,
                  ),
                ),
                if (highlighted)
                  const Chip(label: Text('Consigliato')),
              ],
            ),
            const SizedBox(height: 8),
            Text(plan.stores.join(' + ')),
            const SizedBox(height: 12),
            Wrap(
              spacing: 16,
              runSpacing: 8,
              children: [
                Text('Prodotti €${plan.productTotal.toStringAsFixed(2)}'),
                Text('Viaggio €${plan.travelCost.toStringAsFixed(2)}'),
                Text('Totale €${plan.effectiveTotal.toStringAsFixed(2)}'),
                Text('${plan.distanceKm.toStringAsFixed(1)} km'),
                Text('${plan.storeCount} supermercato${plan.storeCount == 1 ? '' : 'i'}'),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              plan.reason,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const Divider(height: 28),
            Text(
              'Cosa comprare',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            ...plan.assignment.entries.map(
              (entry) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  children: [
                    Expanded(child: Text(entry.key)),
                    Text(entry.value['store_name']?.toString() ?? ''),
                    const SizedBox(width: 8),
                    Text('€${(entry.value['price'] as num).toStringAsFixed(2)}'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
