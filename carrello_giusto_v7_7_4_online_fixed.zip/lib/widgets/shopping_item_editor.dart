
import 'package:flutter/material.dart';
import '../models/shopping_item.dart';

class ShoppingItemEditor extends StatelessWidget {
  final ShoppingItem item;
  final ValueChanged<ShoppingItem> onChanged;
  final VoidCallback onDelete;

  const ShoppingItemEditor({
    super.key,
    required this.item,
    required this.onChanged,
    required this.onDelete,
  });

  double get _step {
    if (item.unit.toLowerCase() == 'kg' ||
        item.unit.toLowerCase() == 'l' ||
        item.unit.toLowerCase() == 'litro') {
      return 0.25;
    }
    return 1.0;
  }

  String _formatQuantity(double value) {
    if ((value - value.round()).abs() < 0.001) {
      return value.toStringAsFixed(0);
    }
    return value.toStringAsFixed(2)
        .replaceFirst(RegExp(r'0+$'), '')
        .replaceFirst(RegExp(r'\.$'), '');
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    item.label,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
            Row(
              children: [
                IconButton(
                  onPressed: item.quantity <= _step
                      ? null
                      : () => onChanged(
                            item.copyWith(
                              quantity:
                                  double.parse((item.quantity - _step).toStringAsFixed(2)),
                            ),
                          ),
                  icon: const Icon(Icons.remove_circle_outline),
                ),
                Text('${_formatQuantity(item.quantity)} ${item.unit}'),
                IconButton(
                  onPressed: () => onChanged(
                    item.copyWith(
                      quantity:
                          double.parse((item.quantity + _step).toStringAsFixed(2)),
                    ),
                  ),
                  icon: const Icon(Icons.add_circle_outline),
                ),
                const Spacer(),
                Flexible(
                  child: Text(
                    item.preferredBrand == null
                        ? 'Nessuna marca preferita'
                        : 'Marca: ${item.preferredBrand}',
                    textAlign: TextAlign.end,
                  ),
                ),
              ],
            ),
            SwitchListTile(
              dense: true,
              visualDensity: VisualDensity.compact,
              contentPadding: EdgeInsets.zero,
              title: const Text('Accetta equivalenti'),
              subtitle: Text(
                item.allowEquivalents
                    ? 'Può scegliere un prodotto equivalente più conveniente.'
                    : 'Mantiene il prodotto/marca richiesta.',
              ),
              value: item.allowEquivalents,
              onChanged: (v) =>
                  onChanged(item.copyWith(allowEquivalents: v)),
            ),
          ],
        ),
      ),
    );
  }
}
