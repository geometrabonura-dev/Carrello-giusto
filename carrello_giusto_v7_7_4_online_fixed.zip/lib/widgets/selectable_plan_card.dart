
import 'package:flutter/material.dart';

class SelectablePlanCard extends StatelessWidget {
  final String title;
  final String reason;
  final double productTotal;
  final double travelCost;
  final double timeCost;
  final double effectiveTotal;
  final double? distanceKm;
  final double? durationMinutes;
  final int storesCount;
  final bool selected;
  final VoidCallback onSelect;

  const SelectablePlanCard({
    super.key,
    required this.title,
    required this.reason,
    required this.productTotal,
    required this.travelCost,
    required this.timeCost,
    required this.effectiveTotal,
    required this.storesCount,
    required this.selected,
    required this.onSelect,
    this.distanceKm,
    this.durationMinutes,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                if (selected) const Icon(Icons.check_circle),
              ],
            ),
            const SizedBox(height: 8),
            Text(reason),
            const SizedBox(height: 12),
            Text('Prodotti: €${productTotal.toStringAsFixed(2)}'),
            Text('Viaggio: €${travelCost.toStringAsFixed(2)}'),
            Text('Tempo: €${timeCost.toStringAsFixed(2)}'),
            Text(
              'Totale effettivo: €${effectiveTotal.toStringAsFixed(2)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Text('$storesCount supermercato/i'),
            if (distanceKm != null)
              Text('Distanza: ${distanceKm!.toStringAsFixed(1)} km'),
            if (durationMinutes != null)
              Text('Durata: ${durationMinutes!.toStringAsFixed(0)} min'),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.tonal(
                onPressed: onSelect,
                child: Text(selected ? 'Piano scelto' : 'Scegli questo piano'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
