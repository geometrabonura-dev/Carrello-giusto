import 'package:flutter/material.dart';

class ResultPlanCard extends StatelessWidget {
  final String title;
  final String reason;
  final double productTotal;
  final double travelCost;
  final double timeCost;
  final double effectiveTotal;
  final double? distanceKm;
  final double? durationMinutes;
  final int storesCount;
  final bool recommended;
  final bool selected;
  final VoidCallback onSelect;

  const ResultPlanCard({
    super.key,
    required this.title,
    required this.reason,
    required this.productTotal,
    required this.travelCost,
    required this.timeCost,
    required this.effectiveTotal,
    required this.storesCount,
    required this.recommended,
    required this.selected,
    required this.onSelect,
    this.distanceKm,
    this.durationMinutes,
  });

  Widget _metric(IconData icon, String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .11),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 21),
        const SizedBox(width: 8),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: const TextStyle(fontSize: 12)),
          Text(value, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ])),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final accent = recommended ? const Color(0xFF079447) : const Color(0xFF1565D8);
    return Card(
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
        side: BorderSide(color: accent.withValues(alpha: .30)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(20)),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(recommended ? Icons.star_rounded : Icons.location_on_rounded, color: Colors.white, size: 19),
                const SizedBox(width: 5),
                Text(title.toUpperCase(), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
              ]),
            ),
            const Spacer(),
            if (selected) Icon(Icons.check_circle, color: accent, size: 28),
          ]),
          const SizedBox(height: 10),
          Text(reason, style: TextStyle(color: Theme.of(context).colorScheme.onSurfaceVariant)),
          const SizedBox(height: 12),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 2.35,
            mainAxisSpacing: 8,
            crossAxisSpacing: 8,
            children: [
              _metric(Icons.shopping_cart_rounded, 'Prodotti', '€${productTotal.toStringAsFixed(2)}', const Color(0xFF0A9D4A)),
              _metric(Icons.directions_car_rounded, 'Viaggio', '€${travelCost.toStringAsFixed(2)}', const Color(0xFF1976D2)),
              _metric(Icons.schedule_rounded, 'Tempo', '€${timeCost.toStringAsFixed(2)}', const Color(0xFFF57C00)),
              _metric(Icons.pin_drop_rounded, 'Distanza', '${(distanceKm ?? 0).toStringAsFixed(1)} km', const Color(0xFF7048E8)),
              _metric(Icons.timer_rounded, 'Durata', '${(durationMinutes ?? 0).toStringAsFixed(0)} min', const Color(0xFFE91E78)),
              _metric(Icons.storefront_rounded, 'Supermercati', '$storesCount', const Color(0xFF00897B)),
            ],
          ),
          const SizedBox(height: 12),
          Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Totale effettivo'),
              Text('€${effectiveTotal.toStringAsFixed(2)}', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: accent)),
            ])),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: accent, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14)),
              onPressed: onSelect,
              icon: Icon(selected ? Icons.visibility_rounded : Icons.arrow_forward_rounded),
              label: Text(selected ? 'Apri piano' : 'Scegli'),
            ),
          ]),
        ]),
      ),
    );
  }
}
