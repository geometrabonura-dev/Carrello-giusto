
import 'package:flutter/material.dart';
import 'screens/main_shell.dart';
import 'screens/onboarding_screen.dart';
import 'services/onboarding_service.dart';
import 'services/anonymous_user_service.dart';
import 'theme/seasonal_theme.dart';

class SpesaSmartApp extends StatefulWidget {
  const SpesaSmartApp({super.key});

  @override
  State<SpesaSmartApp> createState() => _SpesaSmartAppState();
}

class _SpesaSmartAppState extends State<SpesaSmartApp> {
  bool? _onboardingCompleted;
  String? _userId;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final userId = await AnonymousUserService().getOrCreate();
    final completed = await OnboardingService().isCompleted();

    if (!mounted) return;
    setState(() {
      _userId = userId;
      _onboardingCompleted = completed;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_onboardingCompleted == null || _userId == null) {
      return const MaterialApp(
        home: Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }

    return MaterialApp(
      title: 'CarrelloGiusto',
      theme: SeasonalTheme.current(),
      home: _onboardingCompleted!
          ? MainShell(userId: _userId!)
          : OnboardingScreen(
              userId: _userId!,
              onCompleted: () => setState(() => _onboardingCompleted = true),
            ),
    );
  }
}
