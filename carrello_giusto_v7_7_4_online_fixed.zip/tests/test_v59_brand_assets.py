from pathlib import Path

def test_brand_asset_exists():
    p = Path("assets/brand/carrellogiusto_mark.svg")
    assert p.exists()
    text = p.read_text()
    assert "<svg" in text
    assert "path" in text

def test_store_metadata_exist():
    assert Path("store_metadata/google_play_it.md").exists()
    assert Path("store_metadata/app_store_it.md").exists()
    assert Path("store_metadata/privacy_checklist.md").exists()

def test_v59_version():
    text = Path("backend/app/main.py").read_text()
    assert 'version="6.0.0"' in text

def test_about_screen_if_flutter_present():
    if Path("lib").exists():
        text = Path("lib/screens/about_screen.dart").read_text()
        assert "CarrelloGiusto" in text
        assert "La spesa che conviene davvero." in text
