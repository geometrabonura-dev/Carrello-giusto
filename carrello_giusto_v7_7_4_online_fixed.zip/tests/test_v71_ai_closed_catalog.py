import json
import pytest
from backend.app.substitution_ai_candidate_v71 import suggest_from_closed_catalog_v71

class Fake:
    def __init__(self, payload):
        self.payload = payload
    def complete(self, *, system, user):
        return json.dumps(self.payload)

def test_ai_can_only_pick_closed_candidate():
    out = suggest_from_closed_catalog_v71(
        llm_client=Fake({
            "alternative_product_key":"b",
            "reason":"simile",
            "confidence":0.9,
        }),
        source={"product_key":"a"},
        candidates=[{"product_key":"b"}],
    )
    assert out["alternative_product_key"] == "b"

def test_ai_cannot_invent_product_key():
    with pytest.raises(ValueError):
        suggest_from_closed_catalog_v71(
            llm_client=Fake({
                "alternative_product_key":"invented",
                "reason":"x",
                "confidence":0.9,
            }),
            source={"product_key":"a"},
            candidates=[{"product_key":"b"}],
        )
