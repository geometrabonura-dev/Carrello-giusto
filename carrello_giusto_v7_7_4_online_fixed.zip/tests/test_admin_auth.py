
from fastapi.testclient import TestClient
import os

os.environ["ADMIN_TOKEN"] = "test-token"

from backend.app.main import app

client = TestClient(app)

def test_admin_requires_token():
    response = client.get("/admin")
    assert response.status_code == 401
