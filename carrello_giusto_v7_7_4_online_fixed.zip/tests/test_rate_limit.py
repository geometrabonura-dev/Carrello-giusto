
from backend.app.rate_limit import MAX_REQUESTS, WINDOW_SECONDS

def test_rate_limit_config():
    assert MAX_REQUESTS > 0
    assert WINDOW_SECONDS > 0
