
from backend.app.plan_pruning_v60 import lower_bound_effective_cost, should_prune

def test_prune_when_lower_bound_cannot_beat_incumbent():
    lb = lower_bound_effective_cost(
        product_total_lb=50,
        travel_cost_lb=3,
        time_cost_lb=2,
    )
    assert lb == 55
    assert should_prune(lower_bound=55, incumbent_effective_total=54.99)
    assert not should_prune(lower_bound=53, incumbent_effective_total=54.99)
