from pathlib import Path

def test_chat_api_uses_structured_state_and_reducer():
    text = Path("backend/app/ai_cart_chat_api_v68.py").read_text()
    assert "current_state" in text
    assert "apply_actions_v68" in text
    assert 'task="update_cart_conversation"' in text

def test_prompt_forbids_commercial_hallucination():
    text = Path("backend/app/ai_cart_conversation_v68.py").read_text()
    assert "Non inventare prezzi" in text
    assert "product_key" in text
