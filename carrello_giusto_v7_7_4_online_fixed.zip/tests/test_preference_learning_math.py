
from backend.app.preference_learning import _renormalize

def test_weights_renormalize_to_one():
    a, b, c = _renormalize(0.6, 0.3, 0.2)
    assert round(a + b + c, 8) == 1.0
