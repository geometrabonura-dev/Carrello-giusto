
from backend.app.review_state_actions_v57 import ReviewStateActionsV57

class FakeRepo:
    def __init__(self):
        self.reopened = None
    def reopen_review(self, **kwargs):
        self.reopened = kwargs

class FakeAudit:
    def __init__(self):
        self.logs = []
    def log(self, **kwargs):
        self.logs.append(kwargs)
        return "a1"

def test_reopen_is_audited():
    repo = FakeRepo()
    audit = FakeAudit()
    svc = ReviewStateActionsV57(repo, audit)
    result = svc.reopen(
        review_id="r1",
        source_key="conad_official",
        actor="admin",
        reason="nuove informazioni",
    )
    assert result["status"] == "pending"
    assert repo.reopened["review_id"] == "r1"
    assert audit.logs[0]["action"] == "reopen_review"
