
from backend.app.health import detailed_health

def test_health_shape():
    data = detailed_health()
    assert "status" in data
    assert "database" in data
    assert "repository" in data
    assert "components" in data
