from pathlib import Path

def test_ai_screen_has_candidate_picker_and_learning():
    text = Path("lib/screens/ai_cart_screen.dart").read_text()
    assert "_chooseCandidate" in text
    assert "confirmMapping" in text
    assert "La scelta verrà ricordata" in text
    assert "'Scegli'" in text

def test_home_passes_anonymous_user_id():
    text = Path("lib/screens/home_screen.dart").read_text()
    assert "AiCartScreen(userId: widget.userId)" in text
