from pathlib import Path

def test_missing_items_message_is_explicit():
    text = Path("lib/services/api_error_policy_v60.dart").read_text()
    assert "Non trovo offerte utilizzabili per" in text
    assert "no_stores_in_radius" in text
    assert "no_complete_plan" in text

def test_demo_is_labeled_and_budget_constructor_fixed():
    text = Path("lib/services/demo_result_service.dart").read_text()
    assert "fallbackReason" in text
    assert "Dati demo usati solo come fallback temporaneo" in text
    assert "budgetAnalysis: null" in text
