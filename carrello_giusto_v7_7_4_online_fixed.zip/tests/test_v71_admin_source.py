from pathlib import Path

def test_admin_api_is_protected():
    text = Path("backend/app/substitution_admin_api_v71.py").read_text()
    assert "dependencies=[Depends(require_admin)]" in text

def test_ai_suggestion_is_pending_not_approved():
    text = Path("backend/app/substitution_admin_api_v71.py").read_text()
    assert 'review_status": "pending"' in text
    assert "richiede approvazione admin" in text

def test_console_has_approve_reject_compatibility():
    text = Path("backend/app/substitution_console_v71.py").read_text()
    assert "Approva" in text
    assert "Rifiuta" in text
    assert "Compatibilità" in text
