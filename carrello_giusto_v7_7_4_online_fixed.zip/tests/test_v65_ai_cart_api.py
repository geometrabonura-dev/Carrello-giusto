from backend.app.ai_cart_api_v65 import _fallback_parse

def test_fallback_never_invents_product_keys():
    result = _fallback_parse("mele, tonno Rio Mare")
    assert result["requires_confirmation"] is True
    assert result["used_ai"] is False
    assert len(result["items"]) == 2
    assert all(item["product_key"] is None for item in result["items"])

def test_fallback_preserves_labels():
    result = _fallback_parse("mele, tonno Rio Mare")
    labels = [x["label"] for x in result["items"]]
    assert labels == ["mele", "tonno Rio Mare"]
