from backend.app.ai_provider_openai_v66 import OpenAIResponsesClientV66

def test_provider_not_configured_without_key():
    client = OpenAIResponsesClientV66(api_key="")
    assert client.configured is False

def test_provider_defaults_model():
    client = OpenAIResponsesClientV66(api_key="test-key")
    assert client.model
    assert client.configured is True
