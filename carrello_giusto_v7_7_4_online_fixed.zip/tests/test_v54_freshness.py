
from datetime import datetime, timedelta, timezone
from backend.app.freshness_policy_v54 import evaluate_freshness

NOW = datetime(2026, 9, 12, 12, 0, tzinfo=timezone.utc)

def test_expired_offer_is_not_usable():
    d = evaluate_freshness(
        valid_to=NOW - timedelta(minutes=1),
        source_checked_at=NOW,
        now=NOW,
    )
    assert d.status == "expired"
    assert d.usable is False

def test_future_offer_is_not_usable():
    d = evaluate_freshness(
        valid_from=NOW + timedelta(hours=1),
        source_checked_at=NOW,
        now=NOW,
    )
    assert d.status == "not_yet_valid"
    assert d.usable is False

def test_stale_offer_is_not_usable():
    d = evaluate_freshness(
        source_checked_at=NOW - timedelta(hours=49),
        max_age_hours=48,
        now=NOW,
    )
    assert d.status == "stale"
    assert d.usable is False

def test_fresh_offer_is_usable():
    d = evaluate_freshness(
        valid_from=NOW - timedelta(days=1),
        valid_to=NOW + timedelta(days=1),
        source_checked_at=NOW - timedelta(hours=2),
        now=NOW,
    )
    assert d.status == "fresh"
    assert d.usable is True
