
from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)

def test_liveness():
    r = client.get("/health/live")
    assert r.status_code == 200
    assert r.json()["status"] == "alive"

def test_readiness_shape():
    r = client.get("/health/ready")
    assert r.status_code == 200
    data = r.json()
    assert "ready" in data
    assert "database" in data
