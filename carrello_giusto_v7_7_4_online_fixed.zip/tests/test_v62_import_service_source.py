from pathlib import Path

def test_import_service_uses_safe_parsers():
    text = Path("backend/app/feed_import_service_v52.py").read_text()
    assert "parse_bool" in text
    assert "parse_decimal" in text
    assert "parse_datetime_iso" in text
    assert 'loyalty_required=bool(' not in text
    assert 'price = float(raw.get("price")' not in text
