
from fastapi.testclient import TestClient
from backend.app.main import app

client = TestClient(app)

def test_metrics_endpoint():
    response = client.get("/metrics")
    assert response.status_code == 200
    assert "spesa_smart_http_requests_total" in response.text
