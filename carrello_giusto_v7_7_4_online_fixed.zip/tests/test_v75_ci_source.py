from pathlib import Path

def test_ci_has_flutter_checks():
    text = Path(".github/workflows/ci.yml").read_text()
    assert "subosito/flutter-action@v2" in text
    assert "flutter pub get" in text
    assert "flutter analyze" in text
    assert "flutter test" in text

def test_ci_has_backend_checks():
    text = Path(".github/workflows/ci.yml").read_text()
    assert "actions/setup-python@v5" in text
    assert "python -m compileall -q app" in text
    assert "python -m pytest -q" in text

def test_local_validation_script_exists():
    text = Path("tool/validate_project.sh").read_text()
    assert "flutter analyze" in text
    assert "flutter test" in text
    assert "python -m pytest -q" in text
