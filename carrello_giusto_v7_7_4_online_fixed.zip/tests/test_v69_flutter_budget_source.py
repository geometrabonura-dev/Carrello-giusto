from pathlib import Path

def test_home_passes_budget_to_results():
    text = Path("lib/screens/home_screen.dart").read_text()
    assert "double? _budgetCap;" in text
    assert "_budgetCap = result.budgetCap" in text
    assert "budgetCap: _budgetCap" in text

def test_results_show_budget_gap_and_alternative():
    text = Path("lib/screens/results_screen.dart").read_text()
    assert "BudgetEvaluatorV69" in text
    assert "supera il limite" in text
    assert "Esiste però un piano ammesso che rientra nel budget" in text
    assert "Nessun piano ammesso rientra nel budget" in text
