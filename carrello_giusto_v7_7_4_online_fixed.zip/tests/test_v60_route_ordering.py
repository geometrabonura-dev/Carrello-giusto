
from backend.app.route_ordering_v60 import scalable_stop_order, route_cost

def test_exact_small_route():
    matrix = [
        [0,1,5,2],
        [1,0,1,4],
        [5,1,0,1],
        [2,4,1,0],
    ]
    order = scalable_stop_order(matrix, [1,2,3])
    assert set(order) == {1,2,3}
    assert route_cost(order, matrix) <= 7

def test_scalable_six_stops():
    n = 7
    matrix = [[0 if i == j else abs(i-j)+1 for j in range(n)] for i in range(n)]
    order = scalable_stop_order(matrix, [1,2,3,4,5,6])
    assert len(order) == 6
    assert set(order) == {1,2,3,4,5,6}
