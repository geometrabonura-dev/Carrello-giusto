
import os
import pytest
from decimal import Decimal
from backend.app.db import get_conn
from backend.app.import_pipeline import ImportPipeline, IncomingOffer
from backend.app.maintenance import expire_old_offers
from backend.app.quality_policy import QualityPolicy

pytestmark = pytest.mark.integration

def db_available():
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("SELECT 1")
                cur.fetchone()
        return True
    except Exception:
        return False

@pytest.mark.skipif(not db_available(), reason="PostgreSQL non disponibile")
def test_quality_policy_integration():
    policy = QualityPolicy()
    d = policy.decide(0.95, 1.0)
    assert d.accepted
    assert d.verified
    assert d.status == "verified"

@pytest.mark.skipif(not db_available(), reason="PostgreSQL non disponibile")
def test_database_roundtrip():
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT COUNT(*) FROM products")
            count = cur.fetchone()[0]
    assert count >= 0
