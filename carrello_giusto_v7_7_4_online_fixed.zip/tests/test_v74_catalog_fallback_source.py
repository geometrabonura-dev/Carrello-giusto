from pathlib import Path

def test_catalog_search_accepts_initial_query():
    text = Path("lib/screens/catalog_search_screen.dart").read_text()
    assert "initialQuery" in text
    assert "_controller.text = q" in text
    assert "addPostFrameCallback" in text

def test_ai_screen_has_full_catalog_fallback():
    text = Path("lib/screens/ai_cart_screen.dart").read_text()
    assert "_searchFullCatalog" in text
    assert "Cerca nel catalogo" in text
    assert "Vedi altri risultati" in text
    assert "CatalogSearchScreen(" in text
