from backend.app.substitution_preview_v72 import _normalize_cost

def test_normalizes_price_per_kg():
    assert _normalize_cost(2.5, 500, "g") == 5.0
    assert _normalize_cost(4.0, 1, "kg") == 4.0

def test_normalizes_price_per_liter():
    assert _normalize_cost(1.5, 500, "ml") == 3.0

def test_unknown_unit_not_compared():
    assert _normalize_cost(2.0, 1, "box") is None
