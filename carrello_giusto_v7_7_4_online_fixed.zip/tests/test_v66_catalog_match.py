from types import SimpleNamespace
from backend.app.catalog_match_v66 import resolve_catalog_item_v66

class Repo:
    def __init__(self, rows):
        self.rows = rows
    def search(self, query, limit=8):
        return self.rows

def row(key, name, brand=None, unit="pack"):
    return SimpleNamespace(
        product_key=key,
        name=name,
        brand=brand,
        unit=unit,
    )

def test_clear_exact_match_auto_resolves():
    repo = Repo([
        row("pasta-1kg", "Pasta", None, "kg"),
        row("passata", "Passata di pomodoro", None, "pack"),
    ])
    result = resolve_catalog_item_v66(label="Pasta", repo=repo)
    assert result.status == "auto_resolved"
    assert result.product_key == "pasta-1kg"

def test_close_candidates_require_confirmation():
    repo = Repo([
        row("t1", "Tonno Rio Mare 80 g", "Rio Mare"),
        row("t2", "Tonno Rio Mare 160 g", "Rio Mare"),
    ])
    result = resolve_catalog_item_v66(
        label="Tonno Rio Mare",
        preferred_brand="Rio Mare",
        repo=repo,
    )
    assert result.status == "needs_confirmation"
    assert result.product_key is None
    assert len(result.candidates) == 2
