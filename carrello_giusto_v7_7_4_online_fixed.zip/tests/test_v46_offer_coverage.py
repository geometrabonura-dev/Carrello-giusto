
from types import SimpleNamespace
from backend.app.cart_offer_resolution_v46 import resolve_offer_coverage

class FakeRepo:
    def find_candidates(self, product_key, **kwargs):
        if product_key == "pasta1kg":
            return [SimpleNamespace(
                offer_id="o1",
                store_id="s1",
                store_name="Store",
                product_key="pasta1kg",
                product_name="Pasta",
                brand=None,
                price=2.0,
                regular_price=2.5,
                quantity=1.0,
                unit="kg",
                verified=True,
                source_status="active",
                valid_from=None,
                valid_to=None,
                loyalty_required=False,
            )]
        return []

def test_missing_items_are_explicit():
    coverage = resolve_offer_coverage([
        {
            "product_key": "pasta1kg",
            "name": "Pasta",
            "quantity": 1,
            "unit": "kg",
            "preferred_brand": None,
            "allow_equivalents": True,
            "strict_brand": False,
        },
        {
            "product_key": "fiorentina",
            "name": "Fiorentina",
            "quantity": 1,
            "unit": "piece",
            "preferred_brand": None,
            "allow_equivalents": True,
            "strict_brand": False,
        },
    ], repo=FakeRepo())

    assert len(coverage.covered) == 1
    assert coverage.missing[0]["product_key"] == "fiorentina"
