
from backend.app.request_models_v43 import CartItemV43

def test_structured_cart_item():
    item = CartItemV43(
        product_key="pasta1kg",
        quantity=1,
        unit="kg",
        allow_equivalents=True,
    )
    assert item.product_key == "pasta1kg"
    assert item.quantity == 1
