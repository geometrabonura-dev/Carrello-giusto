
from backend.app.review_service_v53 import (
    product_external_ref,
    store_external_ref,
)

def test_product_ref_prefers_ean():
    assert product_external_ref({
        "ean":"123",
        "product_key":"pasta",
        "product_name":"Pasta",
    }) == "ean:123"

def test_product_ref_uses_product_key():
    assert product_external_ref({
        "product_key":"pasta",
        "product_name":"Pasta",
    }) == "product_key:pasta"

def test_product_ref_falls_back_to_brand_and_name():
    assert product_external_ref({
        "brand":"Rio Mare",
        "product_name":"Tonno",
    }) == "name:rio mare|tonno"

def test_store_ref_normalization():
    assert store_external_ref({"store_external_ref":123}) == "123"
