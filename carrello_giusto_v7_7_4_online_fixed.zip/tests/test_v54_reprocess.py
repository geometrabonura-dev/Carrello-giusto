
from backend.app.raw_reprocess_v54 import RawReprocessServiceV54

class FakeRepo:
    def __init__(self):
        self.saved = []
    def create_run(self, source_key, feed_name=None): return "run1"
    def finish_run(self, run_id, status, metrics): pass
    def store_raw_offer(self, **kwargs): return "raw1"
    def resolve_store(self, *, source_key, external_ref):
        return {"id":"s1","name":"Store"} if external_ref == "store-x" else None
    def upsert_offer(self, **kwargs):
        self.saved.append(kwargs)
        return "o1"

class FakeMatcher:
    def match(self, **kwargs): return None

class FakeReviews:
    def enqueue_store(self, **kwargs): return "rs"
    def enqueue_product(self, **kwargs): return "rp"

class FakeMappings:
    def resolve(self, *, source_key, external_ref):
        if external_ref == "ean:123":
            return {"product_id":"p1","confidence":1.0,"method":"manual_mapping"}
        return None

def test_reprocess_uses_manual_mapping():
    repo = FakeRepo()
    svc = RawReprocessServiceV54(
        import_repository=repo,
        product_matcher=FakeMatcher(),
        review_repository=FakeReviews(),
        product_mapping_repository=FakeMappings(),
    )
    result = svc.reprocess_payloads(
        source_key="esselunga_official",
        payloads=[{
            "store_external_ref":"store-x",
            "ean":"123",
            "product_name":"Pasta",
            "price":1.99,
        }],
    )
    assert result["metrics"]["manual_product_mapping_used"] == 1
    assert result["metrics"]["accepted"] == 1
    assert repo.saved[0]["product_id"] == "p1"
