from pathlib import Path

def test_api_service_throws_typed_functional_errors():
    text = Path("lib/services/api_service_v49.dart").read_text()
    assert "ApiException" in text
    assert "validation_error" in text
    assert "network_error" in text
    assert "timeout" in text

def test_controller_fallback_is_not_catch_all():
    text = Path("lib/controllers/optimization_controller.dart").read_text()
    assert "shouldFallbackToDemo" in text
    assert "} catch (_) {\n      return demo.build();" not in text
    assert "rethrow;" in text

def test_home_shows_api_user_message():
    text = Path("lib/screens/home_screen.dart").read_text()
    assert "on ApiException catch (error)" in text
    assert "_error = error.userMessage();" in text
