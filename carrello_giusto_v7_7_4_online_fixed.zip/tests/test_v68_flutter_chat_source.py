from pathlib import Path

def test_ai_screen_is_conversational():
    text = Path("lib/screens/ai_cart_screen.dart").read_text()
    assert "AiCartChatServiceV68" in text
    assert "_messages" in text
    assert "aggiungi il latte" in text
    assert "preferisco un solo supermercato" in text

def test_home_applies_conversational_preferences():
    text = Path("lib/screens/home_screen.dart").read_text()
    assert "_strategy = result.strategy" in text
    assert "_maxStores = result.maxStores" in text
    assert "_minSaving = result.minSavingToTravel" in text
