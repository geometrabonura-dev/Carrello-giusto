from types import SimpleNamespace
from backend.app.catalog_match_v66 import resolve_catalog_item_v66

class Repo:
    def search(self, query, limit=8):
        raise AssertionError("fuzzy search should not run when learned mapping is valid")
    def resolve_key(self, key):
        if key == "tuna-80":
            return SimpleNamespace(
                product_key="tuna-80",
                name="Tonno Rio Mare 80 g",
                brand="Rio Mare",
                unit="pack",
            )
        return None

class MappingRepo:
    def resolve(self, **kwargs):
        return "tuna-80"

def test_learned_mapping_wins_before_fuzzy_search():
    result = resolve_catalog_item_v66(
        label="tonno rio mare",
        preferred_brand="Rio Mare",
        repo=Repo(),
        user_id="anon-1",
        mapping_repo=MappingRepo(),
    )
    assert result.status == "learned_mapping"
    assert result.product_key == "tuna-80"
    assert result.confidence == 1.0
