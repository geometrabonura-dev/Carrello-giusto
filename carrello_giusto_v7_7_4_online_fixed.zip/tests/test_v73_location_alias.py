from pathlib import Path

def test_location_service_matches_home_controller_contract():
    text = Path("lib/services/location_service.dart").read_text()
    assert "getCurrentPosition()" in text
    home = Path("lib/controllers/home_controller.dart").read_text()
    assert "locationService.getCurrentPosition()" in home
