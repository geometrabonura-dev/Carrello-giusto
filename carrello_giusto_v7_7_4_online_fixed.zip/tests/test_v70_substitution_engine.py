from types import SimpleNamespace
from backend.app.budget_substitution_engine_v70 import (
    suggest_budget_substitutions_v70,
    build_budget_recovery_v70,
)

class Repo:
    def approved_for(self, source):
        if source == "tuna-brand":
            return [SimpleNamespace(
                alternative_product_key="tuna-equivalent",
                relation_type="equivalent",
            )]
        return []

def test_only_approved_real_same_store_alternative_is_suggested():
    recommendation = {
        "assignments": [{
            "product_key":"tuna-brand",
            "product_name":"Tonno Rio Mare",
            "brand":"Rio Mare",
            "store_id":"s1",
            "store_name":"Market",
            "cost":6.50,
        }]
    }
    pricebook = {
        "s1":{
            "store_name":"Market",
            "items":{
                "tuna-equivalent":{
                    "product_key":"tuna-equivalent",
                    "product_name":"Tonno equivalente",
                    "brand":"Altro",
                    "cost":4.10,
                    "verified":True,
                    "loyalty_required":False,
                }
            }
        }
    }
    out=suggest_budget_substitutions_v70(
        recommendation=recommendation,
        pricebook=pricebook,
        substitution_repo=Repo(),
    )
    assert len(out)==1
    assert out[0].saving==2.40
    assert out[0].alternative_verified is True

def test_unpriced_alternative_is_not_invented():
    recommendation={"assignments":[{
        "product_key":"tuna-brand","store_id":"s1","cost":6.50
    }]}
    out=suggest_budget_substitutions_v70(
        recommendation=recommendation,
        pricebook={"s1":{"items":{}}},
        substitution_repo=Repo(),
    )
    assert out==[]

def test_recovery_accumulates_real_savings():
    suggestions=[
        SimpleNamespace(saving=2.4,to_dict=lambda:{"saving":2.4}),
        SimpleNamespace(saving=2.0,to_dict=lambda:{"saving":2.0}),
    ]
    out=build_budget_recovery_v70(
        budget_gap=4.2,
        suggestions=suggestions,
    )
    assert out["can_close_gap"] is True
    assert out["suggested_saving"]==4.4
