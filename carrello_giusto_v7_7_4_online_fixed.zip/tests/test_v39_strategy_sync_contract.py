
from backend.app.strategy_profiles import STRATEGIES

def test_strategy_presets_available_for_client_sync():
    assert set(["max_saving", "balanced", "max_comfort"]).issubset(STRATEGIES.keys())
