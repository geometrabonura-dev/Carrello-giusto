
from backend.app.user_preferences import UserPreferences

def test_defaults():
    p = UserPreferences(user_id="demo")
    assert p.radius_km == 10.0
    assert p.min_saving_to_travel == 3.0
    assert p.max_stores == 3
    assert p.weight_saving == 0.50
