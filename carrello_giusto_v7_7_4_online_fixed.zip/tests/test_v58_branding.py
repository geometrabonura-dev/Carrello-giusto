from pathlib import Path

def test_v58_docs_use_new_brand():
    text = Path("docs/v5.8.md").read_text()
    assert "CarrelloGiusto" in text
    assert "La spesa che conviene davvero." in text

def test_backend_version_bumped():
    text = Path("backend/app/main.py").read_text()
    assert 'version="5.9.0"' in text

def test_flutter_brand_constant_if_flutter_present():
    lib = Path("lib")
    if lib.exists():
        text = Path("lib/config/brand.dart").read_text()
        assert "CarrelloGiusto" in text
        assert "La spesa che conviene davvero." in text
