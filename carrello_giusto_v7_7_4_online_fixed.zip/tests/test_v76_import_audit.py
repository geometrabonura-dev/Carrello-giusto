from pathlib import Path
import re
import yaml

def test_no_missing_relative_dart_imports():
    root = Path(".").resolve()
    missing = []
    for path in root.rglob("*.dart"):
        text = path.read_text(errors="ignore")
        for match in re.finditer(r"import\s+'([^']+)';", text):
            imp = match.group(1)
            if imp.startswith(("dart:", "package:")):
                continue
            if not (path.parent / imp).resolve().exists():
                missing.append((str(path), imp))
    assert missing == []

def test_no_undeclared_external_packages():
    root = Path(".")
    pub = yaml.safe_load((root / "pubspec.yaml").read_text())
    own = pub["name"]
    deps = set((pub.get("dependencies") or {}).keys())
    deps |= set((pub.get("dev_dependencies") or {}).keys())
    used = set()
    for path in root.rglob("*.dart"):
        text = path.read_text(errors="ignore")
        for m in re.finditer(r"import\s+'package:([^/]+)/", text):
            used.add(m.group(1))
    assert sorted(x for x in used - deps if x != own) == []
