
from backend.app.scoring import score_plans

def test_simplicity_can_win():
    plans = [
        {"product_total": 48.0, "duration_minutes": 25, "stores": [1,2], "effective_total": 52.0},
        {"product_total": 49.0, "duration_minutes": 15, "stores": [1], "effective_total": 52.0},
    ]
    ranked = score_plans(
        plans,
        weight_saving=0.2,
        weight_time=0.3,
        weight_simplicity=0.5,
        store_penalty_eur=1.0,
    )
    assert ranked[0]["stores"] == [1]
