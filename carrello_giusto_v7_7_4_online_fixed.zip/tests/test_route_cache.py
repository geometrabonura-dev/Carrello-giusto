
from backend.app.route_cache import RouteCache

def test_cache_roundtrip():
    c = RouteCache(ttl_seconds=60)
    coords = [
        {"latitude": 44.49, "longitude": 11.34},
        {"latitude": 44.50, "longitude": 11.35},
    ]
    c.set(coords, "driving", {"ok": True})
    assert c.get(coords, "driving") == {"ok": True}
