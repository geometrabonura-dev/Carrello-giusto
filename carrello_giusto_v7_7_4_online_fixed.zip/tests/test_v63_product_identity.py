from backend.app.product_identity_v63 import (
    normalize_gtin, normalize_quantity, variant_key
)

def test_gtin_normalization():
    assert normalize_gtin("8001234567890") == "8001234567890"
    assert normalize_gtin("8 001234 567890") == "8001234567890"
    assert normalize_gtin("12345") is None

def test_quantity_normalization():
    assert normalize_quantity(500, "g") == (0.5, "kg")
    assert normalize_quantity(1000, "ml") == (1.0, "l")

def test_variant_keys_differ_by_pack_size():
    a = variant_key(product_key="tuna", brand="Rio Mare", name="Tonno", quantity=80, unit="g")
    b = variant_key(product_key="tuna", brand="Rio Mare", name="Tonno", quantity=160, unit="g")
    assert a != b
