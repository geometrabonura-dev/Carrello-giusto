
from backend.app.strategy_ranker_v48 import rank_eligible_plans

def test_strategy_only_ranks_eligible_input():
    eligible = [
        {
            "plan_key":"closest",
            "product_total":50.0,
            "duration_minutes":10.0,
            "stores_count":1,
            "effective_total":51.0,
        },
        {
            "plan_key":"far_ok",
            "product_total":44.0,
            "duration_minutes":25.0,
            "stores_count":4,
            "effective_total":47.0,
        },
    ]
    best, ranked = rank_eligible_plans(eligible, "max_saving")
    assert best["plan_key"] in {"closest","far_ok"}
    assert len(ranked) == 2
