from pathlib import Path

def test_cart_api_accepts_budget_and_builds_substitutions():
    text=Path("backend/app/cart_api_v48.py").read_text()
    assert "budget_cap" in text
    assert "suggest_budget_substitutions_v70" in text
    assert '"budget_analysis": budget_analysis' in text

def test_substitutions_require_approved_database_relation():
    text=Path("backend/app/product_substitution_repository_v70.py").read_text()
    assert "approved = TRUE" in text
