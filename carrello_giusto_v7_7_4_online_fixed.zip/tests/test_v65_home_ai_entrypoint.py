from pathlib import Path

def test_home_exposes_ai_assistant():
    text = Path("lib/screens/home_screen.dart").read_text()
    assert "Assistente AI" in text
    assert "_openAiAssistant" in text
    assert "AiCartScreen" in text
