
from pydantic import BaseModel, Field, ValidationError
import pytest

class RequestContract(BaseModel):
    max_stores: int = Field(default=3, ge=1, le=6)

def test_max_stores_six_is_valid():
    assert RequestContract(max_stores=6).max_stores == 6

def test_max_stores_seven_is_rejected():
    with pytest.raises(ValidationError):
        RequestContract(max_stores=7)
