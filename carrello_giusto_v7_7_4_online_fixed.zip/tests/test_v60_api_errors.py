
from backend.app.api_errors_v60 import classify_http_error, should_fallback_to_demo

def test_409_functional_error_never_falls_back():
    err = classify_http_error(
        409,
        {"detail":{"code":"cart_incomplete","message":"manca un prodotto"}},
    )
    assert err.code == "cart_incomplete"
    assert should_fallback_to_demo(err) is False

def test_422_validation_never_falls_back():
    err = classify_http_error(422, {"detail":"invalid"})
    assert err.code == "validation_error"
    assert should_fallback_to_demo(err) is False
