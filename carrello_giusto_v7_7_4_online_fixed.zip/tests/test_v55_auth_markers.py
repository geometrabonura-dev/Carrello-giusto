
from pathlib import Path

def test_admin_dashboards_require_admin():
    root = Path("backend/app")
    for name in ["import_dashboard_v52.py", "review_dashboard_v54.py"]:
        text = (root/name).read_text()
        assert "require_admin" in text
        assert "Depends(require_admin)" in text

def test_review_resolution_requires_admin():
    text = Path("backend/app/review_api_v53.py").read_text()
    assert '@router.post("/resolve-store", dependencies=[Depends(require_admin)])' in text
    assert '@router.post("/resolve-product", dependencies=[Depends(require_admin)])' in text
