from pathlib import Path

def test_product_search_includes_format_and_gtin():
    text = Path("backend/app/admin_search_v56.py").read_text()
    assert "quantity" in text
    assert "unit" in text
    assert "gtin" in text

def test_preview_endpoint_exists():
    text = Path("backend/app/substitution_admin_api_v71.py").read_text()
    assert '@router.get("/preview")' in text
    assert "SubstitutionPreviewV72" in text
