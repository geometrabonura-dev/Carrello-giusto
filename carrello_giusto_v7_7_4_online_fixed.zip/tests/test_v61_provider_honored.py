from pathlib import Path

def test_optimizer_routes_through_v61_matrix():
    text = Path("backend/app/route_aware_optimizer_v48.py").read_text()
    assert "build_pairwise_route_matrix_v61" in text
    assert "routing_provider=routing_provider" in text
    assert "_route_for_combo" not in text
