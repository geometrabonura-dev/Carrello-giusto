
from backend.app.route_optimizer import optimize_stop_order

def test_empty_route():
    result = optimize_stop_order(
        {"latitude": 44.49, "longitude": 11.34},
        [],
    )
    assert result["distance_km"] == 0.0
    assert result["ordered_stops"] == []
