
from pathlib import Path

def test_v40_migration_exists():
    p = Path(__file__).resolve().parents[1] / "backend" / "sql" / "migration_v4_0.sql"
    assert p.exists()
