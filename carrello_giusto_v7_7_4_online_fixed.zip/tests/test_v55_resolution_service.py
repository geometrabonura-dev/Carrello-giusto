
from backend.app.review_resolution_service_v55 import ReviewResolutionServiceV55

class FakeReviewRepo:
    def __init__(self):
        self.store = None
        self.product = None
    def resolve_store_review(self, **kwargs):
        self.store = kwargs
    def resolve_product_review(self, **kwargs):
        self.product = kwargs

class FakeRawRepo:
    def payloads_for_resolved_mapping(self, **kwargs):
        return [{"x": 1}, {"x": 2}]

class FakeReprocess:
    def __init__(self):
        self.calls = []
    def reprocess_payloads(self, **kwargs):
        self.calls.append(kwargs)
        return {"status":"completed"}

class FakeAudit:
    def __init__(self):
        self.logs = []
    def log(self, **kwargs):
        self.logs.append(kwargs)
        return "a1"

def test_store_resolution_reprocesses_and_audits():
    reviews = FakeReviewRepo()
    reproc = FakeReprocess()
    audit = FakeAudit()
    svc = ReviewResolutionServiceV55(
        review_repository=reviews,
        raw_review_repository=FakeRawRepo(),
        reprocess_service=reproc,
        audit=audit,
    )
    result = svc.resolve_store(
        review_id="r1",
        source_key="conad_official",
        external_ref="s-ext",
        store_id="s1",
        actor="admin@example",
    )
    assert result["reprocessed_count"] == 2
    assert reviews.store["store_id"] == "s1"
    assert len(reproc.calls) == 1
    assert audit.logs[0]["action"] == "resolve_store_review"

def test_product_resolution_reprocesses_and_audits():
    reviews = FakeReviewRepo()
    reproc = FakeReprocess()
    audit = FakeAudit()
    svc = ReviewResolutionServiceV55(
        review_repository=reviews,
        raw_review_repository=FakeRawRepo(),
        reprocess_service=reproc,
        audit=audit,
    )
    result = svc.resolve_product(
        review_id="r2",
        source_key="esselunga_official",
        external_ref="ean:123",
        product_id="p1",
        actor="admin",
    )
    assert result["reprocessed_count"] == 2
    assert reviews.product["product_id"] == "p1"
    assert audit.logs[0]["action"] == "resolve_product_review"
