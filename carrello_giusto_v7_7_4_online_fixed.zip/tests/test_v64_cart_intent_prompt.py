from backend.app.ai_cart_intent_v64 import build_parse_prompt

def test_prompt_forbids_invented_commercial_data():
    system, user = build_parse_prompt("2 kg di mele e tonno Rio Mare in offerta")
    lower = system.lower()
    assert "senza inventare prezzi" in lower
    assert "non prendere decisioni economiche" in lower
    assert "Rio Mare" in user
