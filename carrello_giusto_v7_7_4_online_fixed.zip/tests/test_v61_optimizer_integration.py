from dataclasses import dataclass
from backend.app.route_aware_optimizer_v48 import optimize_db_cart_v48

@dataclass
class R:
    distance_km: float
    duration_minutes: float | None
    provider: str
    verified: bool

class FakeRouting:
    def __init__(self):
        self.calls = 0
    def estimate(self, coords, profile="car"):
        self.calls += 1
        a, b = coords
        d = abs(float(a["latitude"])-float(b["latitude"])) + 1.0
        return R(d, d*3, "fake", True)

def pricebook():
    return {
        "a": {
            "store_name":"A","lat":1.0,"lon":0.0,
            "items":{
                "p1":{"product_key":"p1","cost":5.0,"verified":True},
                "p2":{"product_key":"p2","cost":20.0,"verified":True},
            },
        },
        "b": {
            "store_name":"B","lat":2.0,"lon":0.0,
            "items":{
                "p1":{"product_key":"p1","cost":4.0,"verified":True},
                "p2":{"product_key":"p2","cost":6.0,"verified":True},
            },
        },
        "c": {
            "store_name":"C","lat":3.0,"lon":0.0,
            "items":{
                "p1":{"product_key":"p1","cost":50.0,"verified":True},
                "p2":{"product_key":"p2","cost":50.0,"verified":True},
            },
        },
    }

def test_optimizer_deduplicates_unused_superset_stores():
    fake = FakeRouting()
    result = optimize_db_cart_v48(
        pricebook=pricebook(),
        product_keys=["p1","p2"],
        origin={"latitude":0.0,"longitude":0.0},
        routing_provider=fake,
        max_stores=3,
        min_saving_to_travel=3.0,
        strategy="balanced",
    )
    assert result is not None
    assert result["rule"]["routing_v61"] is True
    assert result["optimizer_stats"]["generated_combinations"] == 7
    # More combinations than unique routed purchase plans.
    assert result["optimizer_stats"]["unique_plans_routed"] < 7
    for plan in result["plans"]:
        assigned_store_ids = {a["store_id"] for a in plan["assignments"]}
        routed_store_ids = {s["id"] for s in plan["stores"]}
        assert routed_store_ids == assigned_store_ids

def test_threshold_rule_remains_enforced():
    fake = FakeRouting()
    result = optimize_db_cart_v48(
        pricebook=pricebook(),
        product_keys=["p1","p2"],
        origin={"latitude":0.0,"longitude":0.0},
        routing_provider=fake,
        max_stores=3,
        min_saving_to_travel=100.0,
        strategy="max_saving",
    )
    closest = result["closest_plan"]
    rec = result["recommendation"]
    assert closest["eligible_by_threshold"] is True
    assert rec["plan_key"] == closest["plan_key"]
