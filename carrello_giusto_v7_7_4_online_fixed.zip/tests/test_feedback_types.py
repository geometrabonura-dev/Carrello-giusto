
from backend.app.feedback_service import ALLOWED_FEEDBACK

def test_core_feedback_types_present():
    assert "prefer_cheaper" in ALLOWED_FEEDBACK
    assert "prefer_faster" in ALLOWED_FEEDBACK
    assert "prefer_fewer_stores" in ALLOWED_FEEDBACK
