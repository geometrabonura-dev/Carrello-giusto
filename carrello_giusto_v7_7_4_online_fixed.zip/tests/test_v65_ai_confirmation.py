from pathlib import Path

def test_ai_screen_requires_resolved_product_keys():
    text = Path("lib/screens/ai_cart_screen.dart").read_text()
    assert "productKey == null" in text
    assert "Alcuni articoli non sono ancora collegati al catalogo" in text
    assert "L’AI non decide prezzi, disponibilità o convenienza." in text
