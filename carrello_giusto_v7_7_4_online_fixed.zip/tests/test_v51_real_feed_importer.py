
from backend.app.real_feed_importer_v51 import RealFeedImporterV51
from backend.app.real_offer_models_v51 import RealOfferInput

def test_importer_preserves_provenance():
    offer = RealOfferInput(
        source_key="esselunga_official",
        store_external_ref="store-123",
        product_key="pasta1kg",
        ean="8000000000000",
        product_name="Pasta 1 kg",
        brand=None,
        price=1.99,
        regular_price=2.49,
        quantity=1.0,
        unit="kg",
        valid_from=None,
        valid_to=None,
        loyalty_required=False,
        source_url="https://example.invalid/offer",
        raw_payload={"x": 1},
    )
    result = RealFeedImporterV51().evaluate_offer(
        offer,
        product_match_confidence=1.0,
        store_resolved=True,
    )
    assert result["offer"]["source_key"] == "esselunga_official"
    assert result["offer"]["store_external_ref"] == "store-123"
    assert result["decision"]["verification_status"] == "accepted_unverified"
