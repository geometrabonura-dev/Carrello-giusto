
from backend.app.quality_policy import QualityPolicy

p = QualityPolicy()

verified = p.decide(0.95, 1.0)
assert verified.accepted is True
assert verified.verified is True
assert verified.status == "verified"

accepted = p.decide(0.80, 0.95)
assert accepted.accepted is True
assert accepted.verified is False
assert accepted.status == "accepted_unverified"

review = p.decide(0.60, 0.85)
assert review.accepted is False
assert review.verified is False
assert review.status == "needs_review"

print("quality policy tests: OK")
