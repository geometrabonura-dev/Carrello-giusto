
from backend.app.release_readiness_v60 import release_readiness

def test_internal_readiness_has_expected_checks():
    result = release_readiness(".")
    names = {c["name"] for c in result["checks"]}
    assert "typed_errors" in names
    assert "scalable_routing" in names
    assert result["ready_for_store_submission"] is False
