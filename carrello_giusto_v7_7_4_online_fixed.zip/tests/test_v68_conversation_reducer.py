from backend.app.ai_cart_conversation_v68 import (
    ConversationStateV68,
    apply_actions_v68,
)

def test_preferences_are_clamped_and_applied():
    state = ConversationStateV68()
    updated = apply_actions_v68(
        state=state,
        actions=[
            {"type":"set_max_stores","value":99},
            {"type":"set_strategy","value":"max_comfort"},
            {"type":"set_min_saving","value":5},
            {"type":"set_budget","value":60},
        ],
    )
    assert updated.preferences.max_stores == 6
    assert updated.preferences.strategy == "max_comfort"
    assert updated.preferences.min_saving_to_travel == 5
    assert updated.preferences.budget_cap == 60

def test_remove_item_is_deterministic():
    state = ConversationStateV68(items=[
        {"product_key":"grapes","label":"Uva senza semi"},
        {"product_key":"milk","label":"Latte"},
    ])
    updated = apply_actions_v68(
        state=state,
        actions=[{"type":"remove_item","label":"uva"}],
    )
    assert [x["product_key"] for x in updated.items] == ["milk"]

def test_unknown_actions_do_nothing():
    state = ConversationStateV68(items=[{"label":"Pasta"}])
    updated = apply_actions_v68(
        state=state,
        actions=[{"type":"invent_price","value":0.01}],
    )
    assert updated.items == state.items
