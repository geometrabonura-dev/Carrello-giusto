from types import SimpleNamespace
from backend.app.optimizer_v46 import _required_cost

def test_optimizer_uses_weight_pricing_for_kg():
    offer = SimpleNamespace(price=29.90, quantity=1.0, unit="kg")
    result = _required_cost({"quantity":0.8, "unit":"kg"}, offer)
    assert result["cost"] == 23.92
    assert result["pricing_basis"] == "per_kg"

def test_optimizer_keeps_pack_pricing_for_pack():
    offer = SimpleNamespace(price=3.50, quantity=1.0, unit="pack")
    result = _required_cost({"quantity":2, "unit":"pack"}, offer)
    assert result["cost"] == 7.0
    assert result["pricing_basis"] == "per_pack"
