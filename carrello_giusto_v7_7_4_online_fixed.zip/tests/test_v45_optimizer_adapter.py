
from types import SimpleNamespace
from backend.app.optimizer_input_v45 import to_optimizer_items

def test_adapter_keeps_canonical_key_and_preferences():
    item = SimpleNamespace(
        product_key="pasta1kg",
        product_name="Pasta 1 kg",
        brand=None,
        quantity=1.0,
        unit="kg",
        preferred_brand=None,
        allow_equivalents=True,
        strict_brand=False,
    )
    payload = to_optimizer_items([item])[0]
    assert payload["product_key"] == "pasta1kg"
    assert payload["quantity"] == 1.0
    assert payload["allow_equivalents"] is True
