from pathlib import Path

def test_ai_product_key_is_not_trusted():
    text = Path("backend/app/ai_cart_api_v65.py").read_text()
    assert "Never trust an AI-supplied product_key" in text
    assert '"product_key": resolution.product_key' in text

def test_api_builds_real_provider():
    text = Path("backend/app/ai_cart_api_v65.py").read_text()
    assert "build_ai_client_v66()" in text
