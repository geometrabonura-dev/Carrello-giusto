import pytest
from backend.app.feed_parsing_v62 import (
    parse_bool, parse_decimal, parse_datetime_iso
)

@pytest.mark.parametrize("value", ["false","0","no","off",""])
def test_false_strings_are_false(value):
    assert parse_bool(value) is False

@pytest.mark.parametrize("value", ["true","1","yes","si","sì"])
def test_true_strings_are_true(value):
    assert parse_bool(value) is True

def test_invalid_bool_rejected():
    with pytest.raises(ValueError):
        parse_bool("maybe")

def test_italian_decimal():
    assert parse_decimal("1,99") == 1.99
    assert parse_decimal("1.234,56") == 1234.56

def test_italian_date():
    value = parse_datetime_iso("12/09/2026")
    assert value.startswith("2026-09-12T00:00:00")
