
from backend.app.strategy_profiles import get_strategy

def test_balanced_strategy():
    s = get_strategy("balanced")
    assert s.weight_saving == 0.50
    assert s.weight_time == 0.25
    assert s.weight_simplicity == 0.25

def test_max_comfort_penalizes_extra_stores_more():
    comfort = get_strategy("max_comfort")
    saving = get_strategy("max_saving")
    assert comfort.store_penalty_eur > saving.store_penalty_eur
