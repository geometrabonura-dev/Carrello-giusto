from pathlib import Path

def test_env_example_has_no_secret():
    text = Path("backend/.env.example").read_text()
    assert "OPENAI_API_KEY=" in text
    assert "OPENAI_API_KEY=sk-" not in text
    assert "AI_PROVIDER=openai" in text
