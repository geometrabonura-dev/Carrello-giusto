from pathlib import Path
import yaml

def test_geolocator_is_declared():
    pub = yaml.safe_load(Path("pubspec.yaml").read_text())
    deps = set((pub.get("dependencies") or {}).keys())
    assert "geolocator" in deps

def test_bootstrap_generates_native_projects():
    text = Path("tool/bootstrap_flutter.sh").read_text()
    assert "flutter create" in text
    assert "--platforms=android,ios" in text
    assert "--org it.carrellogiusto" in text

def test_native_config_adds_location_permissions():
    text = Path("tool/configure_native.sh").read_text()
    assert "ACCESS_FINE_LOCATION" in text
    assert "ACCESS_COARSE_LOCATION" in text
    assert "NSLocationWhenInUseUsageDescription" in text

def test_ci_builds_android_apk():
    text = Path(".github/workflows/ci.yml").read_text()
    assert "flutter analyze" in text
    assert "flutter test" in text
    assert "flutter build apk --debug" in text
    assert "actions/upload-artifact@v4" in text
