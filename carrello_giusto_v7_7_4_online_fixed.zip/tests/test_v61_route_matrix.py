from dataclasses import dataclass
from backend.app.route_matrix_v61 import (
    build_pairwise_route_matrix_v61,
    route_for_store_ids_v61,
)

@dataclass
class R:
    distance_km: float
    duration_minutes: float | None
    provider: str
    verified: bool

class FakeRouting:
    def __init__(self):
        self.calls = 0
    def estimate(self, coords, profile="car"):
        self.calls += 1
        a, b = coords
        dx = abs(float(a["latitude"]) - float(b["latitude"]))
        dy = abs(float(a["longitude"]) - float(b["longitude"]))
        d = round(dx + dy + 1.0, 3)
        return R(d, d * 2, "fake", True)

def test_pairwise_matrix_is_reused():
    fake = FakeRouting()
    stores = [
        {"id":"s1","lat":1.0,"lon":0.0},
        {"id":"s2","lat":2.0,"lon":0.0},
        {"id":"s3","lat":3.0,"lon":0.0},
    ]
    m = build_pairwise_route_matrix_v61(
        origin={"latitude":0.0,"longitude":0.0},
        stores=stores,
        travel_profile="car",
        routing_provider=fake,
    )
    # 4 nodes -> 6 undirected pair calls.
    assert fake.calls == 6
    r1 = route_for_store_ids_v61(m, ["s1","s2"])
    r2 = route_for_store_ids_v61(m, ["s1","s3"])
    assert fake.calls == 6
    assert r1["verified"] is True
    assert r2["provider"] == "fake"
