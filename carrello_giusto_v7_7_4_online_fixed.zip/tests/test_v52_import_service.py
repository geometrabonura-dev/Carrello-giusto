
from backend.app.feed_import_service_v52 import FeedImportServiceV52

class FakeRepo:
    def __init__(self):
        self.raw = []
        self.saved = []
        self.finished = None

    def create_run(self, source_key, feed_name=None):
        return "run1"

    def finish_run(self, run_id, status, metrics):
        self.finished = (run_id, status, metrics)

    def store_raw_offer(self, **kwargs):
        self.raw.append(kwargs["payload"])
        return "raw1"

    def resolve_store(self, *, source_key, external_ref):
        if external_ref == "s1":
            return {"id":"store1","name":"Store 1"}
        return None

    def upsert_offer(self, **kwargs):
        self.saved.append(kwargs)
        return "offer1"

    def recent_runs(self, limit=50):
        return []

class FakeMatcher:
    def match(self, **kwargs):
        if kwargs.get("ean") == "111":
            return {"product_id":"p1","confidence":1.0,"method":"ean"}
        return None

def test_imports_matching_offer_as_unverified_for_official_source():
    repo = FakeRepo()
    svc = FeedImportServiceV52(
        repository=repo,
        product_matcher=FakeMatcher(),
    )
    result = svc.import_bytes(
        source_key="esselunga_official",
        payload=b'[{"store_external_ref":"s1","ean":"111","product_name":"Pasta","price":1.99}]',
        content_type="application/json",
        feed_name="x.json",
    )
    assert result["status"] == "completed"
    assert result["metrics"]["accepted"] == 1
    assert result["metrics"]["verified"] == 0
    assert repo.saved[0]["verification_status"] == "accepted_unverified"

def test_tracks_unmatched_store_and_product():
    repo = FakeRepo()
    svc = FeedImportServiceV52(
        repository=repo,
        product_matcher=FakeMatcher(),
    )
    result = svc.import_bytes(
        source_key="conad_official",
        payload=b'[{"store_external_ref":"missing","product_name":"X","price":2.5}]',
        content_type="application/json",
    )
    assert result["metrics"]["unmatched_store"] == 1
    assert result["metrics"]["unmatched_product"] == 1
