from pathlib import Path

def test_ai_screen_edits_quantity_unit_brand_and_equivalents():
    text = Path("lib/screens/ai_cart_screen.dart").read_text()
    assert "_editItem" in text
    assert "Quantità" in text
    assert "Marca preferita" in text
    assert "Accetta equivalenti" in text
    assert "quantity > 999" in text

def test_identity_change_invalidates_product_mapping():
    text = Path("lib/screens/ai_cart_screen.dart").read_text()
    assert "identityChanged" in text
    assert "clearProductKey: identityChanged" in text
    assert "'needs_confirmation'" in text

def test_draft_can_clear_preferred_brand():
    text = Path("lib/models/ai_cart_draft.dart").read_text()
    assert "clearPreferredBrand" in text
