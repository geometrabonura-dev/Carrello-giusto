
from backend.app.explanations_v35 import explain_plan

def test_single_store_explanation():
    plan = {
        "stores": [{"id": "1"}],
        "travel_cost": 1.5,
        "time_cost": 2.0,
        "duration_minutes": 15,
        "personalized_score": 0.9,
        "effective_total": 50.0,
        "product_total": 46.5,
    }
    e = explain_plan(plan)
    assert any("un solo supermercato" in x for x in e["reasons"])
