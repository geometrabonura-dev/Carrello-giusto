from pathlib import Path

def test_live_offer_query_filters_freshness():
    text = Path("backend/app/offer_repository_v46.py").read_text()
    assert "freshness_status" in text
    assert "source_checked_at IS NOT NULL" in text
    assert "INTERVAL '48 hours'" in text
    assert "'stale'" in text
    assert "'not_yet_valid'" in text
