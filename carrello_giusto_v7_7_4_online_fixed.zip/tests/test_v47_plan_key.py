
from backend.app.route_aware_optimizer_v47 import _plan_key

def test_plan_key_is_stable_for_store_and_assignment_order():
    stores_a = [{"id":"2"},{"id":"1"}]
    stores_b = [{"id":"1"},{"id":"2"}]
    assignments_a = [
        {"product_key":"b","store_id":"2","offer_id":"o2"},
        {"product_key":"a","store_id":"1","offer_id":"o1"},
    ]
    assignments_b = list(reversed(assignments_a))

    assert _plan_key(stores_a, assignments_a) == _plan_key(stores_b, assignments_b)
