
from backend.app.review_actions_v56 import ReviewActionsV56

class FakeRepo:
    def __init__(self):
        self.rejected = None
    def reject_review(self, **kwargs):
        self.rejected = kwargs

class FakeAudit:
    def __init__(self):
        self.logs = []
    def log(self, **kwargs):
        self.logs.append(kwargs)
        return "a1"

def test_reject_review_is_audited():
    repo = FakeRepo()
    audit = FakeAudit()
    svc = ReviewActionsV56(repo, audit)
    result = svc.reject(
        review_id="r1",
        source_key="conad_official",
        review_type="product",
        external_ref="ean:123",
        actor="admin",
        reason="prodotto errato",
    )
    assert result["status"] == "rejected"
    assert repo.rejected["review_id"] == "r1"
    assert audit.logs[0]["action"] == "reject_product_review"
