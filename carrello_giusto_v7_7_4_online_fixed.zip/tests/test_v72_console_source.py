from pathlib import Path

def test_console_has_visual_product_search_and_preview():
    text = Path("backend/app/substitution_console_v71.py").read_text()
    assert "Prodotto sorgente" in text
    assert "Prodotto alternativo" in text
    assert "GTIN/EAN" in text
    assert "Calcola anteprima" in text
    assert "Proponi equivalenza" in text
    assert "comparison_status" in text
