from pathlib import Path

def test_migration_adds_review_columns():
    text = Path("backend/sql/migration_v7_1.sql").read_text()
    assert "review_status" in text
    assert "proposed_by" in text
    assert "reviewed_by" in text
