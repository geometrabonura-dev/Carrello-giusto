
from backend.app.strategy_profiles import STRATEGIES

def test_onboarding_strategy_keys_exist():
    assert "max_saving" in STRATEGIES
    assert "balanced" in STRATEGIES
    assert "max_comfort" in STRATEGIES
