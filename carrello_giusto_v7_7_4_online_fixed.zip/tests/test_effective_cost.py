
from backend.app.effective_cost import time_cost, effective_total

def test_time_cost():
    assert time_cost(30, 8.0) == 4.0

def test_effective_total_with_time():
    result = effective_total(50.0, 2.0, 30, 8.0)
    assert result["time_cost"] == 4.0
    assert result["effective_total"] == 56.0
