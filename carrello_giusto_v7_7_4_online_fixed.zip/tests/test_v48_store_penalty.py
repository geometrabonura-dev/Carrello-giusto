
from backend.app.strategy_ranker_v48 import rank_eligible_plans

def test_comfort_penalizes_many_stores():
    plans = [
        {
            "plan_key":"one",
            "product_total":50.0,
            "duration_minutes":10.0,
            "stores_count":1,
            "effective_total":51.0,
        },
        {
            "plan_key":"five",
            "product_total":48.0,
            "duration_minutes":10.0,
            "stores_count":5,
            "effective_total":49.0,
        },
    ]
    best, ranked = rank_eligible_plans(plans, "max_comfort")
    assert best["plan_key"] == "one"
    five = next(p for p in ranked if p["plan_key"] == "five")
    assert five["store_penalty"] == 6.0
