from backend.app.user_catalog_mapping_v67 import normalize_mapping_text

def test_mapping_text_normalization():
    assert normalize_mapping_text("  Tonno   Rio Mare ") == "tonno rio mare"
    assert normalize_mapping_text(None) == ""
