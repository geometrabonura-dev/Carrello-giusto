from backend.app.ai_explainer_v64 import build_explanation_context

def test_explainer_receives_computed_facts_only():
    result = {
        "recommendation": {
            "plan_key":"x",
            "effective_total":42.1,
            "product_total":35,
            "travel_cost":3,
            "time_cost":4.1,
            "stores_count":2,
            "distance_km":7,
            "saving_vs_closest":4,
        },
        "closest_plan":{"effective_total":46.1},
        "rule":{"min_saving_to_travel":3,"strategy":"balanced"},
    }
    ctx = build_explanation_context(result)
    assert ctx["effective_total"] == 42.1
    assert ctx["threshold"] == 3
    assert "assignments" not in ctx
