from backend.app.budget_evaluator_v69 import evaluate_budget_v69

def plan(key, total, eligible=True, stores=1):
    return {
        "plan_key": key,
        "effective_total": total,
        "eligible_by_threshold": eligible,
        "stores_count": stores,
    }

def test_recommended_within_budget():
    result = evaluate_budget_v69(
        budget_cap=60,
        recommendation=plan("rec", 55),
        plans=[plan("rec",55), plan("x",50)],
    )
    assert result.within_budget is True
    assert result.difference == 5
    assert result.best_plan_within_budget_key == "x"

def test_over_budget_finds_eligible_alternative_only():
    result = evaluate_budget_v69(
        budget_cap=60,
        recommendation=plan("rec",64.20),
        plans=[
            plan("rec",64.20),
            plan("good",59.50, True, 2),
            plan("rejected",40.00, False, 3),
        ],
    )
    assert result.within_budget is False
    assert result.difference == 4.20
    assert result.best_plan_within_budget_key == "good"
    assert result.cheapest_eligible_plan_key == "good"

def test_no_plan_within_budget_reports_cheapest_eligible():
    result = evaluate_budget_v69(
        budget_cap=50,
        recommendation=plan("rec",64),
        plans=[plan("rec",64), plan("cheap",57), plan("x",45, False)],
    )
    assert result.best_plan_within_budget_key is None
    assert result.cheapest_eligible_plan_key == "cheap"
    assert result.cheapest_eligible_total == 57
