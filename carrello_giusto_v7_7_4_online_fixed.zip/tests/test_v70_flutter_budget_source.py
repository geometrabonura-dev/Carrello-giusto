from pathlib import Path

def test_budget_flows_to_api():
    controller=Path("lib/controllers/optimization_controller.dart").read_text()
    api=Path("lib/services/api_service_v49.dart").read_text()
    assert "budgetCap: budgetCap" in controller
    assert "'budget_cap': budgetCap" in api

def test_results_explain_no_fake_substitution():
    text=Path("lib/screens/results_screen.dart").read_text()
    assert "Non ci sono sostituzioni approvate e prezzate" in text
    assert "senza cambiare i supermercati del piano" in text
