
from backend.app.store_radius_v50 import filter_pricebook_by_radius

def test_filters_stores_outside_radius():
    pb = {
        "near": {"store_name":"Near","lat":44.50,"lon":11.35,"items":{}},
        "far": {"store_name":"Far","lat":45.00,"lon":12.00,"items":{}},
    }
    out = filter_pricebook_by_radius(
        pb, {"latitude":44.49,"longitude":11.34}, 10
    )
    assert "near" in out
    assert "far" not in out

def test_radius_is_capped_at_30_km():
    pb = {
        "very_far": {"store_name":"Far","lat":45.00,"lon":12.00,"items":{}},
    }
    out = filter_pricebook_by_radius(
        pb, {"latitude":44.49,"longitude":11.34}, 999
    )
    assert "very_far" not in out

def test_missing_coordinates_are_excluded():
    pb = {"unknown": {"store_name":"Unknown","items":{}}}
    out = filter_pricebook_by_radius(
        pb, {"latitude":44.49,"longitude":11.34}, 30
    )
    assert out == {}
