
from pathlib import Path

def test_review_console_is_admin_protected():
    text = Path("backend/app/review_console_v56.py").read_text()
    assert "Depends(require_admin)" in text
    assert "/admin/review-actions/search/stores" in text
    assert "/admin/review-actions/search/products" in text
    assert "/admin/review-actions/retry" in text
    assert "/admin/review-actions/reject" in text

def test_admin_action_api_is_protected():
    text = Path("backend/app/review_admin_api_v56.py").read_text()
    assert text.count("Depends(require_admin)") >= 4
