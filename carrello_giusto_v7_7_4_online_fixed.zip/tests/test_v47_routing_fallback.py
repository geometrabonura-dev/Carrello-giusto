
from backend.app.routing_service import HaversineRoutingProvider

def test_haversine_fallback_does_not_invent_duration():
    r = HaversineRoutingProvider().route([
        {"latitude": 44.49, "longitude": 11.34},
        {"latitude": 44.50, "longitude": 11.36},
    ], profile="driving")
    assert r.distance_km > 0
    assert r.duration_minutes is None
    assert r.verified is False
