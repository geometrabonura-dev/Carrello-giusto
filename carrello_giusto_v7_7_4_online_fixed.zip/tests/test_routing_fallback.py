
from backend.app.routing_service import HaversineRoutingProvider, RoutingService

def test_haversine_multistop_distance():
    p = HaversineRoutingProvider()
    r = p.route([
        {"latitude": 44.4949, "longitude": 11.3426},
        {"latitude": 44.5000, "longitude": 11.3500},
        {"latitude": 44.4949, "longitude": 11.3426},
    ])
    assert r.distance_km > 0
    assert r.verified is False
    assert r.provider == "haversine"
