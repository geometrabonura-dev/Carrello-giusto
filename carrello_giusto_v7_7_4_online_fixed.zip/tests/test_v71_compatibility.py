from backend.app.substitution_compatibility_v71 import (
    evaluate_substitution_compatibility_v71,
)

def test_grams_and_kilos_are_compatible():
    d = evaluate_substitution_compatibility_v71(
        source_quantity=500,
        source_unit="g",
        alternative_quantity=1,
        alternative_unit="kg",
    )
    assert d.compatible is True
    assert d.source_dimension == "mass"
    assert d.alternative_dimension == "mass"

def test_mass_and_volume_are_incompatible():
    d = evaluate_substitution_compatibility_v71(
        source_quantity=1,
        source_unit="kg",
        alternative_quantity=1,
        alternative_unit="l",
    )
    assert d.compatible is False

def test_extreme_pack_size_is_blocked():
    d = evaluate_substitution_compatibility_v71(
        source_quantity=100,
        source_unit="g",
        alternative_quantity=1,
        alternative_unit="kg",
    )
    assert d.compatible is False

def test_weighted_products_get_specific_relation():
    d = evaluate_substitution_compatibility_v71(
        source_quantity=1,
        source_unit="kg",
        alternative_quantity=1.2,
        alternative_unit="kg",
    )
    assert d.compatible is True
    assert d.suggested_relation_type == "weighted_equivalent"
