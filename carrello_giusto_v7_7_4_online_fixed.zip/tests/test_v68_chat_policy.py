from backend.app.ai_orchestrator_v64 import authorize_ai_task

def test_chat_update_is_allowed():
    assert authorize_ai_task("update_cart_conversation").allowed is True

def test_price_override_remains_forbidden():
    assert authorize_ai_task("override_effective_total").allowed is False
