from pathlib import Path

def test_feed_matcher_receives_pack_identity_fields():
    text = Path("backend/app/feed_import_service_v52.py").read_text()
    assert 'quantity=raw.get("quantity")' in text
    assert 'unit=raw.get("unit")' in text
