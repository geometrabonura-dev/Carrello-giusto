
from backend.app.feed_reader_v52 import read_json_feed, read_csv_feed

def test_reads_json_list():
    rows = read_json_feed(b'[{"price":1.2},{"price":2.3}]')
    assert len(rows) == 2

def test_reads_json_wrapped_offers():
    rows = read_json_feed(b'{"offers":[{"price":1.2}]}')
    assert rows[0]["price"] == 1.2

def test_reads_csv():
    rows = read_csv_feed(
        b"store_external_ref,product_name,price\ns1,Pasta,1.99\n"
    )
    assert rows[0]["store_external_ref"] == "s1"
    assert rows[0]["price"] == "1.99"
