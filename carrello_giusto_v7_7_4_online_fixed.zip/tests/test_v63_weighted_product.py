from backend.app.weighted_product_v63 import cost_for_weight

def test_fiorentina_cost_per_kg():
    result = cost_for_weight(requested_kg=0.8, price_per_kg=29.90)
    assert result["cost"] == 23.92
    assert result["pricing_basis"] == "per_kg"
    assert result["supplied_quantity"] == 0.8
