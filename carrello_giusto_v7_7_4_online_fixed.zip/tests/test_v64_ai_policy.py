from backend.app.ai_orchestrator_v64 import authorize_ai_task, AIOrchestratorV64

def test_allowed_ai_task():
    d = authorize_ai_task("parse_user_intent")
    assert d.allowed is True

def test_forbidden_ai_price_invention():
    d = authorize_ai_task("invent_price")
    assert d.allowed is False

def test_unknown_ai_task_denied():
    d = authorize_ai_task("do_everything")
    assert d.allowed is False

def test_no_provider_means_no_ai_execution():
    ai = AIOrchestratorV64()
    result = ai.run(
        task="explain_result",
        system="s",
        user="u",
    )
    assert result["ok"] is False
    assert result["used_ai"] is False
