
from backend.app.travel_profiles import get_profile

def test_profiles():
    assert get_profile("car").cost_per_km == 0.20
    assert get_profile("motorbike").cost_per_km == 0.10
    assert get_profile("bike").routing_profile == "cycling"
    assert get_profile("walking").routing_profile == "walking"
