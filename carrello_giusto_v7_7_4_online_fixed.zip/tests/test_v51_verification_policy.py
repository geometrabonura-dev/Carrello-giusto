
from backend.app.verification_policy_v51 import decide_verification

def test_official_but_not_authorized_is_not_verified():
    d = decide_verification(
        source_key="esselunga_official",
        product_match_confidence=0.99,
        store_resolved=True,
        has_valid_price=True,
    )
    assert d.accepted is True
    assert d.verification_status == "accepted_unverified"
    assert d.source_authorized is False

def test_unknown_source_rejected():
    d = decide_verification(
        source_key="unknown",
        product_match_confidence=1.0,
        store_resolved=True,
        has_valid_price=True,
    )
    assert d.accepted is False
    assert d.verification_status == "rejected"

def test_low_match_needs_review():
    d = decide_verification(
        source_key="conad_official",
        product_match_confidence=0.70,
        store_resolved=True,
        has_valid_price=True,
    )
    assert d.accepted is True
    assert d.verification_status == "needs_review"

def test_missing_store_needs_review():
    d = decide_verification(
        source_key="conad_official",
        product_match_confidence=1.0,
        store_resolved=False,
        has_valid_price=True,
    )
    assert d.accepted is False
    assert d.verification_status == "needs_review"
