
from backend.app.route_cache import RouteCache

def test_route_cache_rounds_coordinates_to_three_decimals():
    cache = RouteCache()
    a = [{"latitude": 44.49491, "longitude": 11.34261}]
    b = [{"latitude": 44.49501, "longitude": 11.34299}]
    assert cache._key(a, "driving") == cache._key(b, "driving")
