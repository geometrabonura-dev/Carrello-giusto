
from backend.app.feed_import_service_v53 import FeedImportServiceV53

class FakeRepo:
    def __init__(self):
        self.saved = []
        self.raw = []
        self.finished = None

    def create_run(self, source_key, feed_name=None):
        return "run1"

    def finish_run(self, run_id, status, metrics):
        self.finished = (status, metrics)

    def store_raw_offer(self, **kwargs):
        self.raw.append(kwargs["payload"])
        return "raw1"

    def resolve_store(self, *, source_key, external_ref):
        if external_ref == "s1":
            return {"id":"store1","name":"Store 1"}
        return None

    def upsert_offer(self, **kwargs):
        self.saved.append(kwargs)
        return "offer1"

class FakeMatcher:
    def match(self, **kwargs):
        if kwargs.get("ean") == "111":
            return {"product_id":"p1","confidence":1.0,"method":"ean"}
        return None

class FakeReviews:
    def __init__(self):
        self.stores = []
        self.products = []

    def enqueue_store(self, **kwargs):
        self.stores.append(kwargs)
        return "rs1"

    def enqueue_product(self, **kwargs):
        self.products.append(kwargs)
        return "rp1"

class FakeMappings:
    def __init__(self, mapping=None):
        self.mapping = mapping or {}

    def resolve(self, *, source_key, external_ref):
        return self.mapping.get((source_key, external_ref))

def test_unmatched_entities_go_to_review_queue():
    reviews = FakeReviews()
    svc = FeedImportServiceV53(
        repository=FakeRepo(),
        product_matcher=FakeMatcher(),
        review_repository=reviews,
        product_mapping_repository=FakeMappings(),
    )
    result = svc.import_bytes(
        source_key="conad_official",
        payload=b'[{"store_external_ref":"missing","product_name":"X","price":2.5}]',
        content_type="application/json",
    )
    assert result["metrics"]["unmatched_store"] == 1
    assert result["metrics"]["unmatched_product"] == 1
    assert len(reviews.stores) == 1
    assert len(reviews.products) == 1

def test_manual_product_mapping_is_reused():
    repo = FakeRepo()
    mappings = FakeMappings({
        ("esselunga_official", "ean:999"): {
            "product_id":"manual-p",
            "confidence":1.0,
            "method":"manual_mapping",
        }
    })
    svc = FeedImportServiceV53(
        repository=repo,
        product_matcher=FakeMatcher(),
        review_repository=FakeReviews(),
        product_mapping_repository=mappings,
    )
    result = svc.import_bytes(
        source_key="esselunga_official",
        payload=b'[{"store_external_ref":"s1","ean":"999","product_name":"Y","price":1.5}]',
        content_type="application/json",
    )
    assert result["metrics"]["manual_product_mapping_used"] == 1
    assert result["metrics"]["accepted"] == 1
    assert repo.saved[0]["product_id"] == "manual-p"
    assert repo.saved[0]["verification_status"] == "accepted_unverified"
