
from backend.app.store_prefilter_v48 import prefilter_store_ids

def test_prefilter_limits_candidate_stores():
    pb = {}
    for i in range(20):
        pb[str(i)] = {
            "store_name": f"S{i}",
            "items": {
                "a": {"cost": i + 1.0}
            }
        }
    ids = prefilter_store_ids(pb, ["a"], max_candidates=12)
    assert len(ids) == 12

def test_prefilter_favors_coverage():
    pb = {
        "full": {
            "store_name": "Full",
            "items": {"a":{"cost":10}, "b":{"cost":10}},
        },
        "partial": {
            "store_name": "Partial",
            "items": {"a":{"cost":1}},
        },
    }
    ids = prefilter_store_ids(pb, ["a","b"], max_candidates=2)
    assert ids[0] == "full"
