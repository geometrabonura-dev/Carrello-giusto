
from types import SimpleNamespace
from backend.app.route_aware_optimizer_v47 import optimize_db_cart_route_aware

class DummyProfile:
    cost_per_km = 0.20
    default_time_value_per_hour = 0.0

def fake_get_profile(_):
    return DummyProfile()

def fake_route(origin, store_rows, routing_provider, travel_profile):
    # near store route 4 km, far store route 10 km.
    names = sorted(s["name"] for s in store_rows)
    if names == ["Near"]:
        return {"distance_km": 4.0, "duration_minutes": 0.0,
                "verified": True, "provider": "test"}
    if names == ["Far"]:
        return {"distance_km": 10.0, "duration_minutes": 0.0,
                "verified": True, "provider": "test"}
    return {"distance_km": 14.0, "duration_minutes": 0.0,
            "verified": True, "provider": "test"}

def test_farther_plan_not_recommended_if_saving_below_threshold(monkeypatch):
    import backend.app.route_aware_optimizer_v47 as mod
    monkeypatch.setattr(mod, "get_profile", fake_get_profile)
    monkeypatch.setattr(mod, "_route_for_combo", fake_route)

    pb = {
        "near": {
            "store_name": "Near", "lat": 1, "lon": 1,
            "items": {
                "a": {"product_key":"a","offer_id":"n","cost":50.0,"verified":True}
            }
        },
        "far": {
            "store_name": "Far", "lat": 2, "lon": 2,
            "items": {
                "a": {"product_key":"a","offer_id":"f","cost":47.5,"verified":True}
            }
        }
    }

    result = optimize_db_cart_route_aware(
        pricebook=pb,
        product_keys=["a"],
        origin={"latitude": 0.0, "longitude": 0.0},
        routing_provider=None,
        travel_profile="car",
        max_stores=1,
        min_saving_to_travel=3.0,
        vehicle_cost_per_km=0.20,
        time_value_per_hour=0.0,
    )
    # near effective = 50.8, far = 49.5 => only 1.3 euro saving.
    assert result["recommendation"]["stores"][0]["name"] == "Near"
    assert result["max_saving_plan"]["stores"][0]["name"] == "Far"
    assert result["max_saving_plan"]["eligible_by_threshold"] is False

def test_farther_plan_can_win_when_threshold_met(monkeypatch):
    import backend.app.route_aware_optimizer_v47 as mod
    monkeypatch.setattr(mod, "get_profile", fake_get_profile)
    monkeypatch.setattr(mod, "_route_for_combo", fake_route)

    pb = {
        "near": {
            "store_name": "Near", "lat": 1, "lon": 1,
            "items": {
                "a": {"product_key":"a","offer_id":"n","cost":50.0,"verified":True}
            }
        },
        "far": {
            "store_name": "Far", "lat": 2, "lon": 2,
            "items": {
                "a": {"product_key":"a","offer_id":"f","cost":44.0,"verified":True}
            }
        }
    }
    result = optimize_db_cart_route_aware(
        pricebook=pb,
        product_keys=["a"],
        origin={"latitude": 0.0, "longitude": 0.0},
        routing_provider=None,
        travel_profile="car",
        max_stores=1,
        min_saving_to_travel=3.0,
        vehicle_cost_per_km=0.20,
        time_value_per_hour=0.0,
    )
    # near = 50.8, far = 46.0 => 4.8 saving, so far may win.
    assert result["recommendation"]["stores"][0]["name"] == "Far"
    assert result["recommendation"]["eligible_by_threshold"] is True
