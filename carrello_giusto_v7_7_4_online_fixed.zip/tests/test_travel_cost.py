
from backend.app.travel_cost import calculate_travel_cost

def test_travel_cost():
    assert calculate_travel_cost(20.0, 0.20) == 4.0
