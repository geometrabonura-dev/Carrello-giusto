
from backend.app.request_models_v43 import CartItemV43

def test_fractional_quantity_allowed_by_contract():
    item = CartItemV43(
        product_key="uva_senza_semi",
        quantity=1.25,
        unit="kg",
        allow_equivalents=True,
    )
    assert item.quantity == 1.25
