from pathlib import Path

def test_confirm_endpoint_validates_catalog_product():
    text = Path("backend/app/ai_cart_api_v65.py").read_text()
    assert '@router.post("/confirm-mapping")' in text
    assert "catalog.resolve_key(payload.product_key)" in text
    assert "UserCatalogMappingRepositoryV67().save" in text

def test_ai_parse_passes_user_id_to_catalog_resolution():
    text = Path("backend/app/ai_cart_api_v65.py").read_text()
    assert "user_id=payload.user_id" in text
    assert "user_id=user_id" in text
