
from types import SimpleNamespace
from backend.app.cart_offer_resolution_v46 import (
    CartCoverageResult,
    CoveredCartItem,
)
from backend.app.optimizer_v46 import optimize_price_only

def offer(store_id, store_name, price, verified=True):
    return SimpleNamespace(
        offer_id=f"{store_id}-{price}",
        store_id=store_id,
        store_name=store_name,
        product_key="",
        product_name="",
        brand=None,
        price=price,
        regular_price=None,
        quantity=1.0,
        unit="piece",
        verified=verified,
        source_status="active",
        loyalty_required=False,
    )

def test_optimizer_can_split_cart_across_stores():
    coverage = CartCoverageResult(
        covered=[
            CoveredCartItem(
                item={"product_key": "a", "name": "A", "quantity": 1},
                offers=[
                    offer("s1", "Store 1", 10),
                    offer("s2", "Store 2", 8),
                ],
            ),
            CoveredCartItem(
                item={"product_key": "b", "name": "B", "quantity": 1},
                offers=[
                    offer("s1", "Store 1", 6),
                    offer("s2", "Store 2", 9),
                ],
            ),
        ],
        missing=[],
    )

    plan = optimize_price_only(coverage, max_stores=2)
    assert plan["product_total"] == 14.0
    assert plan["stores_count"] == 2

def test_verified_status_requires_all_assignments_verified():
    coverage = CartCoverageResult(
        covered=[
            CoveredCartItem(
                item={"product_key": "a", "name": "A", "quantity": 1},
                offers=[offer("s1", "Store 1", 5, verified=False)],
            )
        ],
        missing=[],
    )
    plan = optimize_price_only(coverage)
    assert plan["all_offers_verified"] is False
