from backend.app.ai_product_match_v64 import (
    should_auto_accept_ai_match,
    route_ai_match,
)

def test_ai_match_never_auto_accepted():
    assert should_auto_accept_ai_match(1.0) is False
    assert should_auto_accept_ai_match(0.99) is False

def test_high_confidence_still_needs_deterministic_confirmation():
    assert route_ai_match(0.99) == "deterministic_confirmation_required"
