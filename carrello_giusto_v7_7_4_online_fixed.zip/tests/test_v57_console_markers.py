
from pathlib import Path

def test_console_has_filters_payload_and_metrics():
    text = Path("backend/app/review_console_v57.py").read_text()
    assert "Payload raw" in text
    assert "page_size" in text
    assert "review_type" in text
    assert "source_key" in text
    assert "avg_resolution_hours" in text
    assert "/admin/reviews-v57/reopen" in text

def test_review_api_is_admin_protected():
    text = Path("backend/app/review_api_v57.py").read_text()
    assert text.count("Depends(require_admin)") >= 3
