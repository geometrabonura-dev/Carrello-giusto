
from types import SimpleNamespace
import pytest

from backend.app.cart_resolution_v45 import (
    resolve_cart_items,
    CartValidationError,
)

class FakeRepo:
    def resolve_key(self, key):
        rows = {
            "pasta1kg": SimpleNamespace(
                product_key="pasta1kg",
                name="Pasta 1 kg",
                brand=None,
                unit="kg",
                strict_brand=False,
                allow_fractional_quantity=True,
            ),
            "rio_mare_tonno": SimpleNamespace(
                product_key="rio_mare_tonno",
                name="Tonno Rio Mare",
                brand="Rio Mare",
                unit="pack",
                strict_brand=True,
                allow_fractional_quantity=False,
            ),
        }
        return rows.get(key)

def raw(**kwargs):
    defaults = dict(
        product_key="pasta1kg",
        quantity=1,
        unit="kg",
        preferred_brand=None,
        allow_equivalents=True,
    )
    defaults.update(kwargs)
    return SimpleNamespace(**defaults)

def test_resolves_fractional_weight_product():
    items = resolve_cart_items(
        [raw(quantity=1.25)],
        repo=FakeRepo(),
    )
    assert items[0].quantity == 1.25
    assert items[0].allow_equivalents is True

def test_strict_brand_disables_equivalents():
    items = resolve_cart_items(
        [raw(
            product_key="rio_mare_tonno",
            quantity=1,
            unit="pack",
            preferred_brand="Rio Mare",
            allow_equivalents=True,
        )],
        repo=FakeRepo(),
    )
    assert items[0].preferred_brand == "Rio Mare"
    assert items[0].allow_equivalents is False

def test_rejects_fractional_pack():
    with pytest.raises(CartValidationError):
        resolve_cart_items(
            [raw(
                product_key="rio_mare_tonno",
                quantity=1.5,
                unit="pack",
            )],
            repo=FakeRepo(),
        )

def test_rejects_wrong_unit():
    with pytest.raises(CartValidationError):
        resolve_cart_items(
            [raw(unit="l")],
            repo=FakeRepo(),
        )
