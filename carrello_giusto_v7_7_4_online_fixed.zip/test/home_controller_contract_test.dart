
import 'package:flutter_test/flutter_test.dart';
import 'package:spesa_smart/controllers/home_controller.dart';

void main() {
  test('home controller can be constructed', () {
    expect(HomeController(), isNotNull);
  });
}
