
import 'package:flutter_test/flutter_test.dart';
import 'package:spesa_smart/models/optimization_result.dart';

void main() {
  test('parses max stores and threshold', () {
    final result = OptimizationResult.fromApi({
      'data_status': 'verified',
      'strategy': {'key':'balanced','label':'Bilanciato'},
      'rule': {'max_stores': 6, 'min_saving_to_travel': 3.0},
      'recommendation': {
        'plan_key':'x',
        'product_total': 40,
        'travel_cost': 2,
        'time_cost': 1,
        'effective_total': 43,
        'distance_km': 10,
        'duration_minutes': 20,
        'stores_count': 5,
        'recommended': true,
        'eligible_by_threshold': true,
        'saving_vs_closest': 4,
        'store_penalty': 3,
        'stores': [],
        'assignments': [],
      },
      'plans': [],
    });

    expect(result.maxStores, 6);
    expect(result.minSavingToTravel, 3.0);
    expect(result.recommendation.storesCount, 5);
  });
}
