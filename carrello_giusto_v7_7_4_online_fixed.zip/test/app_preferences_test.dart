
import 'package:flutter_test/flutter_test.dart';
import 'package:spesa_smart/models/app_preferences.dart';

void main() {
  test('defaults match MVP rules', () {
    const p = AppPreferences();
    expect(p.radiusKm, 10);
    expect(p.minSavingToTravel, 3);
    expect(p.maxStores, 3);
    expect(p.strategy, 'balanced');
  });

  test('supports six stores', () {
    const p = AppPreferences(maxStores: 6);
    expect(p.maxStores, 6);
  });
}
