
import 'package:flutter_test/flutter_test.dart';
import 'package:spesa_smart/models/optimization_result.dart';

void main() {
  test('parses recommendation and metadata', () {
    final result = OptimizationResult.fromApi({
      'data_status': 'verified',
      'strategy': {'key': 'balanced'},
      'explanation': {
        'headline': 'Scelta consigliata',
        'reasons': ['Meno strada'],
      },
      'recommendation': {
        'reason': 'Migliore',
        'product_total': 50,
        'travel_cost': 1,
        'time_cost': 2,
        'effective_total': 53,
        'stores': [{'id': 's1'}],
        'distance_km': 3,
        'duration_minutes': 10,
      },
      'closest_plan': null,
      'max_saving_plan': null,
      'best_single_store': null,
    });

    expect(result.dataStatus, 'verified');
    expect(result.strategy, 'balanced');
    expect(result.plans.length, 1);
    expect(result.plans.first.recommended, true);
  });
}
