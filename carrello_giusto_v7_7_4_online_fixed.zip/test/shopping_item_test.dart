
import 'package:flutter_test/flutter_test.dart';
import 'package:spesa_smart/models/shopping_item.dart';

void main() {
  test('shopping item serializes canonical payload', () {
    const item = ShoppingItem(
      productKey: 'rio_mare_tonno',
      label: 'Tonno Rio Mare',
      quantity: 1,
      unit: 'confezione',
      preferredBrand: 'Rio Mare',
      allowEquivalents: false,
    );

    final json = item.toApiJson();
    expect(json['product_key'], 'rio_mare_tonno');
    expect(json['preferred_brand'], 'Rio Mare');
    expect(json['allow_equivalents'], false);
  });
}
