
import 'package:flutter_test/flutter_test.dart';
import 'package:spesa_smart/models/product_catalog.dart';

void main() {
  test('default catalog contains expected canonical products', () {
    final keys = ProductCatalog.defaults.map((e) => e.productKey).toSet();
    expect(keys.contains('pasta1kg'), true);
    expect(keys.contains('rio_mare_tonno'), true);
    expect(keys.contains('fiorentina'), true);
  });
}
