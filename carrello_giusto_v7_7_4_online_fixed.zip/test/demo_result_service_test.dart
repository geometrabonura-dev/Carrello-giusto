
import 'package:flutter_test/flutter_test.dart';
import 'package:spesa_smart/services/demo_result_service.dart';

void main() {
  test('demo fallback is explicit', () {
    final result = DemoResultService().build();
    expect(result.fromFallback, true);
    expect(result.dataStatus, 'demo');
    expect(result.warning, isNotNull);
    expect(result.plans, isNotEmpty);
  });
}
