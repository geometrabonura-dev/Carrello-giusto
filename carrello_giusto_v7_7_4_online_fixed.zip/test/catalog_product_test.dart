
import 'package:flutter_test/flutter_test.dart';
import 'package:spesa_smart/models/catalog_product.dart';

void main() {
  test('catalog product parses backend payload', () {
    final p = CatalogProduct.fromJson({
      'product_key': 'pasta1kg',
      'name': 'Pasta 1 kg',
      'unit': 'kg',
      'default_quantity': 1,
      'strict_brand': false,
      'allow_fractional_quantity': true,
    });

    expect(p.productKey, 'pasta1kg');
    expect(p.allowFractionalQuantity, true);
  });
}
